/* One match, two read-only camera observers. UI commands use the existing match runtime. */
(function(){
 'use strict';
 const $=id=>document.getElementById(id),meta=JSON.parse($('camera-workbench-source').textContent),
  frame=$('match-engine'),STORE='kneekura.camera-workbench.settings.v1',SIDES=['A','B'],
  COMMANDS=['managed-team','batting-choice','baserunning-choice','pitch-choice','location-choice'],
  TITLES=['操作チーム','打撃','走塁','球種','コース'];
 let win,playback,factory,controllers={},ready=false,busy=false,cancel=false,playing=false,
  currentMs=0,speed=1,mode='loop',camera='batter',loopStartMs=0,loopEndMs=null,
  snapshots={},uiCommands=[],lastMeasure=null,raf=0,lastPaint=0,playOrigin=0,playStarted=0;
 const clone=value=>JSON.parse(JSON.stringify(value));
 const fail=error=>{pause();$('status').textContent=error.message??String(error);$('status').classList.add('error');};
 const message=text=>{$('status').textContent=text;$('status').classList.remove('error');};
 const guard=()=>{if(!ready)throw Error('試合Coreは準備中です');if(busy)throw Error('生成中です。先に生成を停止してください');};
 function object(value,keys,label){
  if(!value||typeof value!=='object'||Array.isArray(value)||Object.getPrototypeOf(value)!==Object.prototype)throw Error(label+'はJSON objectが必要です');
  if(Object.keys(value).some(key=>!keys.includes(key))||Object.values(Object.getOwnPropertyDescriptors(value)).some(d=>d.get||d.set))throw Error(label+'に未対応の項目があります');
 }
 function number(value,min,max,label){if(!Number.isFinite(value)||value<min||value>max)throw Error(label+'が範囲外です');return value;}
 function settingsPacket(value){
  object(value,['schema','sourceGameSha256','settings'],'調整JSON');
  if(value.schema!=='kneekura_camera_tuning_v1'||value.sourceGameSha256!==meta.sourceGameSha256)throw Error('調整JSONのschema／基準試合が一致しません');
  return normalizePair(value.settings);
 }
 function normalizePair(value){
  object(value,SIDES,'A/B設定');if(!value.A||!value.B)throw Error('AとBの設定が必要です');
  return {A:factory.normalizeSettings(value.A),B:factory.normalizeSettings(value.B)};
 }
 function exportSettings(){return {schema:'kneekura_camera_tuning_v1',sourceGameSha256:meta.sourceGameSha256,
  settings:Object.fromEntries(SIDES.map(side=>[side,controllers[side].inspectSettings()]))};}
 function persist(){
  const packet=exportSettings();$('settings-json').value=JSON.stringify(packet,null,2);
  try{localStorage.setItem(STORE,JSON.stringify(packet));}catch{message('調整値は画面に反映済みです。ブラウザ保存は利用できないためJSONで保存してください。');}
 }
 function applyPair(pair){for(const side of SIDES)controllers[side].configure(pair[side]);syncSettings();persist();lastMeasure=null;}
 function setSettings(side,patch){guard();if(!SIDES.includes(side))throw Error('Unknown camera side');
  const next=factory.normalizeSettings({...controllers[side].inspectSettings(),...patch});
  controllers[side].configure(next);pause();syncSettings();persist();lastMeasure=null;renderPair(currentMs);return exportSettings();}
 function importSettings(packet){guard();const pair=settingsPacket(packet);pause();applyPair(pair);renderPair(currentMs);return exportSettings();}
 const fields=[['aimLiftMeters','狙い目から上へ','m',0,.8,.01],['swingMaxDownRadians','下向きの上限','rad',.1,1.25,.01],
  ['hitFollowDelayMs','打球を観測してからの待機','ms',0,600,5],['aimReleaseMs','打球追尾への移行時間','ms',20,400,5]];
 function createSettings(){for(const side of SIDES){
  const box=$('settings-'+side),enabled=document.createElement('label'),toggle=document.createElement('input');
  toggle.type='checkbox';toggle.id='enabled-'+side;toggle.onchange=()=>run(()=>setSettings(side,{enabled:toggle.checked}));
  const span=document.createElement('span');span.append(toggle,' スイング視点の調整を適用');enabled.append(span);box.append(enabled);
  const grid=document.createElement('div');grid.className='controls';
  for(const [key,title,unit,min,max,step]of fields){const label=document.createElement('label'),input=document.createElement('input'),out=document.createElement('output');
   input.type='range';input.id=key+'-'+side;input.min=min;input.max=max;input.step=step;label.htmlFor=input.id;label.textContent=title;
   out.id='value-'+key+'-'+side;out.htmlFor=input.id;input.oninput=()=>run(()=>setSettings(side,{[key]:Number(input.value)}));
   grid.append(label,out,input);
  }box.append(grid);
 }}
 function syncSettings(){for(const side of SIDES){const settings=controllers[side].inspectSettings();$('enabled-'+side).checked=settings.enabled;
  $('label-'+side).textContent=settings.enabled?'調整設定':'従来設定';
  for(const [key,,unit]of fields){$(key+'-'+side).value=settings[key];$(key+'-'+side).disabled=!settings.enabled;
   $('value-'+key+'-'+side).value=(unit==='m'||unit==='rad'?settings[key].toFixed(2):settings[key])+' '+unit+(unit==='rad'?' / '+(settings[key]*180/Math.PI).toFixed(0)+'°':'');}
 }}
 const inspectSource=()=>playback.inspect();
 function checkSource(){const s=inspectSource();if(s.error)throw Error('Core: '+s.error);return s;}
 function summarize(s){const view=s.presentation.continuousBatterView;return {sceneMs:s.presentation.elapsedMs,tick:s.currentFrame.tick,
  camera:s.rendered.camera,eye:s.rendered.cameraEye,yaw:s.rendered.cameraYaw,pitch:s.rendered.cameraPitch,phase:view?.phase,
  aimWeight:view?.aimWeight,regulation:view?.regulation??null,tuning:view?.tuning??null,ball:s.rendered.ballDotDisplay??null};}
 function copyCanvas(side,s){const source=win.document.getElementById('field'),canvas=$('view-'+side);
  if(canvas.width!==source.width)canvas.width=source.width;if(canvas.height!==source.height)canvas.height=source.height;
  const ctx=canvas.getContext('2d');ctx.imageSmoothingEnabled=false;ctx.clearRect(0,0,canvas.width,canvas.height);ctx.drawImage(source,0,0);
  if($('guides').checked){const v=s.presentation.continuousBatterView,cx=v?.cx??canvas.width/2,cy=v?.cy??canvas.height/2;
   ctx.strokeStyle=side==='A'?'#70c8ff':'#ffdc69';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(cx-8,cy);ctx.lineTo(cx+8,cy);ctx.moveTo(cx,cy-8);ctx.lineTo(cx,cy+8);ctx.stroke();}
  const snapshot=snapshots[side];$('phase-'+side).textContent=snapshot.phase??'準備';
  const degrees=r=>Number.isFinite(r)?(r*180/Math.PI).toFixed(1)+'°':'—';
  $('metrics-'+side).textContent='同時刻 '+snapshot.sceneMs.toFixed(0)+'ms / Source tick '+snapshot.tick+'\n'+
   '下向き '+degrees(snapshot.pitch)+' / 左右 '+degrees(snapshot.yaw)+' / 狙い保持 '+(snapshot.aimWeight??0).toFixed(2)+'\n'+
   '目標の下向き '+degrees(snapshot.regulation?.targetPitch)+' / '+(snapshot.camera??camera);
 }
 function renderPair(ms){if(!ready)return;
  for(const side of SIDES){win.KneekuraContinuousBatterView=controllers[side];playback.seekPresentationMs(Math.max(0,ms));
   const s=checkSource();snapshots[side]=summarize(s);copyCanvas(side,s);currentMs=s.presentation.elapsedMs;}
  syncTransport();
 }
 function syncTransport(){const s=inspectSource(),duration=s.presentation.durationMs;
  $('timeline').max=Math.max(1,duration);$('timeline').value=currentMs;$('time-label').value=Math.round(currentMs)+' / '+Math.round(duration)+' ms';
  $('loop-label').value='区間 '+Math.round(loopStartMs)+'–'+Math.round(loopEndMs??duration)+' ms';
  const m=s.observedMatch??s.host.match;
  $('match-status').textContent=(m.inning??1)+'回'+(m.half==='top'?'表':'裏')+' / '+(m.outs??0)+'アウト / '+s.generatedPitches+'球生成'+(s.host.finished?' / 規定終了':'')+' / seed '+win.document.getElementById('match-seed').value;
  $('play').disabled=busy;$('next-pitch').disabled=busy||s.host.finished&&s.selectedPitch>=s.generatedPitches-1;
 }
 function refreshHistory(){const s=inspectSource(),select=$('pitch-list'),selected=s.selectedPitch;select.replaceChildren();
  for(const [i,r]of s.host.history.entries()){const option=document.createElement('option');option.value=i;
   option.textContent=(i+1)+'球目 / '+r.beforeMatch.inning+'回'+(r.beforeMatch.half==='top'?'表':'裏')+' / '+r.batterPlayerId+' / '+r.play.classification;
   select.append(option);}select.value=selected;refreshMarkers();
 }
 function refreshMarkers(){const s=inspectSource(),r=s.lastResult,box=$('markers');box.replaceChildren();if(!r)return;
  const prep=s.presentation.timing.preparationMs,d=r.play.diagnostics,tps=d.sourceClockTicksPerSecond??1e6,first=r.frames[0].tick,
   eventMs=tick=>prep+(tick-first)/tps*1000,hit=r.frames.find(f=>f.ballKind==='batted'),entries=[['投球開始',prep],
    ['予定インパクト',eventMs(d.referenceContactTick)],['スイング終端',eventMs(d.referenceThroughTick)],
    ['打球発生',hit?eventMs(hit.tick):NaN],['公式終了',eventMs(r.play.rules.endedAtTick)]];
  for(const [title,ms]of entries)if(Number.isFinite(ms)&&ms>=0){const b=document.createElement('button');b.textContent=title+' '+Math.round(ms)+'ms';b.onclick=()=>run(()=>seek(ms));box.append(b);}
 }
 function readCommand(){return Object.fromEntries(COMMANDS.map(id=>[id,$('cmd-'+id).value]));}
 function validateCommand(value){object(value,COMMANDS,'配球指示');for(const id of COMMANDS){
  if(typeof value[id]!=='string'||![...win.document.getElementById(id).options].some(o=>o.value===value[id]))throw Error('未対応の配球指示: '+id);
 }return clone(value);}
 function applyCommand(value){for(const id of COMMANDS){const source=win.document.getElementById(id);source.value=value[id];$('cmd-'+id).value=value[id];source.dispatchEvent(new win.Event('change'));}}
 function pause(){playing=false;cancelAnimationFrame(raf);if(ready&&!busy)playback.stop();}
 function seek(ms){guard();number(ms,0,1e9,'再生時刻');pause();renderPair(ms);return inspect();}
 function selectPitch(index){guard();const s=inspectSource();if(!Number.isSafeInteger(index)||index<0||index>=s.generatedPitches)throw Error('Unknown pitch');
  pause();playback.seekPitch(index);loopStartMs=0;loopEndMs=null;renderPair(0);$('pitch-list').value=index;refreshMarkers();return inspect();}
 function issueNext(){const before=inspectSource(),command=readCommand();applyCommand(command);win.document.getElementById('next-pitch').click();
  const after=checkSource();if(after.generatedPitches>before.generatedPitches)uiCommands.push(command);
  loopStartMs=0;loopEndMs=null;refreshHistory();return after;
 }
 function nextPitch(){guard();pause();issueNext();renderPair(0);return inspect();}
 function setCamera(value){guard();if(!['batter','runner','mound','catcher','overhead'].includes(value))throw Error('Unknown camera');
  pause();camera=value;$('camera-choice').value=value;win.document.querySelector('[data-camera="'+value+'"]').click();renderPair(currentMs);return inspect();}
 function setSpeed(value){guard();number(value,.1,4,'再生速度');pause();speed=value;$('speed').value=String(value);return inspect();}
 function setLoop(start,end){guard();const duration=inspectSource().presentation.durationMs;
  number(start,0,duration,'始点');if(end!==null){number(end,0,duration,'終点');if(end<=start)throw Error('終点は始点より後にしてください');}
  pause();loopStartMs=start;loopEndMs=end;syncTransport();return inspect();}
 function play(){guard();pause();if(!inspectSource().generatedPitches)issueNext();
  if(currentMs>=(loopEndMs??inspectSource().presentation.durationMs))renderPair(mode==='loop'?loopStartMs:0);
  if(mode==='loop'&&currentMs<loopStartMs)renderPair(loopStartMs);
  playing=true;playOrigin=currentMs;playStarted=performance.now();lastPaint=-Infinity;
  const update=now=>{if(!playing)return;try{
   const duration=inspectSource().presentation.durationMs,end=mode==='loop'?(loopEndMs??duration):duration,
    desired=playOrigin+(now-playStarted)*speed;
   if(desired>=end){renderPair(end);
    if(mode==='loop'){playOrigin=loopStartMs;playStarted=now;renderPair(loopStartMs);}
    else if(mode==='match'&&!(inspectSource().host.finished&&inspectSource().selectedPitch===inspectSource().generatedPitches-1)){
     issueNext();renderPair(0);playOrigin=0;playStarted=now;
    }else{pause();return;}
   }else if(now-lastPaint>=55){renderPair(desired);lastPaint=now;}
   raf=requestAnimationFrame(update);
  }catch(error){fail(error);}};raf=requestAnimationFrame(update);
 }
 function setPlayMode(value){guard();if(!['loop','pause','match'].includes(value))throw Error('Unknown play mode');pause();mode=value;$('play-mode').value=value;}
 function gameConfig(value={}){object(value,['seed','innings'],'試合条件');const seed=value.seed??$('seed').value,innings=value.innings??Number($('innings').value);
  if(typeof seed!=='string'||!seed.length||seed.length>128)throw Error('seedは1〜128文字です');
  if(![...win.document.getElementById('inning-limit').options].some(option=>Number(option.value)===innings))throw Error('未対応の回数です');return {seed,innings};
 }
 function resetGame(config){pause();win.document.getElementById('match-seed').value=config.seed;win.document.getElementById('inning-limit').value=config.innings;
  $('seed').value=config.seed;$('innings').value=config.innings;playback.newGame();checkSource();uiCommands=[];loopStartMs=0;loopEndMs=null;
 }
 function newGame(value){guard();const config=gameConfig(value);resetGame(config);refreshHistory();renderPair(0);message('新しい試合です。次の一球を自由に生成できます。');return inspect();}
 function setBusy(value){busy=value;$('cancel-generation').disabled=!value;for(const id of ['next-pitch','play','new-game','generate','finish-game','load-session'])$(id).disabled=value;}
 function settleGeneration(){setBusy(false);refreshHistory();const partial=inspectSource();if(!partial.error)renderPair(partial.presentation.elapsedMs);else{snapshots={};currentMs=0;for(const side of SIDES){const canvas=$('view-'+side);canvas.getContext('2d').clearRect(0,0,canvas.width,canvas.height);$('metrics-'+side).textContent='Coreエラーにより描画を停止';}syncTransport();}}
 async function generate(count=12){guard();if(!Number.isSafeInteger(count)||count<1||count>2048)throw Error('生成球数が範囲外です');pause();cancel=false;setBusy(true);
  try{const s=inspectSource();if(s.generatedPitches)playback.seekPitch(s.generatedPitches-1);
   for(let i=0;i<count&&!cancel&&!inspectSource().host.finished;i++){issueNext();message((i+1)+' / '+count+'球を生成中');await new Promise(resolve=>setTimeout(resolve,0));}
   checkSource();refreshHistory();renderPair(0);message(cancel?'生成を停止しました。':'球を生成しました。記録から比較するプレーを選べます。');
  }finally{setBusy(false);syncTransport();}return inspect();
 }
 async function finish(){guard();pause();cancel=false;setBusy(true);const command=readCommand();applyCommand(command);
  const progress=setInterval(()=>{const s=inspectSource();message('規定終了まで生成中 / '+s.generatedPitches+'球');},200);
  try{await playback.finish();const s=checkSource();while(uiCommands.length<s.generatedPitches)uiCommands.push(clone(command));
   refreshHistory();renderPair(s.presentation.elapsedMs);message(cancel?'生成を停止しました。':s.host.finished?'規定終了まで生成しました。全ての球を比較できます。':'生成を停止しました。');
  }finally{clearInterval(progress);const completed=inspectSource().generatedPitches;while(uiCommands.length<completed)uiCommands.push(clone(command));settleGeneration();}return inspect();
 }
 function cancelGeneration(){cancel=true;if(ready&&inspectSource().fast)void playback.finish();}
 function exportSession(){guard();const s=checkSource();if(uiCommands.length!==s.generatedPitches)throw Error('配球履歴と試合が一致しないため保存を停止しました');return {schema:'kneekura_camera_session_v1',sourceGameSha256:meta.sourceGameSha256,
  sourceCoreSha256:meta.sourceCoreSha256,settings:exportSettings().settings,
  scenario:{seed:win.document.getElementById('match-seed').value,innings:Number(win.document.getElementById('inning-limit').value),commands:clone(uiCommands)},
  position:{pitchIndex:s.selectedPitch,sceneMs:currentMs,camera},playback:{speed,mode,loopStartMs,loopEndMs}};}
 async function importSession(packet){guard();
  object(packet,['schema','sourceGameSha256','sourceCoreSha256','settings','scenario','position','playback'],'再現session');
  if(packet.schema!=='kneekura_camera_session_v1'||packet.sourceGameSha256!==meta.sourceGameSha256||packet.sourceCoreSha256!==meta.sourceCoreSha256)throw Error('再現sessionのschema／Coreが一致しません');
  const pair=normalizePair(packet.settings);object(packet.scenario,['seed','innings','commands'],'scenario');if(typeof packet.scenario.seed!=='string'||!Number.isSafeInteger(packet.scenario.innings))throw Error('sessionにseedと回数が必要です');const config=gameConfig({seed:packet.scenario.seed,innings:packet.scenario.innings}),commands=packet.scenario.commands;
  if(!Array.isArray(commands)||commands.length>2048)throw Error('配球履歴が範囲外です');const validated=commands.map(validateCommand);
  object(packet.position,['pitchIndex','sceneMs','camera'],'position');const pos=packet.position;
  if(!Number.isSafeInteger(pos.pitchIndex)||pos.pitchIndex<(validated.length?0:-1)||pos.pitchIndex>=validated.length)throw Error('選択球が範囲外です');
  number(pos.sceneMs,0,1e9,'再生時刻');if(!['batter','runner','mound','catcher','overhead'].includes(pos.camera))throw Error('Unknown camera');
  object(packet.playback,['speed','mode','loopStartMs','loopEndMs'],'playback');const state=packet.playback;
  number(state.speed,.1,4,'速度');if(!['loop','pause','match'].includes(state.mode))throw Error('Unknown play mode');number(state.loopStartMs,0,1e9,'始点');
  if(state.loopEndMs!==null){number(state.loopEndMs,0,1e9,'終点');if(state.loopEndMs<=state.loopStartMs)throw Error('不正な再生区間です');}
  // Validate the entire packet before replacing the current match/settings.
  pause();cancel=false;setBusy(true);
  try{resetGame(config);for(const [i,command]of validated.entries()){
    if(cancel)throw Error('再現を中断しました。途中までの試合を保持します');if(inspectSource().host.finished)throw Error('規定終了後の配球が含まれています');
    applyCommand(command);issueNext();message('セッション再現中 '+(i+1)+' / '+validated.length+'球');await new Promise(resolve=>setTimeout(resolve,0));
   }
   applyPair(pair);if(pos.pitchIndex>=0)playback.seekPitch(pos.pitchIndex);camera=pos.camera;$('camera-choice').value=camera;
   win.document.querySelector('[data-camera="'+camera+'"]').click();speed=state.speed;$('speed').value=String(speed);mode=state.mode;$('play-mode').value=mode;
   loopStartMs=Math.min(state.loopStartMs,inspectSource().presentation.durationMs);loopEndMs=state.loopEndMs===null?null:Math.min(state.loopEndMs,inspectSource().presentation.durationMs);
   if(loopEndMs!==null&&loopEndMs<=loopStartMs){loopStartMs=0;loopEndMs=null;}
   refreshHistory();renderPair(pos.sceneMs);message('同じCoreでセッションを再現しました。');
  }finally{settleGeneration();}return inspect();
 }
 function measure(){guard();const source=inspectSource(),r=source.lastResult;if(!r)throw Error('先に球を生成してください');
  const player=source.physicalRoster.players.find(p=>p.playerId===r.batterPlayerId),batter={...player,height:player.heightMeters,hand:r.play.diagnostics.battingSide},
   prep=source.presentation.timing.preparationMs,tps=r.play.diagnostics.sourceClockTicksPerSecond??1e6,origin=r.frames[0].tick,
   readers=Object.fromEntries(SIDES.map(side=>[side,factory.create(controllers[side].inspectSettings())])),samples=[];
  for(let ms=0;ms<=source.presentation.durationMs;ms+=55){const tick=origin+Math.max(0,ms-prep)/1000*tps,
   f=ms<=prep?r.beforeFrame:r.frames.findLast(f=>f.tick<=tick)??r.frames[0],row={ms};
   for(const side of SIDES){const v=readers[side].observe({record:r,frame:f,sceneMs:ms,preparationMs:prep,batter,
     previousRecord:source.selectedPitch>0?source.host.history[source.selectedPitch-1]:null});
    row[side]={pitch:v.pitch,yaw:v.yaw,phase:v.phase,aimWeight:v.aimWeight,tuning:v.tuning??null,regulation:v.regulation??null};}
   samples.push(row);
  }
  lastMeasure={pitchIndex:source.selectedPitch,samples};drawPlot(samples);$('measure-status').textContent='青=A、黄=B / '+samples.length+'標本 / '+Math.round(source.presentation.durationMs)+'ms。設定変更後は再計測してください。';return clone(lastMeasure);
 }
 function drawPlot(samples){const canvas=$('angle-plot'),ctx=canvas.getContext('2d'),w=canvas.width,h=canvas.height,pad=32;
  ctx.clearRect(0,0,w,h);ctx.font='12px sans-serif';ctx.lineWidth=1;ctx.fillStyle='#aebdc8';
  for(const degrees of [-60,-30,0,30,60]){const y=pad+(degrees+80)/160*(h-pad*2);ctx.strokeStyle='#34414c';ctx.beginPath();ctx.moveTo(pad,y);ctx.lineTo(w-pad,y);ctx.stroke();ctx.fillText(degrees+'°',0,y+4);}
  for(const side of SIDES){ctx.strokeStyle=side==='A'?'#70c8ff':'#ffdc69';ctx.lineWidth=2;ctx.beginPath();
   for(const [i,row]of samples.entries()){const x=pad+row.ms/Math.max(1,samples.at(-1).ms)*(w-pad*2),y=pad+(row[side].pitch*180/Math.PI+80)/160*(h-pad*2);if(i)ctx.lineTo(x,y);else ctx.moveTo(x,y);}ctx.stroke();}
 }
 function inspect(){if(!ready)return {version:1,ready:false};const s=inspectSource();return {version:1,ready:true,busy,playing,speed,mode,camera,
  sceneMs:currentMs,durationMs:s.presentation.durationMs,selectedPitch:s.selectedPitch,generatedPitches:s.generatedPitches,finished:s.host.finished,
  loopStartMs,loopEndMs,A:clone(snapshots.A??null),B:clone(snapshots.B??null),settings:exportSettings().settings,
  seed:win.document.getElementById('match-seed').value,uiCommands:clone(uiCommands),error:s.error,source:meta};}
 function save(packet,name){const url=URL.createObjectURL(new Blob([JSON.stringify(packet,null,2)+'\n'],{type:'application/json'})),a=document.createElement('a');
  a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
 async function run(action){try{return await action();}catch(error){fail(error);}}
 function bind(){const click=(id,action)=>$(id).onclick=()=>run(action);
  click('next-pitch',nextPitch);click('play',play);click('pause',pause);click('step-back',()=>seek(Math.max(0,currentMs-55)));click('step-forward',()=>seek(currentMs+55));
  $('timeline').oninput=()=>run(()=>seek(Number($('timeline').value)));$('pitch-list').onchange=()=>run(()=>selectPitch(Number($('pitch-list').value)));
  $('camera-choice').onchange=()=>run(()=>setCamera($('camera-choice').value));$('speed').onchange=()=>run(()=>setSpeed(Number($('speed').value)));
  $('play-mode').onchange=()=>run(()=>setPlayMode($('play-mode').value));$('guides').onchange=()=>run(()=>renderPair(currentMs));
  click('loop-start',()=>setLoop(currentMs,loopEndMs));click('loop-end',()=>setLoop(loopStartMs,currentMs));click('loop-clear',()=>setLoop(0,null));
  click('copy-a-b',()=>setSettings('B',controllers.A.inspectSettings()));click('copy-b-a',()=>setSettings('A',controllers.B.inspectSettings()));
  click('reset-baseline',()=>setSettings('A',{...factory.defaults,enabled:false}));click('reset-default',()=>setSettings('B',factory.defaults));
  click('new-game',()=>newGame());click('generate',()=>generate(12));click('finish-game',finish);click('cancel-generation',cancelGeneration);click('measure',measure);
  click('save-settings',()=>save(exportSettings(),'kneekura-camera-tuning.json'));click('save-session',()=>save(exportSession(),'kneekura-camera-session.json'));
  $('load-settings').onchange=event=>run(async()=>{const file=event.target.files[0];if(file){if(file.size>100000)throw Error('調整JSONが大きすぎます');importSettings(JSON.parse(await file.text()));}});
  $('load-session').onchange=event=>run(async()=>{const file=event.target.files[0];if(file){if(file.size>2000000)throw Error('再現sessionが大きすぎます');await importSession(JSON.parse(await file.text()));}});
  click('copy-json',async()=>{try{await navigator.clipboard.writeText($('settings-json').value);message('調整JSONをコピーしました。');}catch{$('settings-json').select();message('JSONを選択しました。コピー操作で保存できます。');}});
  document.addEventListener('keydown',event=>{if(/INPUT|TEXTAREA|SELECT/.test(event.target.tagName)||event.ctrlKey||event.metaKey||event.altKey)return;
   if(event.code==='Space'){event.preventDefault();run(playing?pause:play);}else if(event.key==='ArrowLeft'){event.preventDefault();run(()=>seek(Math.max(0,currentMs-55)));}
   else if(event.key==='ArrowRight'){event.preventDefault();run(()=>seek(currentMs+55));}});
 }
 frame.addEventListener('load',()=>run(()=>{
  win=frame.contentWindow;playback=win.liveMatchPlayback;factory=win.KneekuraCameraTuningBatterView;if(!playback||!factory)throw Error('埋め込み試合の起動に失敗しました');
  controllers={A:factory.create({enabled:false}),B:factory.create()};createSettings();
  for(const [i,id]of COMMANDS.entries()){const source=win.document.getElementById(id),label=document.createElement('label'),select=source.cloneNode(true);
   select.id='cmd-'+id;label.textContent=TITLES[i];label.append(select);$('commands').append(label);select.onchange=()=>run(()=>{guard();applyCommand(readCommand());});}
  $('seed').value=win.document.getElementById('match-seed').value;win.document.getElementById('fixed-seed').checked=true;
  $('innings').replaceChildren(...[...win.document.getElementById('inning-limit').options].map(option=>option.cloneNode(true)));$('innings').value=win.document.getElementById('inning-limit').value;
  const overhead=win.document.getElementById('auto-overhead');overhead.checked=false;overhead.dispatchEvent(new win.Event('change'));
  win.document.querySelector('[data-camera="batter"]').click();
  let storageWarning='',restored=false;try{const saved=localStorage.getItem(STORE);if(saved){applyPair(settingsPacket(JSON.parse(saved)));restored=true;}}catch{storageWarning=' 保存済み設定は読み込めなかったため初期値を使用しました。';}
  ready=true;bind();syncSettings();persist();renderPair(0);$('pause').disabled=false;$('step-back').disabled=false;$('step-forward').disabled=false;
  $('source-info').textContent='基準試合SHA256 '+meta.sourceGameSha256+' / Core '+meta.sourceCoreSha256+' / '+meta.sourceInputCount+'入力';
  message((restored?'準備完了。保存済みのA/B設定を復元しました。':'準備完了。Aは従来設定、Bは改善初期値です。')+storageWarning);
 }));
 window.KneekuraCameraLab=Object.freeze({version:1,inspect,setSettings,seek,selectPitch,nextPitch,generate,play,pause,setCamera,setSpeed,setLoop,setPlayMode,
  measure,exportSettings,importSettings,exportSession,importSession,newGame,finish,cancelGeneration});
 frame.srcdoc=CAMERA_LAB_GAME_HTML;
})();
