import {
  asRuleProfileId,
  type RuleProfileId,
} from '../model/RuleProfileRef';

export type RuleProfile = Readonly<{
  id: RuleProfileId;
  jurisdiction: string;
  season: number;
  rulesRevision: string;
  tagUp: Readonly<{
    legalReleaseBasis: 'first_fielder_touch' | 'secure_catch';
    earlyDepartureRequiresAppeal: boolean;
  }>;
  appeal: Readonly<{
    nextPitchOrPlayClosesWindow: boolean;
    defenseLeavingFieldClosesInningEndingWindow: boolean;
    sameTickWindowCloseResolution:
      | 'unresolved'
      | 'appeal_wins'
      | 'window_close_wins';
    advantageousFourthOutPolicy:
      | 'defense_may_elect_advantageous_out'
      | 'disabled';
  }>;
  officialWindows?: Readonly<{
    appeal?: Readonly<{ available: boolean }>;
    review?: Readonly<{ available: boolean; expiresAfterTicks?: number }>;
    challenge?: Readonly<{ available: boolean; expiresAfterTicks?: number }>;
  }>;
  thirdOutScoring: Readonly<{
    batterRunnerBeforeFirstSuppressesRuns: boolean;
    forceThirdOutSuppressesRuns: boolean;
    precedingRunnerAppealSuppressesFollowingRuns: boolean;
  }>;
  defensiveAlignment: Readonly<{
    requiredInfielderCount: number;
    infieldBoundary: Readonly<{
      enabled: boolean;
      evaluationMoment:
        | 'pitching_related_motion_start'
        | 'pitch_release';
      geometrySource:
        | 'stadium_profile'
        | 'fixed_reference';
    }>;
    secondBaseSide: Readonly<{
      enabled: boolean;
      evaluationMoment:
        | 'pitch_release'
        | 'pitching_related_motion_start';
      minimumInfieldersEachSideOfSecondBase: number;
      sideDeterminedBy:
        | 'both_feet'
        | 'body_center';
      assignmentLock: Readonly<{
        enabled: boolean;
        establishedAt:
          | 'inning_first_pitch_release'
          | 'every_pitch_release';
        duration:
          | 'half_inning'
          | 'single_pitch';
      }>;
    }>;
    violationPolicyId: string;
  }>;
}>;

export const NPB_2026_RULE_PROFILE: RuleProfile = {
  id: asRuleProfileId('npb-2026'),
  jurisdiction: 'NPB',
  season: 2026,
  rulesRevision: '2026',
  tagUp: {
    legalReleaseBasis: 'first_fielder_touch',
    earlyDepartureRequiresAppeal: true,
  },
  appeal: {
    nextPitchOrPlayClosesWindow: true,
    defenseLeavingFieldClosesInningEndingWindow: true,
    sameTickWindowCloseResolution: 'unresolved',
    advantageousFourthOutPolicy:
      'defense_may_elect_advantageous_out',
  },
  officialWindows: {
    appeal: { available: true },
  },
  thirdOutScoring: {
    batterRunnerBeforeFirstSuppressesRuns: true,
    forceThirdOutSuppressesRuns: true,
    precedingRunnerAppealSuppressesFollowingRuns: true,
  },
  defensiveAlignment: {
    requiredInfielderCount: 4,
    infieldBoundary: {
      enabled: true,
      evaluationMoment: 'pitching_related_motion_start',
      geometrySource: 'stadium_profile',
    },
    secondBaseSide: {
      enabled: true,
      evaluationMoment: 'pitch_release',
      minimumInfieldersEachSideOfSecondBase: 2,
      sideDeterminedBy: 'both_feet',
      assignmentLock: {
        enabled: true,
        establishedAt: 'inning_first_pitch_release',
        duration: 'half_inning',
      },
    },
    violationPolicyId: 'npb_2026_5_02_c',
  },
};

const RULE_PROFILES = new Map<string, RuleProfile>([
  [NPB_2026_RULE_PROFILE.id, NPB_2026_RULE_PROFILE],
]);

export const isKnownRuleProfileId = (
  id: RuleProfileId,
): boolean => RULE_PROFILES.has(id);

export const getRuleProfile = (
  id: RuleProfileId,
): RuleProfile => {
  const profile = RULE_PROFILES.get(id);
  if (profile === undefined) {
    throw new Error(`unsupported rule profile: ${id}`);
  }
  return profile;
};
