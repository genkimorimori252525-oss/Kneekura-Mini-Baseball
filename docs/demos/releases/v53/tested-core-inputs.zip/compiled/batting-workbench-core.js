"use strict";
var KneekuraBaseballWorkbench = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // src/integration/browser/workbench-index.ts
  var workbench_index_exports = {};
  __export(workbench_index_exports, {
    applyLivePhysicalRosterV1: () => applyLivePhysicalRosterV1,
    createMeasuredBatAxisReferenceV1: () => createMeasuredBatAxisReferenceV1,
    createReferenceBatKinematicsV1: () => createReferenceBatKinematicsV1,
    createWorkbenchPlayer: () => createWorkbenchPlayer,
    defaultWorkbenchPlayer: () => defaultWorkbenchPlayer,
    editLivePublicAbilityV1: () => editLivePublicAbilityV1,
    exportWorkbenchPlayerSources: () => exportWorkbenchPlayerSources,
    getLiveTraitCatalogV1: () => getLiveTraitCatalogV1,
    previewLeagueRatings: () => previewLeagueRatings,
    previewLivePublicLeagueV1: () => previewLivePublicLeagueV1,
    projectLivePublicAbilitiesV1: () => projectLivePublicAbilitiesV1,
    projectLiveTraitProfilesV1: () => projectLiveTraitProfilesV1,
    setLiveTraitProfileV1: () => setLiveTraitProfileV1,
    simulateBattingWorkbench: () => simulateBattingWorkbench,
    simulateReferenceBattingWorkbench: () => simulateReferenceBattingWorkbench,
    validateLiveTraitProfileV1: () => validateLiveTraitProfileV1
  });

  // src/core/sim/ExactEventTime.ts
  var FLOATING_TICK_TOLERANCE = 1e-9;
  var assertAuthoritativeTick = (tick2, name) => {
    if (!Number.isSafeInteger(tick2) || tick2 < 0) {
      throw new Error(`${name} must be a non-negative safe integer tick`);
    }
  };
  var quantizeEventTick = (startTick, elapsedSeconds, ticksPerSecond) => {
    assertAuthoritativeTick(startTick, "startTick");
    if (!Number.isFinite(elapsedSeconds) || elapsedSeconds < 0) {
      throw new Error("elapsedSeconds must be a finite non-negative number");
    }
    if (!Number.isInteger(ticksPerSecond) || ticksPerSecond <= 0) {
      throw new Error("ticksPerSecond must be a positive integer");
    }
    const rawOffsetTicks = elapsedSeconds * ticksPerSecond;
    const nearestInteger = Math.round(rawOffsetTicks);
    const tolerance = FLOATING_TICK_TOLERANCE + Number.EPSILON * Math.max(1, Math.abs(rawOffsetTicks)) * 8;
    const offsetTicks = Math.abs(rawOffsetTicks - nearestInteger) <= tolerance ? nearestInteger : Math.ceil(rawOffsetTicks);
    const eventTick = startTick + offsetTicks;
    assertAuthoritativeTick(eventTick, "eventTick");
    return eventTick;
  };
  var findFirstTrueTick = (startTick, endTick, hasOccurredBy) => {
    assertAuthoritativeTick(startTick, "startTick");
    assertAuthoritativeTick(endTick, "endTick");
    if (endTick < startTick) {
      throw new Error("endTick must be greater than or equal to startTick");
    }
    if (hasOccurredBy(startTick)) {
      return startTick;
    }
    if (!hasOccurredBy(endTick)) {
      return null;
    }
    let low = startTick + 1;
    let high = endTick;
    while (low < high) {
      const middle = low + Math.floor((high - low) / 2);
      if (hasOccurredBy(middle)) {
        high = middle;
      } else {
        low = middle + 1;
      }
    }
    return low;
  };

  // src/core/model/RuleProfileRef.ts
  var asRuleProfileId = (value) => {
    if (value.length === 0) {
      throw new Error("rule profile id must not be empty");
    }
    return value;
  };

  // src/core/rules/RuleProfile.ts
  var NPB_2026_RULE_PROFILE = {
    id: asRuleProfileId("npb-2026"),
    jurisdiction: "NPB",
    season: 2026,
    rulesRevision: "2026",
    tagUp: {
      legalReleaseBasis: "first_fielder_touch",
      earlyDepartureRequiresAppeal: true
    },
    appeal: {
      nextPitchOrPlayClosesWindow: true,
      defenseLeavingFieldClosesInningEndingWindow: true,
      sameTickWindowCloseResolution: "unresolved",
      advantageousFourthOutPolicy: "defense_may_elect_advantageous_out"
    },
    officialWindows: {
      appeal: { available: true }
    },
    thirdOutScoring: {
      batterRunnerBeforeFirstSuppressesRuns: true,
      forceThirdOutSuppressesRuns: true,
      precedingRunnerAppealSuppressesFollowingRuns: true
    },
    defensiveAlignment: {
      requiredInfielderCount: 4,
      infieldBoundary: {
        enabled: true,
        evaluationMoment: "pitching_related_motion_start",
        geometrySource: "stadium_profile"
      },
      secondBaseSide: {
        enabled: true,
        evaluationMoment: "pitch_release",
        minimumInfieldersEachSideOfSecondBase: 2,
        sideDeterminedBy: "both_feet",
        assignmentLock: {
          enabled: true,
          establishedAt: "inning_first_pitch_release",
          duration: "half_inning"
        }
      },
      violationPolicyId: "npb_2026_5_02_c"
    }
  };
  var RULE_PROFILES = /* @__PURE__ */ new Map([
    [NPB_2026_RULE_PROFILE.id, NPB_2026_RULE_PROFILE]
  ]);

  // src/core/adjudication/OfficialWindowPolicy.ts
  var cloneInert = (input) => {
    const ancestors = /* @__PURE__ */ new Set();
    let nodes = 0;
    const visit = (value, depth) => {
      nodes += 1;
      if (nodes > 1e5 || depth > 64) throw new Error("official window input exceeds size limits");
      if (value === null || typeof value === "string" || typeof value === "boolean") return value;
      if (typeof value === "number") {
        if (!Number.isFinite(value)) throw new Error("official window input must be finite");
        return value;
      }
      if (typeof value !== "object") throw new Error("official window input must contain inert data only");
      if (ancestors.has(value)) throw new Error("official window input must not contain cycles");
      ancestors.add(value);
      const result = Array.isArray(value) ? [] : {};
      if (!Array.isArray(value)) {
        const prototype = Object.getPrototypeOf(value);
        if (prototype !== Object.prototype && prototype !== null) {
          throw new Error("official window input must be a plain inert object");
        }
      } else if (Reflect.ownKeys(value).length !== value.length + 1) {
        throw new Error("official window input must be a dense inert array");
      }
      for (const key of Reflect.ownKeys(value)) {
        if (Array.isArray(value) && key === "length") continue;
        if (typeof key !== "string") throw new Error("official window input must not contain symbols");
        const descriptor = Object.getOwnPropertyDescriptor(value, key);
        if (!descriptor || !descriptor.enumerable || !("value" in descriptor)) {
          throw new Error("official window input must not contain accessors");
        }
        Object.defineProperty(result, key, {
          value: visit(descriptor.value, depth + 1),
          enumerable: true,
          writable: true,
          configurable: true
        });
      }
      ancestors.delete(value);
      return result;
    };
    return visit(input, 0);
  };

  // src/core/sim/contact/RigidBatBallContact.ts
  var REFERENCE_BASEBALL_RIGID_BODY = Object.freeze({
    massKg: 0.145,
    radiusM: 0.0366,
    rotationalInertiaFactor: 0.4
  });
  var MEASURED_BASEBALL_ROTATIONAL_INERTIA_FACTOR = 0.378;
  var REALISTIC_BASEBALL_RIGID_BODY = Object.freeze({
    ...REFERENCE_BASEBALL_RIGID_BODY,
    rotationalInertiaFactor: MEASURED_BASEBALL_ROTATIONAL_INERTIA_FACTOR
  });
  var CROSS_NATHAN_2006_LOW_SPEED_BAT_CONTACT_FIXTURE = Object.freeze({
    normalRestitution: 0.63,
    tangentialRestitution: 0.16,
    frictionCoefficient: 0.5
  });
  var EPSILON = 1e-12;
  var add = (a, b) => ({
    x: a.x + b.x,
    y: a.y + b.y,
    z: a.z + b.z
  });
  var subtract = (a, b) => ({
    x: a.x - b.x,
    y: a.y - b.y,
    z: a.z - b.z
  });
  var scale = (value, scalar) => ({
    x: value.x * scalar,
    y: value.y * scalar,
    z: value.z * scalar
  });
  var dot = (a, b) => a.x * b.x + a.y * b.y + a.z * b.z;
  var cross = (a, b) => ({
    x: a.y * b.z - a.z * b.y,
    y: a.z * b.x - a.x * b.z,
    z: a.x * b.y - a.y * b.x
  });
  var magnitude = (value) => Math.hypot(value.x, value.y, value.z);
  var normalize = (value) => {
    const length = magnitude(value);
    if (length <= EPSILON) {
      throw new Error("cannot normalize a zero-length vector");
    }
    return scale(value, 1 / length);
  };
  var clamp01 = (value) => Math.max(0, Math.min(1, value));
  var validateRadiusProfile = (profile) => {
    if (profile.knots.length < 2) {
      throw new Error("bat radius profile requires at least two knots");
    }
    let previousT = -Infinity;
    for (const knot of profile.knots) {
      if (!Number.isFinite(knot.t) || knot.t < 0 || knot.t > 1) {
        throw new Error("bat radius knot t must be finite within [0, 1]");
      }
      if (!Number.isFinite(knot.radiusM) || knot.radiusM <= 0) {
        throw new Error("bat radius knot radiusM must be finite and positive");
      }
      if (knot.t <= previousT) {
        throw new Error("bat radius knots must be strictly increasing");
      }
      previousT = knot.t;
    }
    if (profile.knots[0].t !== 0 || profile.knots[profile.knots.length - 1].t !== 1) {
      throw new Error("bat radius profile must include t=0 and t=1 endpoints");
    }
  };
  var validateEffectiveMassProfile = (profile) => {
    if (profile.knots.length < 2) {
      throw new Error(
        "bat effective-mass profile requires at least two knots"
      );
    }
    let previousT = -Infinity;
    for (const knot of profile.knots) {
      if (!Number.isFinite(knot.t) || knot.t < 0 || knot.t > 1) {
        throw new Error(
          "bat effective-mass knot t must be finite within [0, 1]"
        );
      }
      if (!Number.isFinite(knot.effectiveMassKg) || knot.effectiveMassKg <= 0) {
        throw new Error(
          "bat effective-mass knot value must be finite and positive"
        );
      }
      if (knot.t <= previousT) {
        throw new Error(
          "bat effective-mass knots must be strictly increasing"
        );
      }
      previousT = knot.t;
    }
    if (profile.knots[0].t !== 0 || profile.knots[profile.knots.length - 1].t !== 1) {
      throw new Error(
        "bat effective-mass profile must include t=0 and t=1 endpoints"
      );
    }
  };
  var validateBat = (bat) => {
    const p = bat.physical;
    if (!Number.isFinite(p.massKg) || p.massKg <= 0) {
      throw new Error("bat massKg must be finite and positive");
    }
    if (!Number.isFinite(p.centerOfMassT) || p.centerOfMassT < 0 || p.centerOfMassT > 1) {
      throw new Error("bat centerOfMassT must be finite within [0, 1]");
    }
    if (!Number.isFinite(p.transverseMomentOfInertiaKgM2) || p.transverseMomentOfInertiaKgM2 <= 0 || !Number.isFinite(p.axialMomentOfInertiaKgM2) || p.axialMomentOfInertiaKgM2 <= 0) {
      throw new Error("bat moments of inertia must be finite and positive");
    }
    validateRadiusProfile(p.radiusProfile);
    if (p.normalEffectiveMassProfile !== void 0) {
      validateEffectiveMassProfile(
        p.normalEffectiveMassProfile
      );
    }
  };
  var validateBall = (ball) => {
    if (!Number.isFinite(ball.massKg) || ball.massKg <= 0) {
      throw new Error("ball massKg must be finite and positive");
    }
    if (!Number.isFinite(ball.radiusM) || ball.radiusM <= 0) {
      throw new Error("ball radiusM must be finite and positive");
    }
    if (!Number.isFinite(ball.rotationalInertiaFactor) || ball.rotationalInertiaFactor <= 0) {
      throw new Error(
        "ball rotationalInertiaFactor must be finite and positive"
      );
    }
  };
  var validateContactParameters = (parameters) => {
    for (const [name, value] of [
      ["normalRestitution", parameters.normalRestitution],
      ["tangentialRestitution", parameters.tangentialRestitution]
    ]) {
      if (!Number.isFinite(value) || value < 0 || value > 1) {
        throw new Error(`${name} must be finite within [0, 1]`);
      }
    }
    if (!Number.isFinite(parameters.frictionCoefficient) || parameters.frictionCoefficient < 0) {
      throw new Error("frictionCoefficient must be finite and non-negative");
    }
  };
  var sampleBatRadius = (profile, t) => {
    validateRadiusProfile(profile);
    if (!Number.isFinite(t)) {
      throw new Error("bat radius sample t must be finite");
    }
    const clamped = clamp01(t);
    for (let index = 1; index < profile.knots.length; index += 1) {
      const right = profile.knots[index];
      if (clamped > right.t) {
        continue;
      }
      const left = profile.knots[index - 1];
      const span = right.t - left.t;
      const local = span <= EPSILON ? 0 : (clamped - left.t) / span;
      return left.radiusM + (right.radiusM - left.radiusM) * local;
    }
    return profile.knots[profile.knots.length - 1].radiusM;
  };
  var sampleBatEffectiveMass = (profile, t) => {
    validateEffectiveMassProfile(profile);
    if (!Number.isFinite(t)) {
      throw new Error("bat effective-mass sample t must be finite");
    }
    const clamped = clamp01(t);
    for (let index = 1; index < profile.knots.length; index += 1) {
      const right = profile.knots[index];
      if (clamped > right.t) {
        continue;
      }
      const left = profile.knots[index - 1];
      const span = right.t - left.t;
      const local = span <= EPSILON ? 0 : (clamped - left.t) / span;
      return left.effectiveMassKg + (right.effectiveMassKg - left.effectiveMassKg) * local;
    }
    return profile.knots[profile.knots.length - 1].effectiveMassKg;
  };
  var axisGeometry = (pose) => {
    const delta = subtract(pose.tip, pose.grip);
    const lengthM = magnitude(delta);
    if (lengthM <= EPSILON) {
      throw new Error("bat pose grip and tip must not be identical");
    }
    return {
      axis: scale(delta, 1 / lengthM),
      lengthM
    };
  };
  var closestPointOnTaperedBat = (point, bat) => {
    const { axis, lengthM } = axisGeometry(bat.pose);
    const fromGrip = subtract(
      point,
      bat.pose.grip
    );
    const projectedS = dot(
      fromGrip,
      axis
    );
    const perpendicular = subtract(
      fromGrip,
      scale(axis, projectedS)
    );
    const perpendicularDistance = magnitude(
      perpendicular
    );
    let best = null;
    const consider = (candidateT) => {
      const t = clamp01(candidateT);
      const axisPoint = add(
        bat.pose.grip,
        scale(axis, t * lengthM)
      );
      const localRadiusM = sampleBatRadius(
        bat.physical.radiusProfile,
        t
      );
      const surfaceSeparationM = magnitude(subtract(point, axisPoint)) - localRadiusM;
      if (best === null || surfaceSeparationM < best.surfaceSeparationM) {
        best = {
          point: axisPoint,
          t,
          localRadiusM,
          surfaceSeparationM
        };
      }
    };
    const knots = bat.physical.radiusProfile.knots;
    for (let index = 1; index < knots.length; index += 1) {
      const left = knots[index - 1];
      const right = knots[index];
      consider(left.t);
      consider(right.t);
      const intervalLengthM = (right.t - left.t) * lengthM;
      const radiusSlope = (right.radiusM - left.radiusM) / intervalLengthM;
      if (Math.abs(radiusSlope) < 1) {
        const longitudinalOffsetM = radiusSlope * perpendicularDistance / Math.sqrt(
          1 - radiusSlope * radiusSlope
        );
        const candidateS = projectedS + longitudinalOffsetM;
        const candidateT = candidateS / lengthM;
        if (candidateT >= left.t && candidateT <= right.t) {
          consider(candidateT);
        }
      }
    }
    if (best === null) {
      throw new Error("bat radius profile produced no contact candidates");
    }
    return best;
  };
  var batCenterOfMassPoint = (bat) => add(
    bat.pose.grip,
    scale(
      subtract(bat.pose.tip, bat.pose.grip),
      bat.physical.centerOfMassT
    )
  );
  var applyBatInverseInertia = (value, batAxis, physical2) => {
    const parallel = scale(batAxis, dot(value, batAxis));
    const perpendicular = subtract(value, parallel);
    return add(
      scale(parallel, 1 / physical2.axialMomentOfInertiaKgM2),
      scale(
        perpendicular,
        1 / physical2.transverseMomentOfInertiaKgM2
      )
    );
  };
  var applyBallInverseInertia = (value, ball) => {
    const inertia = ball.rotationalInertiaFactor * ball.massKg * ball.radiusM * ball.radiusM;
    return scale(value, 1 / inertia);
  };
  var pointVelocity = (centerVelocity, angularVelocity, leverArm) => add(
    centerVelocity,
    cross(angularVelocity, leverArm)
  );
  var applyImpulse = (state, impulseOnBall, ballLeverArm, batLeverArm, ball, bat, batAxis) => {
    state.ballVelocity = add(
      state.ballVelocity,
      scale(impulseOnBall, 1 / ball.massKg)
    );
    state.ballSpin = add(
      state.ballSpin,
      applyBallInverseInertia(
        cross(ballLeverArm, impulseOnBall),
        ball
      )
    );
    const impulseOnBat = scale(impulseOnBall, -1);
    state.batVelocity = add(
      state.batVelocity,
      scale(impulseOnBat, 1 / bat.physical.massKg)
    );
    state.batAngularVelocity = add(
      state.batAngularVelocity,
      applyBatInverseInertia(
        cross(batLeverArm, impulseOnBat),
        batAxis,
        bat.physical
      )
    );
  };
  var relativeSurfaceVelocity = (state, ballLeverArm, batLeverArm) => subtract(
    pointVelocity(
      state.ballVelocity,
      state.ballSpin,
      ballLeverArm
    ),
    pointVelocity(
      state.batVelocity,
      state.batAngularVelocity,
      batLeverArm
    )
  );
  var ballInverseMassContributionAlong = (direction, ballLeverArm, ball) => {
    const angular = dot(
      direction,
      cross(
        applyBallInverseInertia(
          cross(ballLeverArm, direction),
          ball
        ),
        ballLeverArm
      )
    );
    return 1 / ball.massKg + angular;
  };
  var rigidBatInverseMassContributionAlong = (direction, batLeverArm, bat, batAxis) => {
    const angular = dot(
      direction,
      cross(
        applyBatInverseInertia(
          cross(batLeverArm, direction),
          batAxis,
          bat.physical
        ),
        batLeverArm
      )
    );
    return 1 / bat.physical.massKg + angular;
  };
  var effectiveInverseMassAlong = (direction, ballLeverArm, batLeverArm, ball, bat, batAxis) => ballInverseMassContributionAlong(
    direction,
    ballLeverArm,
    ball
  ) + rigidBatInverseMassContributionAlong(
    direction,
    batLeverArm,
    bat,
    batAxis
  );
  var createRigidBatStateFromBatterSwingState = (swing, physical2) => {
    validateBat({
      pose: swing.pose,
      centerOfMassVelocity: {
        x: 0,
        y: 0,
        z: 0
      },
      angularVelocity: swing.angularVelocity,
      physical: physical2
    });
    const centerOfMassPoint = add(
      swing.pose.grip,
      scale(
        subtract(
          swing.pose.tip,
          swing.pose.grip
        ),
        physical2.centerOfMassT
      )
    );
    const gripToCenterOfMass = subtract(
      centerOfMassPoint,
      swing.pose.grip
    );
    return {
      pose: swing.pose,
      centerOfMassVelocity: add(
        swing.linearVelocity,
        cross(
          swing.angularVelocity,
          gripToCenterOfMass
        )
      ),
      angularVelocity: swing.angularVelocity,
      physical: physical2
    };
  };
  var measureRigidBatBallSurfaceSeparation = (pitch, bat, ball) => {
    validateBat(bat);
    validateBall(ball);
    const nearest = closestPointOnTaperedBat(
      pitch.position,
      bat
    );
    return nearest.surfaceSeparationM - ball.radiusM;
  };
  var prepareRigidBatBallContact = (pitch, bat, ball) => {
    validateBat(bat);
    validateBall(ball);
    const { axis: batAxis } = axisGeometry(bat.pose);
    const nearest = closestPointOnTaperedBat(
      pitch.position,
      bat
    );
    const localBatRadiusM = nearest.localRadiusM;
    if (nearest.surfaceSeparationM > ball.radiusM) {
      return null;
    }
    const axisToBall = subtract(
      pitch.position,
      nearest.point
    );
    const centerDistance = magnitude(axisToBall);
    const centerOfMass = batCenterOfMassPoint(bat);
    const fallbackRelative = subtract(
      pitch.velocity,
      bat.centerOfMassVelocity
    );
    const normal = centerDistance > EPSILON ? scale(
      axisToBall,
      1 / centerDistance
    ) : normalize(
      scale(
        fallbackRelative,
        -1
      )
    );
    const batSurfacePoint = add(
      nearest.point,
      scale(
        normal,
        localBatRadiusM
      )
    );
    const ballSurfacePoint = add(
      pitch.position,
      scale(
        normal,
        -ball.radiusM
      )
    );
    const batLeverArm = subtract(
      batSurfacePoint,
      centerOfMass
    );
    const ballLeverArm = subtract(
      ballSurfacePoint,
      pitch.position
    );
    const state = {
      ballVelocity: pitch.velocity,
      ballSpin: pitch.spin,
      batVelocity: bat.centerOfMassVelocity,
      batAngularVelocity: bat.angularVelocity
    };
    const relativeBefore = relativeSurfaceVelocity(
      state,
      ballLeverArm,
      batLeverArm
    );
    const normalRelativeSpeed = dot(
      relativeBefore,
      normal
    );
    if (normalRelativeSpeed >= 0) {
      return null;
    }
    const tangentBefore = subtract(
      relativeBefore,
      scale(
        normal,
        normalRelativeSpeed
      )
    );
    const tangentialRelativeSpeedBeforeMps = magnitude(tangentBefore);
    return {
      kinematics: {
        tick: pitch.tick,
        segmentT: nearest.t,
        localBatRadiusM,
        normal,
        batSurfacePoint,
        ballSurfacePoint,
        relativeSurfaceVelocityBefore: relativeBefore,
        totalRelativeSurfaceSpeedMps: magnitude(relativeBefore),
        normalRelativeSpeedBeforeMps: normalRelativeSpeed,
        normalApproachSpeedMps: -normalRelativeSpeed,
        tangentialRelativeSpeedBeforeMps
      },
      batAxis,
      batLeverArm,
      ballLeverArm,
      state
    };
  };
  var resolveRigidBatBallContactWithParameterResolver = (pitch, bat, ball, parameterResolver) => {
    const prepared = prepareRigidBatBallContact(
      pitch,
      bat,
      ball
    );
    if (prepared === null) {
      return null;
    }
    const {
      kinematics,
      batAxis,
      batLeverArm,
      ballLeverArm,
      state
    } = prepared;
    const parameters = parameterResolver(kinematics);
    validateContactParameters(
      parameters
    );
    const rigidBatNormalInverseMass = rigidBatInverseMassContributionAlong(
      kinematics.normal,
      batLeverArm,
      bat,
      batAxis
    );
    const rigidBatNormalEffectiveMassKg = 1 / rigidBatNormalInverseMass;
    const dynamicProfile = bat.physical.normalEffectiveMassProfile;
    const batNormalEffectiveMassKg = dynamicProfile === void 0 ? rigidBatNormalEffectiveMassKg : sampleBatEffectiveMass(
      dynamicProfile,
      kinematics.segmentT
    );
    const normalEffectiveMassSource = dynamicProfile === void 0 ? "rigid_body" : "dynamic_profile";
    const normalInverseMass = ballInverseMassContributionAlong(
      kinematics.normal,
      ballLeverArm,
      ball
    ) + 1 / batNormalEffectiveMassKg;
    if (normalInverseMass <= EPSILON) {
      throw new Error(
        "normal effective inverse mass must be positive"
      );
    }
    const normalImpulseNs = -(1 + parameters.normalRestitution) * kinematics.normalRelativeSpeedBeforeMps / normalInverseMass;
    const normalImpulse = scale(
      kinematics.normal,
      normalImpulseNs
    );
    applyImpulse(
      state,
      normalImpulse,
      ballLeverArm,
      batLeverArm,
      ball,
      bat,
      batAxis
    );
    let tangentialImpulseNs = {
      x: 0,
      y: 0,
      z: 0
    };
    if (parameters.frictionCoefficient > 0 && kinematics.tangentialRelativeSpeedBeforeMps > EPSILON) {
      const relativeAfterNormal = relativeSurfaceVelocity(
        state,
        ballLeverArm,
        batLeverArm
      );
      const normalAfterNormal = dot(
        relativeAfterNormal,
        kinematics.normal
      );
      const tangentAfterNormal = subtract(
        relativeAfterNormal,
        scale(
          kinematics.normal,
          normalAfterNormal
        )
      );
      const tangentSpeedAfterNormal = magnitude(tangentAfterNormal);
      if (tangentSpeedAfterNormal > EPSILON) {
        const tangentDirection = scale(
          tangentAfterNormal,
          1 / tangentSpeedAfterNormal
        );
        const tangentialInverseMass = effectiveInverseMassAlong(
          tangentDirection,
          ballLeverArm,
          batLeverArm,
          ball,
          bat,
          batAxis
        );
        if (tangentialInverseMass <= EPSILON) {
          throw new Error(
            "tangential effective inverse mass must be positive"
          );
        }
        const targetImpulseMagnitude = (1 + parameters.tangentialRestitution) * tangentSpeedAfterNormal / tangentialInverseMass;
        const frictionLimit = parameters.frictionCoefficient * normalImpulseNs;
        const tangentialImpulseMagnitude = Math.min(
          targetImpulseMagnitude,
          frictionLimit
        );
        tangentialImpulseNs = scale(
          tangentDirection,
          -tangentialImpulseMagnitude
        );
        applyImpulse(
          state,
          tangentialImpulseNs,
          ballLeverArm,
          batLeverArm,
          ball,
          bat,
          batAxis
        );
      }
    }
    const totalImpulseNs = add(
      normalImpulse,
      tangentialImpulseNs
    );
    return {
      tick: kinematics.tick,
      ballCenter: pitch.position,
      segmentT: kinematics.segmentT,
      localBatRadiusM: kinematics.localBatRadiusM,
      normal: kinematics.normal,
      batSurfacePoint: kinematics.batSurfacePoint,
      ballSurfacePoint: kinematics.ballSurfacePoint,
      normalRelativeSpeedBeforeMps: kinematics.normalRelativeSpeedBeforeMps,
      tangentialRelativeSpeedBeforeMps: kinematics.tangentialRelativeSpeedBeforeMps,
      normalImpulseNs,
      tangentialImpulseNs,
      totalImpulseNs,
      effectiveNormalMassKg: 1 / normalInverseMass,
      batNormalEffectiveMassKg,
      normalEffectiveMassSource,
      batRecoilModel: normalEffectiveMassSource === "rigid_body" ? "rigid_body" : "rigid_projection_only",
      exitVelocity: state.ballVelocity,
      exitSpin: state.ballSpin,
      batExitCenterOfMassVelocity: state.batVelocity,
      batExitAngularVelocity: state.batAngularVelocity
    };
  };

  // src/core/sim/contact/SwingKinematicsV1.ts
  var SWING_KINEMATICS_V1_VERSION = "swing-kinematics-v1";
  var EPSILON2 = 1e-12;
  var add2 = (first, second) => ({
    x: first.x + second.x,
    y: first.y + second.y,
    z: first.z + second.z
  });
  var subtract2 = (first, second) => ({
    x: first.x - second.x,
    y: first.y - second.y,
    z: first.z - second.z
  });
  var scale2 = (value, scalar) => ({
    x: value.x * scalar,
    y: value.y * scalar,
    z: value.z * scalar
  });
  var dot2 = (first, second) => first.x * second.x + first.y * second.y + first.z * second.z;
  var cross2 = (first, second) => ({
    x: first.y * second.z - first.z * second.y,
    y: first.z * second.x - first.x * second.z,
    z: first.x * second.y - first.y * second.x
  });
  var magnitude2 = (value) => Math.hypot(
    value.x,
    value.y,
    value.z
  );
  var validateVec3 = (name, value) => {
    for (const component of [
      value.x,
      value.y,
      value.z
    ]) {
      if (!Number.isFinite(component)) {
        throw new Error(
          `${name} must contain only finite values`
        );
      }
    }
  };
  var validateTrajectory = (trajectory) => {
    if (trajectory.version !== SWING_KINEMATICS_V1_VERSION) {
      throw new Error(
        "unsupported swing kinematics trajectory version"
      );
    }
    if (!Number.isSafeInteger(
      trajectory.startTick
    ) || !Number.isSafeInteger(
      trajectory.contactTick
    ) || !Number.isSafeInteger(
      trajectory.endTick
    ) || trajectory.startTick >= trajectory.contactTick || trajectory.contactTick >= trajectory.endTick) {
      throw new Error(
        "swing kinematics ticks must be safe integers with start < contact < end"
      );
    }
    if (!Number.isSafeInteger(
      trajectory.ticksPerSecond
    ) || trajectory.ticksPerSecond <= 0) {
      throw new Error(
        "swing kinematics ticksPerSecond must be a positive safe integer"
      );
    }
    if (!Number.isFinite(
      trajectory.batLengthM
    ) || trajectory.batLengthM <= 0) {
      throw new Error(
        "swing kinematics batLengthM must be finite and positive"
      );
    }
    if (!Number.isFinite(
      trajectory.sweetSpotT
    ) || trajectory.sweetSpotT <= 0 || trajectory.sweetSpotT >= 1) {
      throw new Error(
        "swing kinematics sweetSpotT must lie strictly within (0, 1)"
      );
    }
    for (const [
      name,
      knot
    ] of [
      ["start", trajectory.start],
      ["contact", trajectory.contact],
      ["finish", trajectory.finish]
    ]) {
      validateVec3(
        `${name}.sweetSpotPosition`,
        knot.sweetSpotPosition
      );
      validateVec3(
        `${name}.sweetSpotVelocity`,
        knot.sweetSpotVelocity
      );
      validateVec3(
        `${name}.batAxis`,
        knot.batAxis
      );
      validateVec3(
        `${name}.batAxisDerivative`,
        knot.batAxisDerivative
      );
      const axisLength = magnitude2(knot.batAxis);
      if (Math.abs(axisLength - 1) > 1e-9) {
        throw new Error(
          `${name}.batAxis must be normalized`
        );
      }
      if (Math.abs(
        dot2(
          knot.batAxis,
          knot.batAxisDerivative
        )
      ) > 1e-8) {
        throw new Error(
          `${name}.batAxisDerivative must be tangent to batAxis`
        );
      }
    }
  };
  var sampleHermite = (startValue, startDerivativePerSecond, endValue, endDerivativePerSecond, durationSeconds, u) => {
    const clamped = Math.max(
      0,
      Math.min(1, u)
    );
    const u2 = clamped * clamped;
    const u3 = u2 * clamped;
    const h00 = 2 * u3 - 3 * u2 + 1;
    const h10 = u3 - 2 * u2 + clamped;
    const h01 = -2 * u3 + 3 * u2;
    const h11 = u3 - u2;
    const value = add2(
      add2(
        scale2(
          startValue,
          h00
        ),
        scale2(
          startDerivativePerSecond,
          h10 * durationSeconds
        )
      ),
      add2(
        scale2(
          endValue,
          h01
        ),
        scale2(
          endDerivativePerSecond,
          h11 * durationSeconds
        )
      )
    );
    const dh00 = 6 * u2 - 6 * clamped;
    const dh10 = 3 * u2 - 4 * clamped + 1;
    const dh01 = -6 * u2 + 6 * clamped;
    const dh11 = 3 * u2 - 2 * clamped;
    const derivativePerU = add2(
      add2(
        scale2(
          startValue,
          dh00
        ),
        scale2(
          startDerivativePerSecond,
          dh10 * durationSeconds
        )
      ),
      add2(
        scale2(
          endValue,
          dh01
        ),
        scale2(
          endDerivativePerSecond,
          dh11 * durationSeconds
        )
      )
    );
    return {
      value,
      derivativePerSecond: scale2(
        derivativePerU,
        1 / durationSeconds
      )
    };
  };
  var normalizeWithDerivative = (value, derivativePerSecond) => {
    const length = magnitude2(value);
    if (!Number.isFinite(length) || length <= EPSILON2) {
      throw new Error(
        "swing kinematics interpolated bat axis collapsed to zero"
      );
    }
    const axis = scale2(
      value,
      1 / length
    );
    const tangent = subtract2(
      derivativePerSecond,
      scale2(
        axis,
        dot2(
          axis,
          derivativePerSecond
        )
      )
    );
    return {
      axis,
      derivativePerSecond: scale2(
        tangent,
        1 / length
      )
    };
  };
  var sampleSegment = (start, end, startTick, endTick, sampleTick, ticksPerSecond) => {
    const durationTicks = endTick - startTick;
    const durationSeconds = durationTicks / ticksPerSecond;
    const u = (sampleTick - startTick) / durationTicks;
    const sweetSpot = sampleHermite(
      start.sweetSpotPosition,
      start.sweetSpotVelocity,
      end.sweetSpotPosition,
      end.sweetSpotVelocity,
      durationSeconds,
      u
    );
    const axisRaw = sampleHermite(
      start.batAxis,
      start.batAxisDerivative,
      end.batAxis,
      end.batAxisDerivative,
      durationSeconds,
      u
    );
    const axis = normalizeWithDerivative(
      axisRaw.value,
      axisRaw.derivativePerSecond
    );
    return {
      sweetSpotPosition: sweetSpot.value,
      sweetSpotVelocity: sweetSpot.derivativePerSecond,
      batAxis: axis.axis,
      batAxisDerivative: axis.derivativePerSecond
    };
  };
  var sampleSwingKinematicsV1 = (trajectory, tick2) => {
    validateTrajectory(
      trajectory
    );
    if (!Number.isSafeInteger(tick2) || tick2 < trajectory.startTick || tick2 > trajectory.endTick) {
      throw new Error(
        "swing kinematics sample tick must lie within the trajectory interval"
      );
    }
    const phase = tick2 < trajectory.contactTick ? "pre_contact" : tick2 === trajectory.contactTick ? "contact" : "follow_through";
    const sampled = tick2 <= trajectory.contactTick ? sampleSegment(
      trajectory.start,
      trajectory.contact,
      trajectory.startTick,
      trajectory.contactTick,
      tick2,
      trajectory.ticksPerSecond
    ) : sampleSegment(
      trajectory.contact,
      trajectory.finish,
      trajectory.contactTick,
      trajectory.endTick,
      tick2,
      trajectory.ticksPerSecond
    );
    const grip = subtract2(
      sampled.sweetSpotPosition,
      scale2(
        sampled.batAxis,
        trajectory.batLengthM * trajectory.sweetSpotT
      )
    );
    const tip = add2(
      grip,
      scale2(
        sampled.batAxis,
        trajectory.batLengthM
      )
    );
    const gripVelocity = subtract2(
      sampled.sweetSpotVelocity,
      scale2(
        sampled.batAxisDerivative,
        trajectory.batLengthM * trajectory.sweetSpotT
      )
    );
    const angularVelocity = cross2(
      sampled.batAxis,
      sampled.batAxisDerivative
    );
    return {
      tick: tick2,
      phase,
      sweetSpotPosition: sampled.sweetSpotPosition,
      sweetSpotVelocity: sampled.sweetSpotVelocity,
      batAxis: sampled.batAxis,
      batAxisDerivative: sampled.batAxisDerivative,
      swingState: {
        pose: {
          grip,
          tip
        },
        linearVelocity: gripVelocity,
        angularVelocity
      }
    };
  };
  var sampleSwingStateV1 = (trajectory, tick2) => sampleSwingKinematicsV1(
    trajectory,
    tick2
  ).swingState;

  // src/core/sim/pitching/CourseAwareSwingKinematicsV1.ts
  var INCH_TO_M = 0.0254;
  var EVIDENCE_BOUNDED_SWING_COURSE_PROFILE_V1 = Object.freeze({
    profileId: "evidence-bounded-population-swing",
    version: "swing-course-profile-v1",
    batLengthM: 0.84,
    sweetSpotT: 0.72,
    centerContactDepthM: 20.1 * INCH_TO_M,
    contactDepthPopulationStdDevM: 7.2 * INCH_TO_M,
    insideOutsideDepthGainM: 0.075,
    heightDepthGainM: 0.035,
    baseContactSweetSpotSpeedMps: 31,
    contactDepthSpeedGainMpsPerM: 4,
    basePreContactSeconds: 0.165,
    insideOutsideTimingGainSeconds: 0.01,
    heightTimingGainSeconds: 4e-3,
    followThroughSeconds: 0.135,
    highAttackAngleDeg: 7,
    middleAttackAngleDeg: 9,
    lowAttackAngleDeg: 16,
    courseAttackDirectionGainDeg: 6,
    nominalContactSurfaceDistanceM: 0.0366 + 0.033
  });

  // src/integration/browser/WorkbenchPlayer.ts
  var WORKBENCH_TICKS_PER_SECOND = 1e6;
  var leagues = ["NPB", "MLB", "NLB", "KBO", "CUSTOM"];
  var freeze = (value) => {
    if (value !== null && typeof value === "object") {
      Object.values(value).forEach(freeze);
      Object.freeze(value);
    }
    return value;
  };
  var fields = (value, keys, path) => {
    if (value === null || typeof value !== "object" || Array.isArray(value) || Object.keys(value).sort().join("|") !== [...keys].sort().join("|")) throw new Error(`invalid workbench fields: ${path}`);
  };
  var text = (value, path) => {
    if (typeof value !== "string" || !value.length || value.trim() !== value || value.length > 160) throw new Error(`invalid workbench text: ${path}`);
  };
  var range = (value, low, high, path) => {
    if (!Number.isFinite(value) || value < low || value > high) throw new Error(`invalid workbench range: ${path}`);
  };
  var ticks = (value, low, high, path) => {
    range(value, low, high, path);
    if (!Number.isSafeInteger(value)) throw new Error(`workbench ticks must be integers: ${path}`);
  };
  function createWorkbenchPlayer(raw) {
    const player = cloneInert(raw);
    fields(player, ["schemaVersion", "identity", "body", "capability", "bat", "swing", "decision", "traits"], "player");
    if (player.schemaVersion !== 1) throw new Error("unsupported workbench player schema");
    fields(player.identity, ["playerId", "name", "leagueId", "bats", "throws"], "identity");
    text(player.identity.playerId, "playerId");
    text(player.identity.name, "name");
    if (!leagues.includes(player.identity.leagueId) || !["R", "L"].includes(player.identity.bats) || !["R", "L"].includes(player.identity.throws)) throw new Error("invalid workbench identity");
    fields(player.body, ["heightMeters", "massKg"], "body");
    range(player.body.heightMeters, 0.8, 3, "heightMeters");
    range(player.body.massKg, 15, 300, "body.massKg");
    fields(player.capability, [
      "maximumSweetSpotSpeedMps",
      "motorLatencyTicks",
      "technicalTimingOffsetTicks",
      "runSpeedMps",
      "throwSpeedMps",
      "pitchSpeedMps",
      "positionErrorMeters",
      "timingErrorTicks"
    ], "capability");
    const c = player.capability;
    range(c.maximumSweetSpotSpeedMps, 0.1, 90, "maximumSweetSpotSpeedMps");
    ticks(c.motorLatencyTicks, 1, 2e6, "motorLatencyTicks");
    ticks(c.technicalTimingOffsetTicks, -5e5, 5e5, "technicalTimingOffsetTicks");
    range(c.runSpeedMps, 0.1, 20, "runSpeedMps");
    range(c.throwSpeedMps, 0.1, 80, "throwSpeedMps");
    range(c.pitchSpeedMps, 0.1, 80, "pitchSpeedMps");
    range(c.positionErrorMeters, 0, 1, "positionErrorMeters");
    ticks(c.timingErrorTicks, 0, 5e5, "timingErrorTicks");
    fields(player.bat, ["lengthM", "massKg", "sweetSpotT"], "bat");
    range(player.bat.lengthM, 0.2, 1.5, "bat.lengthM");
    range(player.bat.massKg, 0.05, 3, "bat.massKg");
    range(player.bat.sweetSpotT, 0.65, 0.9, "sweetSpotT (declared barrel reference)");
    fields(player.swing, [
      "speedMps",
      "attackAngleDeg",
      "pullAngleDeg",
      "preContactSeconds",
      "followThroughSeconds",
      "contactDepthM",
      "loadAngleDeg",
      "finishAngleDeg",
      "handTravelM"
    ], "swing");
    const s = player.swing;
    range(s.speedMps, 0.1, c.maximumSweetSpotSpeedMps, "swing speed envelope");
    range(s.attackAngleDeg, -80, 80, "attackAngleDeg");
    range(s.pullAngleDeg, -80, 80, "pullAngleDeg");
    range(s.preContactSeconds, 5e-3, 2, "preContactSeconds");
    range(s.followThroughSeconds, 5e-3, 2, "followThroughSeconds");
    range(s.contactDepthM, 1e-3, 2, "contactDepthM");
    range(s.loadAngleDeg, -179, 179, "loadAngleDeg");
    range(s.finishAngleDeg, -179, 179, "finishAngleDeg");
    range(s.handTravelM, 0, 1, "handTravelM");
    fields(player.decision, ["threshold", "aggressionWeight", "approach"], "decision");
    range(player.decision.threshold, 0, 1, "threshold");
    range(player.decision.aggressionWeight, 0, 1, "aggressionWeight");
    if (!["AUTO", "TAKE", "SWING"].includes(player.decision.approach)) throw new Error("invalid workbench approach");
    fields(player.traits, ["badBallControl", "labels"], "traits");
    range(player.traits.badBallControl, 0, 1, "badBallControl");
    if (!Array.isArray(player.traits.labels) || player.traits.labels.length > 32) throw new Error("invalid workbench trait labels");
    player.traits.labels.forEach((label) => text(label, "trait label"));
    if (new Set(player.traits.labels).size !== player.traits.labels.length) throw new Error("duplicate workbench trait label");
    return freeze(player);
  }
  function defaultWorkbenchPlayer() {
    const profile = EVIDENCE_BOUNDED_SWING_COURSE_PROFILE_V1;
    return createWorkbenchPlayer({
      schemaVersion: 1,
      identity: { playerId: "workbench-new-player", name: "\u65B0\u898F\u9078\u624B", leagueId: "CUSTOM", bats: "R", throws: "R" },
      body: { heightMeters: 1.8, massKg: 80 },
      capability: {
        maximumSweetSpotSpeedMps: 45,
        motorLatencyTicks: 14e4,
        technicalTimingOffsetTicks: 0,
        runSpeedMps: 7,
        throwSpeedMps: 35,
        pitchSpeedMps: 40,
        positionErrorMeters: 6e-3,
        timingErrorTicks: 8e3
      },
      bat: { lengthM: profile.batLengthM, massKg: 0.9, sweetSpotT: profile.sweetSpotT },
      swing: {
        speedMps: profile.baseContactSweetSpotSpeedMps,
        attackAngleDeg: profile.middleAttackAngleDeg,
        pullAngleDeg: 0,
        preContactSeconds: profile.basePreContactSeconds,
        followThroughSeconds: profile.followThroughSeconds,
        contactDepthM: profile.centerContactDepthM,
        loadAngleDeg: -70,
        finishAngleDeg: 65,
        handTravelM: 0.22
      },
      decision: { threshold: 0.5, aggressionWeight: 0.5, approach: "AUTO" },
      traits: { badBallControl: 0, labels: [] }
    });
  }
  var metrics = [
    { key: "maximumSweetSpotSpeedMps", label: "\u82AF\u306E\u6700\u5927\u901F\u5EA6", unit: "m/s", direction: 1, value: (p) => p.capability.maximumSweetSpotSpeedMps },
    { key: "swingSpeedMps", label: "\u8A2D\u5B9A\u30B9\u30A4\u30F3\u30B0\u901F\u5EA6", unit: "m/s", direction: 1, value: (p) => p.swing.speedMps },
    { key: "runSpeedMps", label: "\u8D70\u901F\u5EA6", unit: "m/s", direction: 1, value: (p) => p.capability.runSpeedMps },
    { key: "throwSpeedMps", label: "\u9001\u7403\u521D\u901F", unit: "m/s", direction: 1, value: (p) => p.capability.throwSpeedMps },
    { key: "pitchSpeedMps", label: "\u6295\u7403\u521D\u901F", unit: "m/s", direction: 1, value: (p) => p.capability.pitchSpeedMps },
    { key: "positionErrorMeters", label: "\u4F4D\u7F6E\u8AA4\u5DEE", unit: "m", direction: -1, value: (p) => p.capability.positionErrorMeters },
    { key: "timingErrorTicks", label: "\u30BF\u30A4\u30DF\u30F3\u30B0\u8AA4\u5DEE", unit: "tick", direction: -1, value: (p) => p.capability.timingErrorTicks },
    { key: "motorLatencyTicks", label: "\u904B\u52D5\u9045\u5EF6", unit: "tick", direction: -1, value: (p) => p.capability.motorLatencyTicks }
  ];
  function previewLeagueRatings(rawPlayer, population, leagueId) {
    const player = createWorkbenchPlayer(rawPlayer);
    if (!leagues.includes(leagueId) || !Array.isArray(population)) throw new Error("invalid workbench preview population");
    const members = population.map(createWorkbenchPlayer);
    if (new Set(members.map((p) => p.identity.playerId)).size !== members.length) throw new Error("duplicate workbench population player");
    const cohort = members.filter((p) => p.identity.leagueId === leagueId);
    const projected = metrics.map((metric) => {
      let mean = 0, variance = 0;
      cohort.forEach((member, index) => {
        const value = metric.value(member), delta = value - mean;
        mean += delta / (index + 1);
        variance += delta * (value - mean);
      });
      const stddev = cohort.length ? Math.sqrt(Math.max(0, variance / cohort.length)) : null;
      const actual = metric.value(player);
      const rating = cohort.length >= 2 && stddev !== null && stddev > 0 ? Math.max(0, Math.min(100, 50 + 20 * metric.direction * (actual - mean) / stddev)) : null;
      return {
        key: metric.key,
        label: metric.label,
        unit: metric.unit,
        actual,
        mean: cohort.length ? mean : null,
        stddev,
        rating
      };
    });
    return freeze({
      leagueId,
      sampleCount: cohort.length,
      available: projected.some((metric) => metric.rating !== null),
      policyId: "workbench-population-preview-v1",
      metrics: projected
    });
  }
  function exportWorkbenchPlayerSources(raw) {
    const player = createWorkbenchPlayer(raw);
    const radiusProfile = { knots: [
      { t: 0, radiusM: 0.024 },
      { t: 0.04, radiusM: 0.014 },
      { t: 0.3, radiusM: 0.018 },
      { t: 0.65, radiusM: 0.03 },
      { t: 0.78, radiusM: 0.033 },
      { t: 1, radiusM: 0.012 }
    ] };
    const slices = Array.from({ length: 256 }, (_, index) => {
      const t = (index + 0.5) / 256, radiusM = sampleBatRadius(radiusProfile, t);
      return { t, radiusM, weight: radiusM * radiusM };
    });
    const total = slices.reduce((sum, slice) => sum + slice.weight, 0);
    const centerOfMassT = slices.reduce((sum, slice) => sum + slice.t * slice.weight, 0) / total;
    const transverseMomentOfInertiaKgM2 = slices.reduce((sum, slice) => sum + player.bat.massKg * slice.weight / total * (((slice.t - centerOfMassT) * player.bat.lengthM) ** 2 + slice.radiusM ** 2 / 4 + (player.bat.lengthM / 256) ** 2 / 12), 0);
    const axialMomentOfInertiaKgM2 = slices.reduce((sum, slice) => sum + player.bat.massKg * slice.weight / total * slice.radiusM ** 2 / 2, 0);
    const reference = EVIDENCE_BOUNDED_SWING_COURSE_PROFILE_V1;
    return freeze({
      boundary: "AUTHORING_VALUES_NOT_ACCEPTED_NATIVE_SOURCE",
      ticksPerSecond: WORKBENCH_TICKS_PER_SECOND,
      capability: {
        motorLatencyTicks: player.capability.motorLatencyTicks,
        technicalTimingOffsetTicks: player.capability.technicalTimingOffsetTicks,
        maximumSweetSpotSpeedMps: player.capability.maximumSweetSpotSpeedMps
      },
      repertoire: { repertoireId: "workbench-authored-swing", repertoireVersion: "workbench-player-v1", profiles: [{
        minimumAggression: 0,
        profile: {
          ...reference,
          profileId: "workbench-authored-course",
          version: "workbench-player-v1",
          batLengthM: player.bat.lengthM,
          sweetSpotT: player.bat.sweetSpotT,
          centerContactDepthM: player.swing.contactDepthM,
          baseContactSweetSpotSpeedMps: player.swing.speedMps,
          contactDepthSpeedGainMpsPerM: 0,
          basePreContactSeconds: player.swing.preContactSeconds,
          followThroughSeconds: player.swing.followThroughSeconds,
          highAttackAngleDeg: player.swing.attackAngleDeg,
          middleAttackAngleDeg: player.swing.attackAngleDeg,
          lowAttackAngleDeg: player.swing.attackAngleDeg,
          courseAttackDirectionGainDeg: player.swing.pullAngleDeg
        }
      }] },
      decision: {
        modelId: "workbench-authored-decision",
        version: "workbench-player-v1",
        threshold: player.decision.threshold,
        aggressionWeight: player.decision.aggressionWeight
      },
      equipment: { batPhysical: {
        massKg: player.bat.massKg,
        centerOfMassT,
        transverseMomentOfInertiaKgM2,
        axialMomentOfInertiaKgM2,
        radiusProfile
      }, ball: { ...REALISTIC_BASEBALL_RIGID_BODY } },
      authoring: player
    });
  }

  // src/core/sim/contact/HighSpeedObliqueBatCalibration.ts
  var NATHAN_2012_HIGH_SPEED_OBLIQUE_WOOD_CONTACT = Object.freeze({
    normalRestitution: 0.52,
    tangentialRestitution: 0.3,
    frictionCoefficient: 0.15
  });
  var NATHAN_2012_OBLIQUE_WOOD_EVIDENCE = Object.freeze({
    maximumIncidentSpeedMph: 120,
    nonSlipNormalRestitution: 0.52,
    nonSlipTangentialRestitution: 0.3,
    tangentialRestitutionUncertainty: 0.02,
    grossSlipFrictionCoefficient: 0.15,
    grossSlipOnsetAngleDegreesApprox: 40,
    source: "Nathan et al. 2012, Spin of a batted baseball"
  });

  // src/core/sim/contact/WoodBatProductionProfileV1.ts
  var MPH_TO_MPS = 0.44704;
  var NATHAN_2012_WOOD_LOCAL_CONTACT_PROFILE_V1 = Object.freeze({
    profileId: "nathan-2012-rigid-wood-local-contact",
    version: "nathan-2012-47-impact-fit-v1",
    normalRestitutionKnots: Object.freeze([
      {
        relativeImpactSpeedMps: 85 * MPH_TO_MPS,
        normalRestitution: NATHAN_2012_HIGH_SPEED_OBLIQUE_WOOD_CONTACT.normalRestitution
      },
      {
        relativeImpactSpeedMps: 120 * MPH_TO_MPS,
        normalRestitution: NATHAN_2012_HIGH_SPEED_OBLIQUE_WOOD_CONTACT.normalRestitution
      }
    ]),
    tangentialRestitution: NATHAN_2012_HIGH_SPEED_OBLIQUE_WOOD_CONTACT.tangentialRestitution,
    frictionCoefficient: NATHAN_2012_HIGH_SPEED_OBLIQUE_WOOD_CONTACT.frictionCoefficient,
    evidenceIds: Object.freeze([
      "nathan-2012-spin-of-a-batted-baseball",
      "nathan-2012-rigid-three-inch-wood-cylinder-47-impact-fit"
    ])
  });
  var NATHAN_2012_WOOD_LOCAL_CONTACT_PROFILE_SCOPE = Object.freeze({
    minimumDocumentedIncidentSpeedMph: 85,
    maximumDocumentedIncidentSpeedMph: NATHAN_2012_OBLIQUE_WOOD_EVIDENCE.maximumIncidentSpeedMph,
    fittedNonGrossSlipImpactCount: 47,
    fixture: "rigidly-mounted-three-inch-wood-cylinder",
    finiteBatDynamics: "handled-by-rigid-bat-ball-contact"
  });

  // src/core/sim/contact/WoodBatSpeedResponseProfile.ts
  var HIRONO_2025_WOOD_BAT_SPEED_RESPONSE_EVIDENCE = Object.freeze({
    source: "Hirono, Murata & Nakamura 2025, Journal of the Society of Materials Science, Japan 74(9):582-587",
    testedImpactSpeedComparisonKph: Object.freeze([
      120,
      180
    ]),
    finding: "BBCOR generally decreased as impact velocity increased, but the rate of decrease differed by wooden bat; some tested bats did not decrease monotonically through 180 km/h.",
    implication: "Wood-bat speed response must remain bat/profile-specific; a universal v^(-1/6) wooden-bat law is not justified by this evidence."
  });
  var lerp = (a, b, t) => a + (b - a) * t;
  var validateWoodBatSpeedResponseProfile = (profile) => {
    if (profile.profileId.length === 0 || profile.version.length === 0) {
      throw new Error(
        "wood-bat speed response profile id/version must not be empty"
      );
    }
    if (profile.normalRestitutionKnots.length < 2) {
      throw new Error(
        "wood-bat speed response requires at least two same-profile speed knots"
      );
    }
    if (profile.evidenceIds.length === 0 || profile.evidenceIds.some(
      (id) => id.length === 0
    )) {
      throw new Error(
        "wood-bat speed response requires explicit evidence ids"
      );
    }
    if (!Number.isFinite(
      profile.tangentialRestitution
    ) || profile.tangentialRestitution < 0 || profile.tangentialRestitution > 1 || !Number.isFinite(
      profile.frictionCoefficient
    ) || profile.frictionCoefficient < 0) {
      throw new Error(
        "wood-bat tangential restitution must be within [0,1] and friction non-negative"
      );
    }
    let previousSpeed = -Infinity;
    for (const knot of profile.normalRestitutionKnots) {
      if (!Number.isFinite(
        knot.relativeImpactSpeedMps
      ) || knot.relativeImpactSpeedMps <= 0 || knot.relativeImpactSpeedMps <= previousSpeed || !Number.isFinite(
        knot.normalRestitution
      ) || knot.normalRestitution < 0 || knot.normalRestitution > 1) {
        throw new Error(
          "wood-bat restitution knots must use strictly increasing positive speed and restitution within [0,1]"
        );
      }
      previousSpeed = knot.relativeImpactSpeedMps;
    }
  };
  var resolveWoodBatSpeedResponse = (profile, relativeImpactSpeedMps) => {
    validateWoodBatSpeedResponseProfile(
      profile
    );
    if (!Number.isFinite(
      relativeImpactSpeedMps
    ) || relativeImpactSpeedMps < 0) {
      throw new Error(
        "wood-bat impact speed must be finite and non-negative"
      );
    }
    const knots = profile.normalRestitutionKnots;
    const first = knots[0];
    const last = knots[knots.length - 1];
    let normalRestitution = first.normalRestitution;
    if (relativeImpactSpeedMps >= last.relativeImpactSpeedMps) {
      normalRestitution = last.normalRestitution;
    } else if (relativeImpactSpeedMps > first.relativeImpactSpeedMps) {
      for (let index = 1; index < knots.length; index += 1) {
        const right = knots[index];
        if (relativeImpactSpeedMps > right.relativeImpactSpeedMps) {
          continue;
        }
        const left = knots[index - 1];
        const t = (relativeImpactSpeedMps - left.relativeImpactSpeedMps) / (right.relativeImpactSpeedMps - left.relativeImpactSpeedMps);
        normalRestitution = lerp(
          left.normalRestitution,
          right.normalRestitution,
          t
        );
        break;
      }
    }
    return {
      normalRestitution,
      tangentialRestitution: profile.tangentialRestitution,
      frictionCoefficient: profile.frictionCoefficient
    };
  };

  // src/core/sim/ball/BaseballSpinDecay.ts
  var NATHAN_2026_BASEBALL_SPIN_DECAY_ESTIMATE = Object.freeze({
    referenceSpeedMps: 44.704,
    timeConstantSecondsAtReferenceSpeed: 20
  });
  var magnitude3 = (value) => Math.hypot(
    value.x,
    value.y,
    value.z
  );
  var scale3 = (value, scalar) => ({
    x: value.x * scalar,
    y: value.y * scalar,
    z: value.z * scalar
  });
  var validateBaseballSpinDecayParameters = (parameters) => {
    if (!Number.isFinite(
      parameters.referenceSpeedMps
    ) || parameters.referenceSpeedMps <= 0 || !Number.isFinite(
      parameters.timeConstantSecondsAtReferenceSpeed
    ) || parameters.timeConstantSecondsAtReferenceSpeed <= 0) {
      throw new Error(
        "baseball spin-decay reference speed and time constant must be finite and positive"
      );
    }
  };
  var calculateBaseballSpinDecayTimeConstantSeconds = (airRelativeSpeedMps, parameters = NATHAN_2026_BASEBALL_SPIN_DECAY_ESTIMATE) => {
    validateBaseballSpinDecayParameters(
      parameters
    );
    if (!Number.isFinite(
      airRelativeSpeedMps
    ) || airRelativeSpeedMps < 0) {
      throw new Error(
        "airRelativeSpeedMps must be finite and non-negative"
      );
    }
    if (airRelativeSpeedMps <= 1e-12) {
      return Infinity;
    }
    return parameters.timeConstantSecondsAtReferenceSpeed * parameters.referenceSpeedMps / airRelativeSpeedMps;
  };
  var calculateBaseballSpinDecayDerivative = (spinRadPerSecond, airRelativeVelocityMps, parameters) => {
    const speed = magnitude3(
      airRelativeVelocityMps
    );
    const tau = calculateBaseballSpinDecayTimeConstantSeconds(
      speed,
      parameters
    );
    if (!Number.isFinite(tau)) {
      return {
        x: 0,
        y: 0,
        z: 0
      };
    }
    return scale3(
      spinRadPerSecond,
      -1 / tau
    );
  };

  // src/core/sim/ball/BaseballAerodynamicCoefficientProfile.ts
  var lerp2 = (a, b, t) => a + (b - a) * t;
  var validateAscending = (name, values) => {
    for (let index = 1; index < values.length; index += 1) {
      if (!(values[index] > values[index - 1])) {
        throw new Error(
          `${name} must be strictly increasing`
        );
      }
    }
  };
  var validateBaseballAerodynamicCoefficientProfile = (profile) => {
    if (profile.profileId.length === 0 || profile.version.length === 0) {
      throw new Error(
        "aerodynamic coefficient profile id/version must not be empty"
      );
    }
    if (!Number.isFinite(
      profile.referenceReynoldsNumber
    ) || profile.referenceReynoldsNumber <= 0) {
      throw new Error(
        "referenceReynoldsNumber must be finite and positive"
      );
    }
    if (profile.spinKnots.length < 2) {
      throw new Error(
        "aerodynamic coefficient profile requires at least two spin knots"
      );
    }
    if (profile.reynoldsKnots.length < 2) {
      throw new Error(
        "aerodynamic coefficient profile requires at least two Reynolds knots"
      );
    }
    validateAscending(
      "spin factors",
      profile.spinKnots.map(
        (knot) => knot.spinFactor
      )
    );
    validateAscending(
      "Reynolds numbers",
      profile.reynoldsKnots.map(
        (knot) => knot.reynoldsNumber
      )
    );
    for (const knot of profile.spinKnots) {
      if (!Number.isFinite(knot.spinFactor) || knot.spinFactor < 0 || !Number.isFinite(
        knot.dragCoefficientAtReferenceRe
      ) || knot.dragCoefficientAtReferenceRe < 0 || !Number.isFinite(
        knot.liftCoefficient
      ) || knot.liftCoefficient < 0) {
        throw new Error(
          "aerodynamic spin knots must contain finite non-negative values"
        );
      }
    }
    for (const knot of profile.reynoldsKnots) {
      if (!Number.isFinite(
        knot.reynoldsNumber
      ) || knot.reynoldsNumber <= 0 || !Number.isFinite(
        knot.dragCorrectionFactorAtLowSpin
      ) || knot.dragCorrectionFactorAtLowSpin < 0) {
        throw new Error(
          "aerodynamic Reynolds knots must contain finite positive Re and non-negative correction"
        );
      }
    }
    if (!Number.isFinite(
      profile.reynoldsCorrectionFullThroughSpinFactor
    ) || !Number.isFinite(
      profile.reynoldsCorrectionZeroAtSpinFactor
    ) || profile.reynoldsCorrectionFullThroughSpinFactor < 0 || profile.reynoldsCorrectionZeroAtSpinFactor <= profile.reynoldsCorrectionFullThroughSpinFactor) {
      throw new Error(
        "aerodynamic Reynolds spin-blend thresholds must be finite and ordered"
      );
    }
  };
  var interpolate = (x, xs, ys) => {
    if (x <= xs[0]) {
      return ys[0];
    }
    if (x >= xs[xs.length - 1]) {
      return ys[ys.length - 1];
    }
    for (let index = 1; index < xs.length; index += 1) {
      const rightX = xs[index];
      if (x > rightX) {
        continue;
      }
      const leftX = xs[index - 1];
      const t = (x - leftX) / (rightX - leftX);
      return lerp2(
        ys[index - 1],
        ys[index],
        t
      );
    }
    throw new Error(
      "unreachable aerodynamic interpolation interval"
    );
  };
  var resolveBaseballAerodynamicCoefficients = (profile, reynoldsNumber, spinFactor) => {
    validateBaseballAerodynamicCoefficientProfile(
      profile
    );
    if (!Number.isFinite(reynoldsNumber) || reynoldsNumber < 0 || !Number.isFinite(spinFactor) || spinFactor < 0) {
      throw new Error(
        "Reynolds number and spin factor must be finite and non-negative"
      );
    }
    const spinXs = profile.spinKnots.map(
      (knot) => knot.spinFactor
    );
    const baseDrag = interpolate(
      spinFactor,
      spinXs,
      profile.spinKnots.map(
        (knot) => knot.dragCoefficientAtReferenceRe
      )
    );
    const liftCoefficient = interpolate(
      spinFactor,
      spinXs,
      profile.spinKnots.map(
        (knot) => knot.liftCoefficient
      )
    );
    const reynoldsCorrection = interpolate(
      reynoldsNumber,
      profile.reynoldsKnots.map(
        (knot) => knot.reynoldsNumber
      ),
      profile.reynoldsKnots.map(
        (knot) => knot.dragCorrectionFactorAtLowSpin
      )
    );
    const full = profile.reynoldsCorrectionFullThroughSpinFactor;
    const zero4 = profile.reynoldsCorrectionZeroAtSpinFactor;
    const blend = spinFactor <= full ? 1 : spinFactor >= zero4 ? 0 : (zero4 - spinFactor) / (zero4 - full);
    return {
      dragCoefficient: baseDrag * (1 + blend * (reynoldsCorrection - 1)),
      liftCoefficient: spinFactor <= 0 ? 0 : liftCoefficient
    };
  };
  var LYU_2022_SEAM_AVERAGED_AERO_PROFILE = Object.freeze({
    profileId: "lyu-2022-seam-averaged",
    version: "lyu-2022-figure-digitization-v1",
    referenceReynoldsNumber: 144e3,
    spinKnots: Object.freeze([
      {
        spinFactor: 0,
        dragCoefficientAtReferenceRe: 0.35,
        liftCoefficient: 0
      },
      {
        spinFactor: 0.05,
        dragCoefficientAtReferenceRe: 0.34,
        liftCoefficient: 0.1
      },
      {
        spinFactor: 0.1,
        dragCoefficientAtReferenceRe: 0.32,
        liftCoefficient: 0.115
      },
      {
        spinFactor: 0.15,
        dragCoefficientAtReferenceRe: 0.32,
        liftCoefficient: 0.17
      },
      {
        spinFactor: 0.2,
        dragCoefficientAtReferenceRe: 0.33,
        liftCoefficient: 0.195
      },
      {
        spinFactor: 0.25,
        dragCoefficientAtReferenceRe: 0.34,
        liftCoefficient: 0.23
      },
      {
        spinFactor: 0.3,
        dragCoefficientAtReferenceRe: 0.36,
        liftCoefficient: 0.27
      },
      {
        spinFactor: 0.35,
        dragCoefficientAtReferenceRe: 0.38,
        liftCoefficient: 0.305
      },
      {
        spinFactor: 0.4,
        dragCoefficientAtReferenceRe: 0.39,
        liftCoefficient: 0.34
      },
      {
        spinFactor: 0.45,
        dragCoefficientAtReferenceRe: 0.41,
        liftCoefficient: 0.385
      },
      {
        spinFactor: 0.5,
        dragCoefficientAtReferenceRe: 0.42,
        liftCoefficient: 0.4
      }
    ]),
    reynoldsKnots: Object.freeze([
      {
        reynoldsNumber: 75e3,
        dragCorrectionFactorAtLowSpin: 0.46 / 0.34
      },
      {
        reynoldsNumber: 1e5,
        dragCorrectionFactorAtLowSpin: 0.44 / 0.34
      },
      {
        reynoldsNumber: 125e3,
        dragCorrectionFactorAtLowSpin: 0.42 / 0.34
      },
      {
        reynoldsNumber: 15e4,
        dragCorrectionFactorAtLowSpin: 0.36 / 0.34
      },
      {
        reynoldsNumber: 175e3,
        dragCorrectionFactorAtLowSpin: 0.32 / 0.34
      },
      {
        reynoldsNumber: 2e5,
        dragCorrectionFactorAtLowSpin: 0.34 / 0.34
      },
      {
        reynoldsNumber: 25e4,
        dragCorrectionFactorAtLowSpin: 0.35 / 0.34
      }
    ]),
    reynoldsCorrectionFullThroughSpinFactor: 0.05,
    reynoldsCorrectionZeroAtSpinFactor: 0.15
  });

  // src/core/sim/ball/BaseballAerodynamics.ts
  var REFERENCE_BASEBALL_AERODYNAMICS = Object.freeze({
    ballMassKg: 0.145,
    ballRadiusM: 0.0366,
    airDensityKgM3: 1.225,
    windVelocityMps: Object.freeze({ x: 0, y: 0, z: 0 }),
    dragCoefficient: 0.35
  });
  var REALISTIC_LYU_2022_BASEBALL_AERODYNAMICS = Object.freeze({
    ...REFERENCE_BASEBALL_AERODYNAMICS,
    coefficientProfile: LYU_2022_SEAM_AVERAGED_AERO_PROFILE,
    airKinematicViscosityM2PerSecond: 15e-6,
    spinDecay: NATHAN_2026_BASEBALL_SPIN_DECAY_ESTIMATE
  });
  var EPSILON3 = 1e-12;
  var add3 = (a, b) => ({
    x: a.x + b.x,
    y: a.y + b.y,
    z: a.z + b.z
  });
  var subtract3 = (a, b) => ({
    x: a.x - b.x,
    y: a.y - b.y,
    z: a.z - b.z
  });
  var scale4 = (value, scalar) => ({
    x: value.x * scalar,
    y: value.y * scalar,
    z: value.z * scalar
  });
  var dot3 = (a, b) => a.x * b.x + a.y * b.y + a.z * b.z;
  var cross3 = (a, b) => ({
    x: a.y * b.z - a.z * b.y,
    y: a.z * b.x - a.x * b.z,
    z: a.x * b.y - a.y * b.x
  });
  var magnitude4 = (value) => Math.hypot(value.x, value.y, value.z);
  var validateParameters = (parameters) => {
    if (!Number.isFinite(parameters.ballMassKg) || parameters.ballMassKg <= 0) {
      throw new Error("ballMassKg must be finite and positive");
    }
    if (!Number.isFinite(parameters.ballRadiusM) || parameters.ballRadiusM <= 0) {
      throw new Error("ballRadiusM must be finite and positive");
    }
    if (!Number.isFinite(parameters.airDensityKgM3) || parameters.airDensityKgM3 < 0) {
      throw new Error("airDensityKgM3 must be finite and non-negative");
    }
    if (!Number.isFinite(parameters.dragCoefficient) || parameters.dragCoefficient < 0) {
      throw new Error("dragCoefficient must be finite and non-negative");
    }
    if (parameters.spinDecay !== void 0) {
      validateBaseballSpinDecayParameters(
        parameters.spinDecay
      );
    }
    if (parameters.coefficientProfile !== void 0) {
      validateBaseballAerodynamicCoefficientProfile(
        parameters.coefficientProfile
      );
      if (!Number.isFinite(
        parameters.airKinematicViscosityM2PerSecond
      ) || (parameters.airKinematicViscosityM2PerSecond ?? 0) <= 0) {
        throw new Error(
          "airKinematicViscosityM2PerSecond must be finite and positive when coefficientProfile is enabled"
        );
      }
    }
    for (const component of [
      parameters.windVelocityMps.x,
      parameters.windVelocityMps.y,
      parameters.windVelocityMps.z
    ]) {
      if (!Number.isFinite(component)) {
        throw new Error("windVelocityMps must contain only finite values");
      }
    }
  };
  var calculateBaseballLiftCoefficient = (spinFactor) => {
    if (!Number.isFinite(spinFactor) || spinFactor < 0) {
      throw new Error("spinFactor must be finite and non-negative");
    }
    return spinFactor <= 0.1 ? 1.5 * spinFactor : 0.09 + 0.6 * spinFactor;
  };
  var calculateBaseballAerodynamics = (ballVelocityMps, ballSpinRadPerSecond, parameters = REFERENCE_BASEBALL_AERODYNAMICS) => {
    validateParameters(parameters);
    const relativeAirVelocity = subtract3(
      ballVelocityMps,
      parameters.windVelocityMps
    );
    const speed = magnitude4(relativeAirVelocity);
    if (speed <= EPSILON3 || parameters.airDensityKgM3 <= EPSILON3) {
      const zero4 = { x: 0, y: 0, z: 0 };
      return {
        relativeAirVelocity,
        activeSpin: zero4,
        spinFactor: 0,
        reynoldsNumber: null,
        dragCoefficientUsed: parameters.dragCoefficient,
        liftCoefficientUsed: 0,
        dragAcceleration: zero4,
        liftAcceleration: zero4,
        totalAcceleration: zero4
      };
    }
    const velocityHat = scale4(relativeAirVelocity, 1 / speed);
    const parallelSpin = scale4(
      velocityHat,
      dot3(ballSpinRadPerSecond, velocityHat)
    );
    const activeSpin = subtract3(ballSpinRadPerSecond, parallelSpin);
    const activeSpinMagnitude = magnitude4(activeSpin);
    const spinFactor = parameters.ballRadiusM * activeSpinMagnitude / speed;
    const area = Math.PI * parameters.ballRadiusM * parameters.ballRadiusM;
    const dynamicAccelerationScale = 0.5 * parameters.airDensityKgM3 * area * speed * speed / parameters.ballMassKg;
    const reynoldsNumber = parameters.coefficientProfile === void 0 ? null : speed * (2 * parameters.ballRadiusM) / parameters.airKinematicViscosityM2PerSecond;
    const resolvedCoefficients = parameters.coefficientProfile === void 0 ? {
      dragCoefficient: parameters.dragCoefficient,
      liftCoefficient: calculateBaseballLiftCoefficient(
        spinFactor
      )
    } : resolveBaseballAerodynamicCoefficients(
      parameters.coefficientProfile,
      reynoldsNumber,
      spinFactor
    );
    const dragAcceleration = scale4(
      velocityHat,
      -dynamicAccelerationScale * resolvedCoefficients.dragCoefficient
    );
    let liftAcceleration = { x: 0, y: 0, z: 0 };
    if (activeSpinMagnitude > EPSILON3) {
      const liftDirectionRaw = cross3(activeSpin, velocityHat);
      const liftDirectionMagnitude = magnitude4(liftDirectionRaw);
      if (liftDirectionMagnitude > EPSILON3) {
        liftAcceleration = scale4(
          liftDirectionRaw,
          dynamicAccelerationScale * resolvedCoefficients.liftCoefficient / liftDirectionMagnitude
        );
      }
    }
    return {
      relativeAirVelocity,
      activeSpin,
      spinFactor,
      reynoldsNumber,
      dragCoefficientUsed: resolvedCoefficients.dragCoefficient,
      liftCoefficientUsed: resolvedCoefficients.liftCoefficient,
      dragAcceleration,
      liftAcceleration,
      totalAcceleration: add3(dragAcceleration, liftAcceleration)
    };
  };

  // src/core/sim/pitching/PitchSpinPhysics.ts
  var EPSILON4 = 1e-12;
  var scale5 = (value, scalar) => ({
    x: value.x * scalar,
    y: value.y * scalar,
    z: value.z * scalar
  });
  var subtract4 = (a, b) => ({
    x: a.x - b.x,
    y: a.y - b.y,
    z: a.z - b.z
  });
  var dot4 = (a, b) => a.x * b.x + a.y * b.y + a.z * b.z;
  var cross4 = (a, b) => ({
    x: a.y * b.z - a.z * b.y,
    y: a.z * b.x - a.x * b.z,
    z: a.x * b.y - a.y * b.x
  });
  var magnitude5 = (value) => Math.hypot(value.x, value.y, value.z);
  var normalize2 = (value) => {
    const length = magnitude5(value);
    if (length <= EPSILON4) {
      throw new Error("cannot normalize a zero-length vector");
    }
    return scale5(value, 1 / length);
  };
  var decomposePitchSpin = (velocityMps, spinRadPerSecond) => {
    const speed = magnitude5(velocityMps);
    if (speed <= EPSILON4) {
      throw new Error(
        "pitch velocity must be non-zero for spin decomposition"
      );
    }
    const velocityDirection = scale5(
      velocityMps,
      1 / speed
    );
    const signedGyroRate = dot4(
      spinRadPerSecond,
      velocityDirection
    );
    const gyroSpin = Math.abs(signedGyroRate) <= EPSILON4 ? { x: 0, y: 0, z: 0 } : scale5(
      velocityDirection,
      signedGyroRate
    );
    const activeSpin = subtract4(
      spinRadPerSecond,
      gyroSpin
    );
    const totalSpinRadPerSecond = magnitude5(
      spinRadPerSecond
    );
    const activeSpinRadPerSecond = magnitude5(
      activeSpin
    );
    const gyroSpinRadPerSecond = Math.abs(
      signedGyroRate
    );
    const activeSpinFraction = totalSpinRadPerSecond <= EPSILON4 ? 0 : activeSpinRadPerSecond / totalSpinRadPerSecond;
    const gyroSpinFraction = totalSpinRadPerSecond <= EPSILON4 ? 0 : gyroSpinRadPerSecond / totalSpinRadPerSecond;
    const magnusRaw = cross4(
      activeSpin,
      velocityDirection
    );
    const magnusDirection = magnitude5(magnusRaw) <= EPSILON4 ? null : normalize2(magnusRaw);
    return {
      velocityDirection,
      activeSpin,
      gyroSpin,
      totalSpinRadPerSecond,
      activeSpinRadPerSecond,
      gyroSpinRadPerSecond,
      activeSpinFraction,
      gyroSpinFraction,
      magnusDirection
    };
  };

  // src/core/sim/pitching/BaseballOrientation.ts
  var IDENTITY_QUATERNION = Object.freeze({
    w: 1,
    x: 0,
    y: 0,
    z: 0
  });
  var EPSILON5 = 1e-12;
  var magnitude6 = (value) => Math.hypot(value.x, value.y, value.z);
  var scale6 = (value, scalar) => ({
    x: value.x * scalar,
    y: value.y * scalar,
    z: value.z * scalar
  });
  var normalizeQuaternion = (value) => {
    const length = Math.hypot(
      value.w,
      value.x,
      value.y,
      value.z
    );
    if (!Number.isFinite(length) || length <= EPSILON5) {
      throw new Error(
        "quaternion must have finite non-zero magnitude"
      );
    }
    return {
      w: value.w / length,
      x: value.x / length,
      y: value.y / length,
      z: value.z / length
    };
  };
  var multiplyQuaternions = (a, b) => ({
    w: a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z,
    x: a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y,
    y: a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x,
    z: a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w
  });
  var quaternionFromAxisAngle = (axis, angleRadians) => {
    if (!Number.isFinite(angleRadians)) {
      throw new Error("angleRadians must be finite");
    }
    const axisMagnitude = magnitude6(axis);
    if (axisMagnitude <= EPSILON5) {
      if (Math.abs(angleRadians) <= EPSILON5) {
        return IDENTITY_QUATERNION;
      }
      throw new Error(
        "axis must be non-zero for a non-zero rotation"
      );
    }
    const unitAxis = scale6(
      axis,
      1 / axisMagnitude
    );
    const half = angleRadians / 2;
    const sine = Math.sin(half);
    return normalizeQuaternion({
      w: Math.cos(half),
      x: unitAxis.x * sine,
      y: unitAxis.y * sine,
      z: unitAxis.z * sine
    });
  };
  var rotateVectorByQuaternion = (value, orientation) => {
    const q = normalizeQuaternion(orientation);
    const vectorQ = {
      w: 0,
      x: value.x,
      y: value.y,
      z: value.z
    };
    const conjugate = {
      w: q.w,
      x: -q.x,
      y: -q.y,
      z: -q.z
    };
    const rotated = multiplyQuaternions(
      multiplyQuaternions(q, vectorQ),
      conjugate
    );
    return {
      x: rotated.x,
      y: rotated.y,
      z: rotated.z
    };
  };
  var advanceBaseballOrientation = (orientation, angularVelocityWorldRadPerSecond, elapsedSeconds) => {
    if (!Number.isFinite(elapsedSeconds) || elapsedSeconds < 0) {
      throw new Error(
        "elapsedSeconds must be finite and non-negative"
      );
    }
    const spinRate = magnitude6(
      angularVelocityWorldRadPerSecond
    );
    if (spinRate <= EPSILON5 || elapsedSeconds <= EPSILON5) {
      return normalizeQuaternion(orientation);
    }
    const delta = quaternionFromAxisAngle(
      angularVelocityWorldRadPerSecond,
      spinRate * elapsedSeconds
    );
    return normalizeQuaternion(
      multiplyQuaternions(
        delta,
        normalizeQuaternion(orientation)
      )
    );
  };

  // src/core/sim/pitching/AerodynamicPitchTrajectory.ts
  var EPSILON6 = 1e-12;
  var add4 = (a, b) => ({
    x: a.x + b.x,
    y: a.y + b.y,
    z: a.z + b.z
  });
  var subtract5 = (a, b) => ({
    x: a.x - b.x,
    y: a.y - b.y,
    z: a.z - b.z
  });
  var scale7 = (value, scalar) => ({
    x: value.x * scalar,
    y: value.y * scalar,
    z: value.z * scalar
  });
  var weightedSum = (a, b, c, d) => ({
    x: a.x + 2 * b.x + 2 * c.x + d.x,
    y: a.y + 2 * b.y + 2 * c.y + d.y,
    z: a.z + 2 * b.z + 2 * c.z + d.z
  });
  var lerpVec3 = (a, b, t) => ({
    x: a.x + (b.x - a.x) * t,
    y: a.y + (b.y - a.y) * t,
    z: a.z + (b.z - a.z) * t
  });
  var validateParameters2 = (parameters) => {
    if (!Number.isSafeInteger(parameters.ticksPerSecond) || parameters.ticksPerSecond <= 0) {
      throw new Error(
        "pitch aerodynamics ticksPerSecond must be a positive safe integer"
      );
    }
    if (!Number.isSafeInteger(parameters.integrationStepTicks) || parameters.integrationStepTicks <= 0) {
      throw new Error(
        "pitch aerodynamics integrationStepTicks must be a positive safe integer"
      );
    }
    if (!Number.isFinite(parameters.gravityY)) {
      throw new Error(
        "pitch aerodynamics gravityY must be finite"
      );
    }
  };
  var validateTrajectory2 = (trajectory) => {
    validateParameters2(trajectory.parameters);
    if (!Number.isSafeInteger(trajectory.start.tick) || trajectory.start.tick < 0) {
      throw new Error(
        "aerodynamic pitch start tick must be a non-negative safe integer"
      );
    }
    if (!Number.isSafeInteger(trajectory.endTick) || trajectory.endTick < trajectory.start.tick) {
      throw new Error(
        "aerodynamic pitch endTick must be a safe integer at or after start"
      );
    }
  };
  var accelerationAt = (velocity, spin, parameters) => {
    const aerodynamic = calculateBaseballAerodynamics(
      velocity,
      spin,
      parameters.aerodynamics
    );
    return {
      x: aerodynamic.totalAcceleration.x,
      y: aerodynamic.totalAcceleration.y + parameters.gravityY,
      z: aerodynamic.totalAcceleration.z
    };
  };
  var spinDerivativeAt = (velocity, spin, parameters) => {
    const decay = parameters.aerodynamics.spinDecay;
    if (decay === void 0) {
      return {
        x: 0,
        y: 0,
        z: 0
      };
    }
    return calculateBaseballSpinDecayDerivative(
      spin,
      subtract5(
        velocity,
        parameters.aerodynamics.windVelocityMps
      ),
      decay
    );
  };
  var advanceAerodynamicPitchStep = (state, stepTicks, parameters) => {
    const dt = stepTicks / parameters.ticksPerSecond;
    const k1Position = state.velocity;
    const k1Velocity = accelerationAt(
      state.velocity,
      state.spin,
      parameters
    );
    const k1Spin = spinDerivativeAt(
      state.velocity,
      state.spin,
      parameters
    );
    const k2VelocityInput = add4(
      state.velocity,
      scale7(k1Velocity, dt / 2)
    );
    const k2SpinInput = add4(
      state.spin,
      scale7(k1Spin, dt / 2)
    );
    const k2Position = k2VelocityInput;
    const k2Velocity = accelerationAt(
      k2VelocityInput,
      k2SpinInput,
      parameters
    );
    const k2Spin = spinDerivativeAt(
      k2VelocityInput,
      k2SpinInput,
      parameters
    );
    const k3VelocityInput = add4(
      state.velocity,
      scale7(k2Velocity, dt / 2)
    );
    const k3SpinInput = add4(
      state.spin,
      scale7(k2Spin, dt / 2)
    );
    const k3Position = k3VelocityInput;
    const k3Velocity = accelerationAt(
      k3VelocityInput,
      k3SpinInput,
      parameters
    );
    const k3Spin = spinDerivativeAt(
      k3VelocityInput,
      k3SpinInput,
      parameters
    );
    const k4VelocityInput = add4(
      state.velocity,
      scale7(k3Velocity, dt)
    );
    const k4SpinInput = add4(
      state.spin,
      scale7(k3Spin, dt)
    );
    const k4Position = k4VelocityInput;
    const k4Velocity = accelerationAt(
      k4VelocityInput,
      k4SpinInput,
      parameters
    );
    const k4Spin = spinDerivativeAt(
      k4VelocityInput,
      k4SpinInput,
      parameters
    );
    return {
      tick: state.tick + stepTicks,
      position: add4(
        state.position,
        scale7(
          weightedSum(
            k1Position,
            k2Position,
            k3Position,
            k4Position
          ),
          dt / 6
        )
      ),
      velocity: add4(
        state.velocity,
        scale7(
          weightedSum(
            k1Velocity,
            k2Velocity,
            k3Velocity,
            k4Velocity
          ),
          dt / 6
        )
      ),
      // Aerodynamic torque changes spin magnitude only in the current model;
      // no unmeasured precession is manufactured.
      spin: add4(
        state.spin,
        scale7(
          weightedSum(
            k1Spin,
            k2Spin,
            k3Spin,
            k4Spin
          ),
          dt / 6
        )
      )
    };
  };
  var advanceAerodynamicPitchState = (state, deltaTicks, parameters) => {
    validateParameters2(parameters);
    if (!Number.isSafeInteger(deltaTicks) || deltaTicks < 0) {
      throw new Error(
        "aerodynamic pitch deltaTicks must be a non-negative safe integer"
      );
    }
    let current = state;
    let remaining = deltaTicks;
    while (remaining > 0) {
      const stepTicks = Math.min(
        parameters.integrationStepTicks,
        remaining
      );
      current = advanceAerodynamicPitchStep(
        current,
        stepTicks,
        parameters
      );
      remaining -= stepTicks;
    }
    return current;
  };
  var sampleAerodynamicPitchTrajectory = (trajectory, tick2) => {
    validateTrajectory2(trajectory);
    if (!Number.isSafeInteger(tick2) || tick2 < trajectory.start.tick || tick2 > trajectory.endTick) {
      throw new Error(
        "aerodynamic pitch sample tick must lie inside the trajectory interval"
      );
    }
    return advanceAerodynamicPitchState(
      trajectory.start,
      tick2 - trajectory.start.tick,
      trajectory.parameters
    );
  };
  var sampleAerodynamicPitchOrientation = (trajectory, elapsedSeconds) => {
    if (trajectory.releaseOrientation === void 0) {
      return void 0;
    }
    if (!Number.isFinite(elapsedSeconds) || elapsedSeconds < 0) {
      throw new Error(
        "pitch orientation elapsedSeconds must be finite and non-negative"
      );
    }
    return advanceBaseballOrientation(
      normalizeQuaternion(
        trajectory.releaseOrientation
      ),
      trajectory.start.spin,
      elapsedSeconds
    );
  };
  var crossedPlate = (startZ, currentZ, plateZ) => startZ > plateZ ? currentZ <= plateZ : currentZ >= plateZ;
  var findAerodynamicPitchPlateCrossing = (trajectory, plateZ) => {
    validateTrajectory2(trajectory);
    if (!Number.isFinite(plateZ)) {
      throw new Error("plateZ must be finite");
    }
    if (Math.abs(
      trajectory.start.position.z - plateZ
    ) <= EPSILON6) {
      return {
        tick: trajectory.start.tick,
        elapsedSeconds: 0,
        position: {
          ...trajectory.start.position,
          z: plateZ
        },
        velocity: trajectory.start.velocity,
        spin: trajectory.start.spin,
        spinDecomposition: decomposePitchSpin(
          trajectory.start.velocity,
          trajectory.start.spin
        ),
        orientation: sampleAerodynamicPitchOrientation(
          trajectory,
          0
        )
      };
    }
    const end = sampleAerodynamicPitchTrajectory(
      trajectory,
      trajectory.endTick
    );
    if (!crossedPlate(
      trajectory.start.position.z,
      end.position.z,
      plateZ
    )) {
      return null;
    }
    const crossingTick = findFirstTrueTick(
      trajectory.start.tick,
      trajectory.endTick,
      (tick2) => {
        const sampled = sampleAerodynamicPitchTrajectory(
          trajectory,
          tick2
        );
        return crossedPlate(
          trajectory.start.position.z,
          sampled.position.z,
          plateZ
        );
      }
    );
    if (crossingTick === null) {
      return null;
    }
    if (crossingTick === trajectory.start.tick) {
      return {
        tick: crossingTick,
        elapsedSeconds: 0,
        position: {
          ...trajectory.start.position,
          z: plateZ
        },
        velocity: trajectory.start.velocity,
        spin: trajectory.start.spin,
        spinDecomposition: decomposePitchSpin(
          trajectory.start.velocity,
          trajectory.start.spin
        ),
        orientation: sampleAerodynamicPitchOrientation(
          trajectory,
          0
        )
      };
    }
    const before = sampleAerodynamicPitchTrajectory(
      trajectory,
      crossingTick - 1
    );
    const after = sampleAerodynamicPitchTrajectory(
      trajectory,
      crossingTick
    );
    const denominator = after.position.z - before.position.z;
    const interpolation = Math.abs(denominator) <= EPSILON6 ? 1 : Math.max(
      0,
      Math.min(
        1,
        (plateZ - before.position.z) / denominator
      )
    );
    const position = lerpVec3(
      before.position,
      after.position,
      interpolation
    );
    const velocity = lerpVec3(
      before.velocity,
      after.velocity,
      interpolation
    );
    const elapsedTicks = crossingTick - 1 - trajectory.start.tick + interpolation;
    return {
      tick: crossingTick,
      elapsedSeconds: elapsedTicks / trajectory.parameters.ticksPerSecond,
      position: {
        ...position,
        z: plateZ
      },
      velocity,
      spin: lerpVec3(
        before.spin,
        after.spin,
        interpolation
      ),
      spinDecomposition: decomposePitchSpin(
        velocity,
        lerpVec3(
          before.spin,
          after.spin,
          interpolation
        )
      ),
      orientation: sampleAerodynamicPitchOrientation(
        trajectory,
        elapsedTicks / trajectory.parameters.ticksPerSecond
      )
    };
  };

  // src/core/sim/ball/BaseballGroundDynamics.ts
  var EPSILON7 = 1e-10;
  function validate(ball, p) {
    if (!ball || !Number.isSafeInteger(ball.tick) || ball.tick < 0 || ![ball.position, ball.velocity, ball.spin].every((v) => v && Object.values(v).every(Number.isFinite))) {
      throw new Error("ground dynamics requires a finite physical ball and source clock");
    }
    if (!p || !p.material || !Number.isSafeInteger(p.ticksPerSecond) || p.ticksPerSecond <= 0 || ![p.radiusM, p.inertiaRatio, p.gravityMps2].every((v) => Number.isFinite(v) && v > 0) || ![
      p.restingVerticalSpeedMps,
      p.material.slidingFriction,
      p.material.rollingDecelerationMps2,
      p.material.normalSpinDecayPerSecond
    ].every((v) => Number.isFinite(v) && v >= 0) || !Number.isFinite(p.material.restitution) || p.material.restitution < 0 || p.material.restitution > 1) {
      throw new Error("invalid ground dynamics physical parameters");
    }
  }
  function slip(ball, radius) {
    return { x: ball.velocity.x + radius * ball.spin.z, z: ball.velocity.z - radius * ball.spin.x };
  }
  function resolveBaseballGroundImpact(ball, p) {
    validate(ball, p);
    if (Math.abs(ball.position.y - p.radiusM) > EPSILON7 || ball.velocity.y > 0) {
      throw new Error("ground impact requires an actual incoming floor contact");
    }
    const normalImpulsePerMass = -(1 + p.material.restitution) * ball.velocity.y;
    const relative = slip(ball, p.radiusM), speed = Math.hypot(relative.x, relative.z);
    const impulse = Math.min(speed / (1 + 1 / p.inertiaRatio), p.material.slidingFriction * normalImpulsePerMass);
    const dx = speed <= EPSILON7 ? 0 : -relative.x / speed * impulse;
    const dz = speed <= EPSILON7 ? 0 : -relative.z / speed * impulse;
    const rebound = -p.material.restitution * ball.velocity.y;
    const result = {
      ...ball,
      position: { ...ball.position, y: p.radiusM },
      velocity: { x: ball.velocity.x + dx, y: rebound < p.restingVerticalSpeedMps ? 0 : rebound, z: ball.velocity.z + dz },
      spin: {
        x: ball.spin.x - dz / (p.inertiaRatio * p.radiusM),
        y: ball.spin.y,
        z: ball.spin.z + dx / (p.inertiaRatio * p.radiusM)
      }
    };
    validate(result, p);
    return result;
  }
  function advanceBaseballGroundMotion(initial, deltaTicks, p) {
    validate(initial, p);
    if (!Number.isSafeInteger(deltaTicks) || deltaTicks < 0 || !Number.isSafeInteger(initial.tick + deltaTicks)) {
      throw new Error("ground motion requires a bounded non-negative source-clock interval");
    }
    return advanceBaseballGroundMotionSeconds(initial, deltaTicks / p.ticksPerSecond, initial.tick + deltaTicks, p);
  }
  function advanceBaseballGroundMotionSeconds(initial, duration, throughTick, p) {
    if (Math.abs(initial.position.y - p.radiusM) > EPSILON7 || initial.velocity.y !== 0) {
      throw new Error("ground motion requires a ball resting on the actual floor");
    }
    let remaining = duration, elapsed = 0;
    let x = initial.position.x, z = initial.position.z;
    let vx = initial.velocity.x, vz = initial.velocity.z;
    let wx = initial.spin.x, wz = initial.spin.z;
    const transitions = [];
    const relative = slip(initial, p.radiusM), slipSpeed = Math.hypot(relative.x, relative.z);
    const friction = p.material.slidingFriction * p.gravityMps2;
    let rolling = slipSpeed <= EPSILON7;
    if (!rolling) {
      const untilRolling = friction === 0 ? Infinity : slipSpeed / (friction * (1 + 1 / p.inertiaRatio));
      const dt = Math.min(remaining, untilRolling);
      const ax = -friction * relative.x / slipSpeed, az = -friction * relative.z / slipSpeed;
      x += vx * dt + 0.5 * ax * dt * dt;
      z += vz * dt + 0.5 * az * dt * dt;
      vx += ax * dt;
      vz += az * dt;
      wx -= az * dt / (p.inertiaRatio * p.radiusM);
      wz += ax * dt / (p.inertiaRatio * p.radiusM);
      remaining -= dt;
      elapsed += dt;
      if (dt === untilRolling) {
        rolling = true;
        transitions.push({ kind: "rolling_started", elapsedSeconds: elapsed });
      }
    }
    let phase = rolling ? "rolling" : "sliding";
    if (rolling) {
      const speed = Math.hypot(vx, vz), deceleration = p.material.rollingDecelerationMps2;
      const stopSeconds = speed === 0 ? 0 : deceleration === 0 ? Infinity : speed / deceleration;
      const dt = Math.min(remaining, stopSeconds);
      const distance = speed * dt - 0.5 * deceleration * dt * dt;
      if (speed > EPSILON7) {
        x += vx / speed * distance;
        z += vz / speed * distance;
        const nextSpeed = Math.max(0, speed - deceleration * dt);
        vx = vx / speed * nextSpeed;
        vz = vz / speed * nextSpeed;
      } else {
        vx = 0;
        vz = 0;
      }
      if (stopSeconds <= remaining) {
        vx = 0;
        vz = 0;
        phase = "resting";
        if (speed > EPSILON7) transitions.push({ kind: "rolling_stopped", elapsedSeconds: elapsed + stopSeconds });
      }
      wx = vz === 0 ? 0 : vz / p.radiusM;
      wz = vx === 0 ? 0 : -vx / p.radiusM;
    }
    const result = {
      tick: throughTick,
      position: { x, y: p.radiusM, z },
      velocity: { x: vx, y: 0, z: vz },
      spin: { x: wx, y: initial.spin.y * Math.exp(-p.material.normalSpinDecayPerSecond * duration), z: wz }
    };
    validate(result, p);
    return { ball: result, phase, transitions };
  }

  // src/core/sim/ball/FreeBaseballTrajectory.ts
  var freeze2 = (value) => {
    if (value && typeof value === "object") {
      Object.values(value).forEach(freeze2);
      Object.freeze(value);
    }
    return value;
  };
  function createFreeBaseballTrajectory(raw) {
    const input = structuredClone(raw), { initialBall, throughTick, aerodynamics: aero, ground } = input;
    if (!initialBall || !aero || !ground || !Number.isSafeInteger(initialBall.tick) || initialBall.tick < 0 || !Number.isSafeInteger(throughTick) || throughTick < initialBall.tick || !Number.isSafeInteger(aero.ticksPerSecond) || aero.ticksPerSecond <= 0 || !Number.isSafeInteger(aero.integrationStepTicks) || aero.integrationStepTicks <= 0 || ![initialBall.position, initialBall.velocity, initialBall.spin].every((v) => v && [v.x, v.y, v.z].every(Number.isFinite)) || ground.ticksPerSecond !== aero.ticksPerSecond || ground.radiusM !== aero.aerodynamics.ballRadiusM || ground.gravityMps2 !== -aero.gravityY || (throughTick - initialBall.tick) / aero.ticksPerSecond > 120 || initialBall.position.y < ground.radiusM - 1e-10) {
      throw new Error("free baseball trajectory requires consistent original physical parameters and a bounded horizon");
    }
    advanceAerodynamicPitchState(initialBall, 0, aero);
    calculateBaseballAerodynamics(initialBall.velocity, initialBall.spin, aero.aerodynamics);
    advanceBaseballGroundMotion({
      ...initialBall,
      position: { ...initialBall.position, y: ground.radiusM },
      velocity: { ...initialBall.velocity, y: 0 }
    }, 0, ground);
    const samples = [], groundContacts = [];
    const grounded = (b) => Math.abs(b.position.y - ground.radiusM) <= 1e-10 && b.velocity.y === 0;
    const phaseAt = (b) => grounded(b) ? advanceBaseballGroundMotion(b, 0, ground).phase : "airborne";
    const oriented = (anchor, ball) => {
      const meanSpin = {
        x: (anchor.ball.spin.x + ball.spin.x) / 2,
        y: (anchor.ball.spin.y + ball.spin.y) / 2,
        z: (anchor.ball.spin.z + ball.spin.z) / 2
      };
      return { tick: ball.tick, ball, phase: phaseAt(ball), orientation: advanceBaseballOrientation(
        anchor.orientation,
        meanSpin,
        (ball.tick - anchor.tick) / aero.ticksPerSecond
      ) };
    };
    const advance = (anchor, tick2) => oriented(
      anchor,
      grounded(anchor.ball) ? advanceBaseballGroundMotion(anchor.ball, tick2 - anchor.tick, ground).ball : advanceAerodynamicPitchState(anchor.ball, tick2 - anchor.tick, aero)
    );
    let current = {
      tick: initialBall.tick,
      ball: initialBall,
      orientation: normalizeQuaternion(input.orientationAtStart ?? IDENTITY_QUATERNION),
      phase: phaseAt(initialBall)
    };
    if (initialBall.position.y <= ground.radiusM && initialBall.velocity.y < 0) {
      const incoming = { ...initialBall, position: { ...initialBall.position, y: ground.radiusM } };
      const outgoing = resolveBaseballGroundImpact(incoming, ground);
      groundContacts.push({ incoming, outgoing });
      current = { ...current, ball: outgoing, phase: phaseAt(outgoing) };
    }
    samples.push(current);
    while (current.tick < throughTick) {
      const lattice = initialBall.tick + (Math.floor((current.tick - initialBall.tick) / aero.integrationStepTicks) + 1) * aero.integrationStepTicks;
      let endTick = Math.min(lattice, throughTick);
      if (grounded(current.ball)) {
        const nextTransition = advanceBaseballGroundMotion(current.ball, endTick - current.tick, ground).transitions[0];
        if (nextTransition) {
          const boundaryTick = quantizeEventTick(current.tick, nextTransition.elapsedSeconds, aero.ticksPerSecond);
          if (boundaryTick > current.tick) endTick = Math.min(endTick, boundaryTick);
        }
      }
      const proposed = advance(current, endTick);
      let floorHorizon = endTick;
      if (!grounded(current.ball) && current.ball.velocity.y < 0 && proposed.ball.velocity.y >= 0) {
        const turnTick = findFirstTrueTick(current.tick, endTick, (tick2) => advance(current, tick2).ball.velocity.y >= 0);
        if (turnTick !== null) {
          const before = Math.max(current.tick, turnTick - 1);
          floorHorizon = advance(current, before).ball.position.y < advance(current, turnTick).ball.position.y ? before : turnTick;
        }
      }
      if (!grounded(current.ball) && advance(current, floorHorizon).ball.position.y <= ground.radiusM) {
        const first = current.ball.position.y <= ground.radiusM ? current.tick + 1 : current.tick;
        const contactTick = findFirstTrueTick(
          first,
          floorHorizon,
          (tick2) => advance(current, tick2).ball.position.y <= ground.radiusM
        );
        if (contactTick === null) throw new Error("free trajectory ground crossing has no physical contact");
        const atContact = advance(current, contactTick);
        const incoming = { ...atContact.ball, position: { ...atContact.ball.position, y: ground.radiusM } };
        const outgoing = resolveBaseballGroundImpact(incoming, ground);
        groundContacts.push({ incoming, outgoing });
        current = { ...atContact, ball: outgoing, phase: phaseAt(outgoing) };
      } else current = proposed;
      samples.push(current);
    }
    const frozenSamples = freeze2(samples), frozenContacts = freeze2(groundContacts);
    const observe = (ticks2) => {
      let previous = -1;
      return ticks2.map((tick2) => {
        if (!Number.isSafeInteger(tick2) || tick2 <= previous || tick2 < initialBall.tick || tick2 > throughTick) {
          throw new Error("free baseball observation requires strictly increasing available source ticks");
        }
        previous = tick2;
        let low = 0, high = frozenSamples.length - 1;
        while (low < high) {
          const mid = Math.ceil((low + high) / 2);
          if (frozenSamples[mid].tick <= tick2) low = mid;
          else high = mid - 1;
        }
        const anchor = frozenSamples[low];
        return anchor.tick === tick2 ? anchor : freeze2(advance(anchor, tick2));
      });
    };
    return Object.freeze({ samples: frozenSamples, groundContacts: frozenContacts, observe });
  }

  // src/core/rng/DeterministicRng.ts
  function rotateLeft(value, bits) {
    return (value << bits | value >>> 32 - bits) >>> 0;
  }
  var DeterministicRng = class {
    s0;
    s1;
    s2;
    s3;
    constructor(seed) {
      let state = seed >>> 0;
      const split = () => {
        state = state + 2654435769 >>> 0;
        let z = state;
        z = Math.imul(z ^ z >>> 16, 569420461);
        z = Math.imul(z ^ z >>> 15, 1935289751);
        return (z ^ z >>> 15) >>> 0;
      };
      this.s0 = split();
      this.s1 = split();
      this.s2 = split();
      this.s3 = split();
      if ((this.s0 | this.s1 | this.s2 | this.s3) === 0) this.s3 = 1;
    }
    nextUint32() {
      const result = Math.imul(rotateLeft(Math.imul(this.s1, 5) >>> 0, 7), 9) >>> 0;
      const t = this.s1 << 9 >>> 0;
      this.s2 = (this.s2 ^ this.s0) >>> 0;
      this.s3 = (this.s3 ^ this.s1) >>> 0;
      this.s1 = (this.s1 ^ this.s2) >>> 0;
      this.s0 = (this.s0 ^ this.s3) >>> 0;
      this.s2 = (this.s2 ^ t) >>> 0;
      this.s3 = rotateLeft(this.s3, 11);
      return result;
    }
    nextFloat() {
      return this.nextUint32() / 4294967296;
    }
  };

  // src/integration/browser/WorkbenchPitchTrajectory.ts
  var createWorkbenchPitchTrajectory = (pitch) => {
    if (!pitch || ![pitch.speedMps, pitch.spinRpm, pitch.courseX, pitch.courseY].every(Number.isFinite) || pitch.speedMps < 10 || pitch.speedMps > 80 || pitch.spinRpm < 0 || pitch.spinRpm > 5e3 || Math.abs(pitch.courseX) > 1.5 || pitch.courseY < 0.2 || pitch.courseY > 2.5 || !["backspin", "topspin", "sidespin", "gyro"].includes(pitch.spinAxis)) throw new Error("invalid workbench physical scenario");
    const p = WORKBENCH_TICKS_PER_SECOND, spinRate = pitch.spinRpm * Math.PI * 2 / 60;
    const spin = pitch.spinAxis === "backspin" ? { x: spinRate, y: 0, z: 0 } : pitch.spinAxis === "topspin" ? { x: -spinRate, y: 0, z: 0 } : pitch.spinAxis === "sidespin" ? { x: 0, y: spinRate, z: 0 } : { x: 0, y: 0, z: spinRate };
    const flightEnd = Math.ceil((18 / pitch.speedMps + 0.3) * p);
    const approximateTime = 18 / pitch.speedMps;
    let initial = {
      tick: 0,
      position: { x: 0, y: 1.8, z: 18 },
      velocity: {
        x: pitch.courseX / approximateTime,
        y: (pitch.courseY - 1.8 + 4.905 * approximateTime ** 2) / approximateTime,
        z: -pitch.speedMps
      },
      spin
    };
    const parameters = {
      ticksPerSecond: p,
      integrationStepTicks: 1e3,
      gravityY: -9.81,
      aerodynamics: REALISTIC_LYU_2022_BASEBALL_AERODYNAMICS
    };
    let trajectory = { start: initial, endTick: flightEnd, parameters, releaseOrientation: IDENTITY_QUATERNION };
    for (let i = 0; i < 4; i++) {
      const course = findAerodynamicPitchPlateCrossing(trajectory, 0);
      if (!course) throw new Error("workbench course does not reach the authored contact plane");
      initial = { ...initial, velocity: {
        ...initial.velocity,
        x: initial.velocity.x + (pitch.courseX - course.position.x) / course.elapsedSeconds,
        y: initial.velocity.y + (pitch.courseY - course.position.y) / course.elapsedSeconds
      } };
      trajectory = { ...trajectory, start: initial };
    }
    return { initial, parameters, trajectory, flightEnd };
  };

  // src/integration/browser/BattingWorkbench.ts
  var add5 = (a, b) => ({ x: a.x + b.x, y: a.y + b.y, z: a.z + b.z });
  var sub = (a, b) => ({ x: a.x - b.x, y: a.y - b.y, z: a.z - b.z });
  var scale8 = (a, n) => ({ x: a.x * n, y: a.y * n, z: a.z * n });
  var norm = (a) => Math.hypot(a.x, a.y, a.z);
  var cross5 = (a, b) => ({ x: a.y * b.z - a.z * b.y, y: a.z * b.x - a.x * b.z, z: a.x * b.y - a.y * b.x });
  var unit = (a) => scale8(a, 1 / Math.max(1e-12, norm(a)));
  var clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  var smooth = (v) => v * v * (3 - 2 * v);
  var rad = (v) => v * Math.PI / 180;
  var gaussian = (rng) => Math.sqrt(-2 * Math.log(Math.max(1e-12, rng.nextFloat()))) * Math.cos(2 * Math.PI * rng.nextFloat());
  function simulateBattingWorkbench(raw) {
    const player = createWorkbenchPlayer(raw.player), pitch = structuredClone(raw.pitch);
    const duration = raw.throughSeconds ?? 8, timeOffset = raw.timingOffsetMs ?? 0, positionOffset = raw.positionOffsetM ?? 0;
    if (!Number.isSafeInteger(raw.seed) || !pitch || ![
      pitch.speedMps,
      pitch.spinRpm,
      pitch.courseX,
      pitch.courseY,
      duration,
      timeOffset,
      positionOffset
    ].every(Number.isFinite) || pitch.speedMps < 10 || pitch.speedMps > 80 || pitch.spinRpm < 0 || pitch.spinRpm > 5e3 || Math.abs(pitch.courseX) > 1.5 || pitch.courseY < 0.2 || pitch.courseY > 2.5 || duration < 1 || duration > 20 || Math.abs(timeOffset) > 500 || Math.abs(positionOffset) > 0.5 || !["backspin", "topspin", "sidespin", "gyro"].includes(pitch.spinAxis)) throw new Error("invalid workbench physical scenario");
    const sourceValues = exportWorkbenchPlayerSources(player), equipment = sourceValues.equipment;
    const p = WORKBENCH_TICKS_PER_SECOND;
    const { initial, parameters, trajectory, flightEnd } = createWorkbenchPitchTrajectory(pitch);
    const target = findAerodynamicPitchPlateCrossing(trajectory, player.swing.contactDepthM);
    const rng = new DeterministicRng(raw.seed), diagnostics = [];
    const awkwardness = Math.max(
      0,
      Math.abs(target.position.x) / 0.2159 - 1,
      (0.55 - target.position.y) / 0.5,
      (target.position.y - 1.5) / 0.5
    );
    const executionError = player.capability.positionErrorMeters * (1 + awkwardness * (1 - player.traits.badBallControl));
    const aimed = add5(target.position, {
      x: gaussian(rng) * executionError,
      y: gaussian(rng) * executionError + positionOffset,
      z: 0
    });
    const timingNoise = Math.round(gaussian(rng) * player.capability.timingErrorTicks);
    const plannedContactTick = target.tick + player.capability.technicalTimingOffsetTicks + Math.round(timeOffset * 1e3) + timingNoise;
    const preTicks = Math.round(player.swing.preContactSeconds * p), followTicks = Math.round(player.swing.followThroughSeconds * p);
    const startTick = Math.max(player.capability.motorLatencyTicks, plannedContactTick - preTicks);
    const motorDelay = startTick - (plannedContactTick - preTicks), contactTick = plannedContactTick + motorDelay;
    const endTick = contactTick + followTicks;
    if (motorDelay > 0) diagnostics.push("\u8EAB\u4F53\u306E\u53CD\u5FDC\u304C\u59CB\u52D5\u4E88\u5B9A\u306B\u9593\u306B\u5408\u308F\u305A\u3001\u5B9F\u30B9\u30A4\u30F3\u30B0\u3092\u9045\u3089\u305B\u307E\u3057\u305F");
    const side = player.identity.bats === "R" ? 1 : -1;
    const pull = rad(player.swing.pullAngleDeg * side), attack = rad(player.swing.attackAngleDeg);
    const contactAxis = { x: side * Math.cos(pull), y: 0, z: side * Math.sin(pull) };
    const tangent = { x: -Math.sin(pull) * Math.cos(attack), y: Math.sin(attack), z: Math.cos(pull) * Math.cos(attack) };
    const axisNormal = unit(cross5(contactAxis, tangent)), sweetRadius = player.bat.lengthM * player.bat.sweetSpotT;
    const omega = player.swing.speedMps / sweetRadius;
    if (player.swing.loadAngleDeg >= -1 || player.swing.finishAngleDeg <= 1) {
      throw new Error("\u59CB\u52D5\u89D2\u306F-1\u5EA6\u672A\u6E80\u3001\u7D42\u70B9\u89D2\u306F1\u5EA6\u8D85\u306B\u3057\u3066\u304F\u3060\u3055\u3044");
    }
    const loadAngle = -rad(player.swing.loadAngleDeg), finishAngle = rad(player.swing.finishAngleDeg);
    if (loadAngle < 0.01 || finishAngle < 0.01) throw new Error("\u30D0\u30C3\u30C8\u306E\u59CB\u52D5\u89D2\u3068\u7D42\u70B9\u89D2\u306F1\u5EA6\u4EE5\u4E0A\u306B\u3057\u3066\u304F\u3060\u3055\u3044");
    const preExponent = omega * player.swing.preContactSeconds / loadAngle;
    const postExponent = omega * player.swing.followThroughSeconds / finishAngle;
    if (preExponent < 1 || postExponent < 1) throw new Error("\u89D2\u5EA6\u306B\u5BFE\u3057\u3066\u30B9\u30A4\u30F3\u30B0\u6642\u9593\u304C\u77ED\u3059\u304E\u307E\u3059\u3002\u6642\u9593\u3092\u5897\u3084\u3059\u304B\u89D2\u5EA6\u3092\u6E1B\u3089\u3057\u3066\u304F\u3060\u3055\u3044");
    const centerAtContact = add5(aimed, {
      x: 0,
      y: 0,
      z: -(equipment.ball.radiusM + sampleBatRadius(equipment.batPhysical.radiusProfile, player.bat.sweetSpotT))
    });
    const contactGrip = sub(centerAtContact, scale8(contactAxis, sweetRadius));
    const shoulderCenter = { x: -side * player.body.heightMeters * 0.47, y: player.body.heightMeters * 0.64, z: 0.08 };
    const shoulders = [-1, 1].map((s) => add5(shoulderCenter, { x: side * s * player.body.heightMeters * 0.09, y: 0, z: 0 }));
    const upperArm = player.body.heightMeters * 0.18, forearm = player.body.heightMeters * 0.16;
    const reach = upperArm + forearm - 1e-5;
    const minimumReach = Math.abs(upperArm - forearm) + 1e-5;
    const angles = (tick2) => {
      if (tick2 <= startTick) return { theta: -loadAngle, rate: 0, hand: -player.swing.handTravelM };
      if (tick2 < contactTick) {
        const u = (tick2 - startTick) / preTicks;
        return {
          theta: -loadAngle * (1 - u ** preExponent),
          rate: omega * u ** (preExponent - 1),
          hand: -player.swing.handTravelM * (1 - smooth(u))
        };
      }
      if (tick2 < endTick) {
        const u = (tick2 - contactTick) / followTicks;
        return {
          theta: finishAngle * (1 - (1 - u) ** postExponent),
          rate: omega * (1 - u) ** (postExponent - 1),
          hand: player.swing.handTravelM * 0.35 * smooth(u)
        };
      }
      return { theta: finishAngle, rate: 0, hand: player.swing.handTravelM * 0.35 };
    };
    const pose = (tick2) => {
      const a = angles(tick2), axis = rotateVectorByQuaternion(contactAxis, quaternionFromAxisAngle(axisNormal, a.theta));
      let grip = add5(contactGrip, scale8(contactAxis, a.hand));
      for (let i = 0; i < 64; i++) {
        let changed = false;
        for (let arm = 0; arm < 2; arm++) {
          const offset = scale8(axis, arm * 0.045), hand = add5(grip, offset), distance = sub(hand, shoulders[arm]);
          const length = norm(distance), allowed = clamp(length, minimumReach, reach);
          if (length !== allowed) {
            changed = true;
            const direction = length > 1e-12 ? unit(distance) : { x: 0, y: 0, z: 1 };
            grip = sub(add5(shoulders[arm], scale8(direction, allowed)), offset);
          }
        }
        if (!changed) break;
      }
      for (let arm = 0; arm < 2; arm++) {
        const distance = norm(sub(add5(grip, scale8(axis, arm * 0.045)), shoulders[arm]));
        if (distance < minimumReach - 1e-8 || distance > reach + 1e-8) throw new Error("\u4E21\u8155\u306E\u5230\u9054\u7BC4\u56F2\u3092\u6E80\u305F\u3059\u59FF\u52E2\u3092\u89E3\u3051\u307E\u305B\u3093");
      }
      return { grip, tip: add5(grip, scale8(axis, player.bat.lengthM)), axis, angularVelocity: scale8(axisNormal, a.rate) };
    };
    const swingState = (tick2) => {
      const current = pose(tick2), before = pose(Math.max(0, tick2 - 10)), after = pose(tick2 + 10);
      const dt = (tick2 + 10 - Math.max(0, tick2 - 10)) / p;
      return {
        pose: { grip: current.grip, tip: current.tip },
        linearVelocity: scale8(sub(after.grip, before.grip), 1 / dt),
        angularVelocity: current.angularVelocity
      };
    };
    const rigidAt = (tick2) => createRigidBatStateFromBatterSwingState(swingState(tick2), equipment.batPhysical);
    const physicalAt = (tick2) => advanceAerodynamicPitchState(initial, tick2, parameters);
    const pitchFrames = [];
    let ball = initial, orientation = IDENTITY_QUATERNION, contact = null;
    const perceivedZoneScore = clamp(1 - Math.max(
      Math.abs(target.position.x) / 0.45,
      Math.abs(target.position.y - 1) / 0.8
    ), 0, 1);
    const shouldSwing = player.decision.approach === "SWING" || player.decision.approach === "AUTO" && perceivedZoneScore + player.decision.aggressionWeight * 0.2 >= player.decision.threshold;
    let maximumSpeed = 0;
    const speedAt = (tick2) => {
      const state = swingState(tick2), axis = unit(sub(state.pose.tip, state.pose.grip));
      return norm(add5(state.linearVelocity, cross5(state.angularVelocity, scale8(axis, sweetRadius))));
    };
    if (shouldSwing) {
      for (let tick2 = startTick; tick2 <= endTick; tick2 += 100) maximumSpeed = Math.max(maximumSpeed, speedAt(tick2));
      for (const tick2 of [
        startTick,
        startTick + Math.round(preTicks / 2),
        contactTick,
        contactTick + Math.round(followTicks / 2),
        endTick
      ]) maximumSpeed = Math.max(maximumSpeed, speedAt(tick2));
      if (maximumSpeed > player.capability.maximumSweetSpotSpeedMps * 1.001) throw new Error("\u5B9F\u8ECC\u9053\u306E\u82AF\u901F\u5EA6\u304C\u9078\u624B\u306E\u8EAB\u4F53\u4E0A\u9650\u3092\u8D85\u3048\u307E\u3059");
    }
    const relativeSpeedBound = norm(initial.velocity) + 9.81 * flightEnd / p + player.capability.maximumSweetSpotSpeedMps + omega * Math.max(sweetRadius, player.bat.lengthM - sweetRadius);
    const contactWithin = (anchor, lower, upper) => {
      const at = (tick2) => advanceAerodynamicPitchState(anchor, tick2 - anchor.tick, parameters);
      const separation = (tick2) => measureRigidBatBallSurfaceSeparation(at(tick2), rigidAt(shouldSwing ? tick2 : 0), equipment.ball);
      const search = (a, b, sa, sb) => {
        if (sa <= 0) return a;
        if (b - a <= 1) return sb <= 0 ? b : null;
        if (Math.min(sa, sb) > relativeSpeedBound * (b - a) / p) return null;
        const middle = Math.floor((a + b) / 2), sm = separation(middle);
        return search(a, middle, sa, sm) ?? search(middle, b, sm, sb);
      };
      return search(lower, upper, separation(lower), separation(upper));
    };
    for (let tick2 = 0; tick2 <= flightEnd; tick2 += 1e3) {
      const anchor = ball;
      if (tick2 > 0) {
        const next = advanceAerodynamicPitchState(ball, 1e3, parameters);
        orientation = advanceBaseballOrientation(orientation, scale8(add5(ball.spin, next.spin), 0.5), 1e-3);
        ball = next;
      }
      if (tick2 % 8e3 === 0) pitchFrames.push({ tick: tick2, position: ball.position, spin: ball.spin, orientation });
      {
        const low = contactWithin(anchor, anchor.tick, tick2);
        if (low === null) continue;
        const at = physicalAt(low);
        contact = resolveRigidBatBallContactWithParameterResolver(
          at,
          rigidAt(shouldSwing ? low : 0),
          equipment.ball,
          (k) => resolveWoodBatSpeedResponse(NATHAN_2012_WOOD_LOCAL_CONTACT_PROFILE_V1, k.normalApproachSpeedMps)
        );
        if (contact) {
          if (!shouldSwing) diagnostics.push("\u898B\u9001\u308A\u4E2D\u306E\u9759\u6B62\u30D0\u30C3\u30C8\u306B\u7403\u304C\u63A5\u89E6\u3057\u307E\u3057\u305F\u3002\u516C\u5F0F\u88C1\u5B9A\u306F\u672A\u5B9F\u884C");
          orientation = IDENTITY_QUATERNION;
          let cursor = initial;
          while (cursor.tick < low) {
            const step = Math.min(1e3, low - cursor.tick), next = advanceAerodynamicPitchState(cursor, step, parameters);
            orientation = advanceBaseballOrientation(orientation, scale8(add5(cursor.spin, next.spin), 0.5), step / p);
            cursor = next;
          }
          pitchFrames.push({ tick: low, position: at.position, spin: at.spin, orientation });
          break;
        }
      }
    }
    const batFrames = [];
    const elbow = (shoulder, hand, arm) => {
      const delta = sub(hand, shoulder), distance = norm(delta), direction = unit(delta);
      const along = (upperArm ** 2 - forearm ** 2 + distance ** 2) / (2 * distance);
      let perpendicular = cross5(direction, { x: 0, y: 1, z: 0 });
      if (norm(perpendicular) < 1e-8) perpendicular = cross5(direction, { x: 0, y: 0, z: 1 });
      perpendicular = unit(perpendicular);
      return add5(add5(shoulder, scale8(direction, along)), scale8(
        perpendicular,
        side * (arm === 0 ? 1 : -1) * Math.sqrt(Math.max(0, upperArm ** 2 - along ** 2))
      ));
    };
    const batEnd = Math.max(flightEnd, endTick);
    const batTicks = Array.from({ length: Math.floor(batEnd / 4e3) + 1 }, (_, i) => i * 4e3);
    const exactBatTicks = [.../* @__PURE__ */ new Set([...batTicks, startTick, contactTick, endTick, ...contact ? [contact.tick] : []])].filter((tick2) => tick2 >= 0).sort((a, b) => a - b);
    for (const tick2 of exactBatTicks) {
      const state = swingState(shouldSwing ? tick2 : 0), axis = unit(sub(state.pose.tip, state.pose.grip));
      const sweetSpot = add5(state.pose.grip, scale8(axis, sweetRadius));
      const sweetSpotVelocity = add5(state.linearVelocity, cross5(state.angularVelocity, scale8(axis, sweetRadius)));
      maximumSpeed = Math.max(maximumSpeed, norm(sweetSpotVelocity));
      const hands = [state.pose.grip, add5(state.pose.grip, scale8(axis, 0.045))];
      batFrames.push({
        tick: tick2,
        ...state.pose,
        sweetSpot,
        sweetSpotVelocity,
        body: { shoulders, elbows: hands.map((h, i) => elbow(shoulders[i], h, i)), hands, torsoCenter: { ...shoulderCenter, y: player.body.heightMeters * 0.5 } }
      });
    }
    if (maximumSpeed > player.capability.maximumSweetSpotSpeedMps * 1.001) throw new Error("\u5B9F\u8ECC\u9053\u306E\u82AF\u901F\u5EA6\u304C\u9078\u624B\u306E\u8EAB\u4F53\u4E0A\u9650\u3092\u8D85\u3048\u307E\u3059");
    let flightFrames = [], firstLanding = null;
    if (contact) {
      const throughTick = contact.tick + Math.round(duration * p);
      const free = createFreeBaseballTrajectory({
        initialBall: {
          tick: contact.tick,
          position: contact.ballCenter,
          velocity: contact.exitVelocity,
          spin: contact.exitSpin
        },
        throughTick,
        aerodynamics: parameters,
        ground: {
          radiusM: equipment.ball.radiusM,
          inertiaRatio: equipment.ball.rotationalInertiaFactor,
          gravityMps2: 9.81,
          ticksPerSecond: p,
          restingVerticalSpeedMps: 0.15,
          material: { restitution: 0.4, slidingFriction: 0.3, rollingDecelerationMps2: 0.8, normalSpinDecayPerSecond: 0.5 }
        },
        orientationAtStart: orientation
      });
      const ticks2 = Array.from({ length: Math.floor(duration * 100) + 1 }, (_, i) => contact.tick + i * 1e4);
      flightFrames = free.observe(ticks2);
      firstLanding = free.groundContacts[0]?.incoming.position ?? null;
    }
    const horizontal = contact ? Math.hypot(contact.exitVelocity.x, contact.exitVelocity.z) : 0;
    const exitSpeed = contact ? norm(contact.exitVelocity) : null;
    const exitSpin = contact ? norm(contact.exitSpin) : null;
    const perpendicularSpin = contact && exitSpeed ? norm(cross5(contact.exitSpin, unit(contact.exitVelocity))) : 0;
    const carry = contact && firstLanding ? Math.hypot(firstLanding.x - contact.ballCenter.x, firstLanding.z - contact.ballCenter.z) : null;
    diagnostics.push("\u5168\u8EAB\u306E\u7B4B\u529B\u30FB\u63E1\u308A\u306E\u5F3E\u6027\u30FB\u5B9F\u9078\u624B\u5225\u6821\u6B63\u306F\u672A\u78BA\u5B9A\u3002\u6253\u6483\u306E\u885D\u7A81\u3068\u98DB\u7FD4\u306FCore\u306E\u540C\u3058\u8A08\u7B97\u3092\u4F7F\u7528");
    diagnostics.push("\u885D\u7A81\u5F8C\u306E\u30D0\u30C3\u30C8\u306F\u898F\u5B9A\u30D5\u30A9\u30ED\u30FC\u30B9\u30EB\u30FC\u3002Core\u306E\u53CD\u52D5\u901F\u5EA6\u306F\u8A08\u7B97\u6E08\u307F\u3067\u3059\u304C\u8EAB\u4F53\u3068\u306E\u9023\u6210\u306F\u672A\u5B9F\u88C5");
    return {
      authority: "CORE_PHYSICAL_BATTING_WORKBENCH",
      officialResult: null,
      player,
      sourceValues,
      numericalResolution: { contactClockTicks: 1, motorAuditStepTicks: 100, renderStepTicks: 4e3 },
      trajectoryAuthority: { beforeContact: "BODY_CONSTRAINED_KINEMATICS", afterContact: "PRESCRIBED_FOLLOW_THROUGH_RECOIL_NOT_COUPLED" },
      batFrames,
      pitchFrames,
      flightFrames,
      contact,
      diagnostics,
      metrics: {
        batSpeedMps: maximumSpeed,
        exitSpeedMps: exitSpeed,
        launchAngleDeg: contact ? Math.atan2(contact.exitVelocity.y, horizontal) * 180 / Math.PI : null,
        spinRpm: exitSpin === null ? null : exitSpin * 60 / (2 * Math.PI),
        spinEfficiency: exitSpin ? perpendicularSpin / exitSpin : null,
        carryM: carry
      }
    };
  }

  // src/core/sim/contact/ReferenceBatKinematicsV1.ts
  var add6 = (a, b) => ({ x: a.x + b.x, y: a.y + b.y, z: a.z + b.z });
  var sub2 = (a, b) => ({ x: a.x - b.x, y: a.y - b.y, z: a.z - b.z });
  var scale9 = (a, n) => ({ x: a.x * n, y: a.y * n, z: a.z * n });
  var cross6 = (a, b) => ({ x: a.y * b.z - a.z * b.y, y: a.z * b.x - a.x * b.z, z: a.x * b.y - a.y * b.x });
  var magnitude7 = (a) => Math.hypot(a.x, a.y, a.z);
  var dot5 = (a, b) => a.x * b.x + a.y * b.y + a.z * b.z;
  var fields2 = (a, names) => !!a && typeof a === "object" && !Array.isArray(a) && Object.keys(a).sort().join("|") === names.sort().join("|");
  var vec = (a) => fields2(a, ["x", "y", "z"]) && Object.values(a).every((v) => Number.isFinite(v) && Math.abs(v) <= 1e6);
  var quat = (a) => fields2(a, ["x", "y", "z", "w"]) && Object.values(a).every(Number.isFinite) && Math.abs(Math.hypot(a.x, a.y, a.z, a.w) - 1) < 1e-6;
  var tick = (a) => Number.isSafeInteger(a) && a >= 0;
  var zero = () => ({ x: 0, y: 0, z: 0 });
  var createReferenceBatKinematicsV1 = (raw) => {
    const input = cloneInert(raw);
    if (!fields2(input, ["provenance", "frames", "batLengthM", "sweetSpotT", "sourceTicksPerSecond", "startTick", "ticksPerSecond", "playbackRate", "transform"]) || !fields2(input.provenance, ["clipId", "sourceSha256"]) || !input.provenance.clipId?.trim() || !/^[0-9a-f]{64}$/.test(input.provenance.sourceSha256) || !Array.isArray(input.frames) || input.frames.length < 2 || input.frames.length > 1e4 || ![input.batLengthM, input.sweetSpotT, input.sourceTicksPerSecond, input.ticksPerSecond, input.playbackRate].every(Number.isFinite) || input.batLengthM <= 0 || input.batLengthM > 2 || input.sweetSpotT < 0.65 || input.sweetSpotT > 0.9 || !Number.isSafeInteger(input.sourceTicksPerSecond) || input.sourceTicksPerSecond <= 0 || input.sourceTicksPerSecond > 1e9 || !Number.isSafeInteger(input.ticksPerSecond) || input.ticksPerSecond <= 0 || input.ticksPerSecond > 1e9 || input.playbackRate < 0.01 || input.playbackRate > 20 || !tick(input.startTick) || !fields2(input.transform, ["rotation", "translation", "scale"]) || !quat(input.transform.rotation) || !vec(input.transform.translation) || !Number.isFinite(input.transform.scale) || input.transform.scale <= 0 || input.transform.scale > 10 || input.frames.some((f, i) => !fields2(f, ["tick", "grip", "orientation"]) || !tick(f.tick) || !vec(f.grip) || !quat(f.orientation) || i > 0 && f.tick <= input.frames[i - 1].tick)) throw new Error("invalid sampled reference bat trajectory");
    const rotation = normalizeQuaternion(input.transform.rotation), length = input.batLengthM * input.transform.scale;
    const radius = length * input.sweetSpotT, speedScale = input.transform.scale * input.playbackRate;
    const frames = input.frames.map((f) => ({ ...f, orientation: normalizeQuaternion(f.orientation) }));
    const segments = frames.slice(0, -1).map((one, i) => {
      const two = frames[i + 1], dt = (two.tick - one.tick) / input.sourceTicksPerSecond;
      let next = two.orientation;
      if (Object.keys(one.orientation).reduce((v, k) => v + one.orientation[k] * next[k], 0) < 0)
        next = { x: -next.x, y: -next.y, z: -next.z, w: -next.w };
      const q = normalizeQuaternion(multiplyQuaternions(next, { x: -one.orientation.x, y: -one.orientation.y, z: -one.orientation.z, w: one.orientation.w }));
      const sine = Math.hypot(q.x, q.y, q.z), angle = 2 * Math.atan2(sine, Math.max(0, q.w));
      const omega = sine < 1e-12 ? zero() : scale9({ x: q.x, y: q.y, z: q.z }, angle / (sine * dt));
      const velocity = scale9(sub2(two.grip, one.grip), 1 / dt);
      const axis = rotateVectorByQuaternion({ x: 0, y: 1, z: 0 }, one.orientation);
      const speedBound = magnitude7(velocity) * speedScale + magnitude7(cross6(omega, axis)) * radius * input.playbackRate;
      const linear = scale9(velocity, speedScale), rotational = scale9(cross6(omega, axis), radius * input.playbackRate);
      const omegaNorm = magnitude7(omega), turnAxis = omegaNorm ? scale9(omega, 1 / omegaNorm) : zero();
      const a = dot5(linear, rotational), b = dot5(linear, cross6(turnAxis, rotational));
      const candidates = [0, angle], maximumPhase = Math.atan2(b, a);
      for (const phase of [maximumPhase, maximumPhase + 2 * Math.PI, maximumPhase - 2 * Math.PI])
        if (phase >= 0 && phase <= angle) candidates.push(phase);
      const peak = Math.max(...candidates.map((phase) => a * Math.cos(phase) + b * Math.sin(phase)));
      const maximumSweetSpeed = Math.sqrt(Math.max(0, dot5(linear, linear) + dot5(rotational, rotational) + 2 * peak));
      return { one, two, dt, omega, velocity, speedBound, maximumSweetSpeed };
    });
    const first = frames[0], last = frames[frames.length - 1];
    const sampleCoordinate = (sourceTick, atTick, side) => {
      let grip, orientation, linear = zero(), angular = zero();
      if (sourceTick < first.tick || sourceTick > last.tick || sourceTick === first.tick && side === "incoming" || sourceTick === last.tick && side === "outgoing") {
        const frame = sourceTick <= first.tick ? first : last;
        grip = frame.grip;
        orientation = frame.orientation;
      } else {
        let lo = 0, hi = segments.length - 1;
        while (lo < hi) {
          const mid = Math.ceil((lo + hi) / 2);
          if (side === "incoming" ? segments[mid].one.tick < sourceTick : segments[mid].one.tick <= sourceTick) lo = mid;
          else hi = mid - 1;
        }
        const s = segments[lo], u = (sourceTick - s.one.tick) / (s.two.tick - s.one.tick);
        grip = add6(s.one.grip, scale9(sub2(s.two.grip, s.one.grip), u));
        orientation = normalizeQuaternion(multiplyQuaternions(quaternionFromAxisAngle(s.omega, magnitude7(s.omega) * s.dt * u), s.one.orientation));
        linear = scale9(rotateVectorByQuaternion(s.velocity, rotation), speedScale);
        angular = scale9(rotateVectorByQuaternion(s.omega, rotation), input.playbackRate);
      }
      const worldGrip = add6(input.transform.translation, scale9(rotateVectorByQuaternion(grip, rotation), input.transform.scale));
      const worldOrientation = normalizeQuaternion(multiplyQuaternions(rotation, orientation));
      const axis = rotateVectorByQuaternion({ x: 0, y: 1, z: 0 }, worldOrientation);
      const state = { pose: { grip: worldGrip, tip: add6(worldGrip, scale9(axis, length)) }, linearVelocity: linear, angularVelocity: angular };
      return {
        tick: atTick,
        sourceTick: Math.max(first.tick, Math.min(last.tick, sourceTick)),
        orientation: worldOrientation,
        state,
        sweetSpot: add6(worldGrip, scale9(axis, radius)),
        sweetSpotVelocity: add6(linear, cross6(angular, scale9(axis, radius)))
      };
    };
    const sampleContinuous = (atTick) => {
      if (!Number.isFinite(atTick) || atTick < 0) throw new Error("invalid reference bat observation tick");
      const sourceTick = first.tick + (atTick - input.startTick) / input.ticksPerSecond * input.sourceTicksPerSecond * input.playbackRate;
      return sampleCoordinate(sourceTick, atTick, "outgoing");
    };
    const sampleAtSourceTick = (sourceTick, side = "outgoing") => {
      if (!Number.isFinite(sourceTick) || sourceTick < 0 || !["incoming", "outgoing"].includes(side)) throw new Error("invalid original reference source tick");
      const atTick = input.startTick + (sourceTick - first.tick) / input.sourceTicksPerSecond / input.playbackRate * input.ticksPerSecond;
      return sampleCoordinate(sourceTick, atTick, side);
    };
    const sample = (atTick) => {
      if (!tick(atTick)) throw new Error("invalid reference bat observation tick");
      return sampleContinuous(atTick);
    };
    return Object.freeze({
      authority: "SAMPLED_RIGID_REFERENCE_RESEARCH",
      nativeAdmission: false,
      officialResult: null,
      provenance: Object.freeze({ ...input.provenance }),
      batLengthM: length,
      sweetSpotT: input.sweetSpotT,
      maximumSweetSpotSpeedUpperBoundMps: Math.max(...segments.map((s) => s.speedBound)),
      maximumSweetSpotSpeedMps: Math.max(...segments.map((s) => s.maximumSweetSpeed)),
      maximumGripSpeedMps: Math.max(...segments.map((s) => magnitude7(s.velocity) * speedScale)),
      maximumAngularSpeedRadPerSecond: Math.max(...segments.map((s) => magnitude7(s.omega) * input.playbackRate)),
      sample,
      sampleContinuous,
      sampleAtSourceTick
    });
  };

  // src/core/sim/contact/BatBallContact.ts
  var DEFAULT_CONTACT_PARAMETERS = Object.freeze({
    ballRadius: 0.0366,
    batRadius: 0.033,
    restitution: 0.52,
    tangentialRetention: 0.82,
    spinTransfer: 0.18
  });
  var TICKS_PER_SECOND = 1e6;
  var add7 = (a, b) => ({
    x: a.x + b.x,
    y: a.y + b.y,
    z: a.z + b.z
  });
  var subtract6 = (a, b) => ({
    x: a.x - b.x,
    y: a.y - b.y,
    z: a.z - b.z
  });
  var scale10 = (value, scalar) => ({
    x: value.x * scalar,
    y: value.y * scalar,
    z: value.z * scalar
  });
  var cross7 = (a, b) => ({
    x: a.y * b.z - a.z * b.y,
    y: a.z * b.x - a.x * b.z,
    z: a.x * b.y - a.y * b.x
  });
  var sampleCompatibilityBatterSwingState = (swing, offsetTicks, ticksPerSecond = TICKS_PER_SECOND) => {
    if (!Number.isSafeInteger(offsetTicks) || offsetTicks < 0) {
      throw new Error("swing sample offsetTicks must be a non-negative safe integer");
    }
    if (!Number.isSafeInteger(ticksPerSecond) || ticksPerSecond <= 0) {
      throw new Error("swing sample ticksPerSecond must be a positive safe integer");
    }
    const dt = offsetTicks / ticksPerSecond;
    const gripTranslation = scale10(swing.linearVelocity, dt);
    const batAxis = subtract6(swing.pose.tip, swing.pose.grip);
    const tipAngularTranslation = scale10(cross7(swing.angularVelocity, batAxis), dt);
    return {
      pose: {
        grip: add7(swing.pose.grip, gripTranslation),
        tip: add7(add7(swing.pose.tip, gripTranslation), tipAngularTranslation)
      },
      linearVelocity: swing.linearVelocity,
      angularVelocity: swing.angularVelocity
    };
  };

  // src/core/sim/pitching/AerodynamicRigidBatSwingingPitchPhysicalResult.ts
  var SWING_KINEMATICS_V1_CONSERVATIVE_MAX_BAT_POINT_SPEED_MPS = 200;
  var createRigidBatSwingWindowFromSampledV1 = (raw, rawPhysical, interval) => {
    const sampledKinematicsV1 = cloneInert(raw), physical2 = cloneInert(rawPhysical), motion = createReferenceBatKinematicsV1(sampledKinematicsV1);
    const first = sampledKinematicsV1.frames[0], last = sampledKinematicsV1.frames.at(-1);
    const scope = interval === void 0 ? void 0 : cloneInert(interval);
    if (scope && Object.keys(scope).sort().join("|") !== "endTick|startTick") throw new Error("invalid sampled rigid swing scope");
    const startTick = scope?.startTick ?? sampledKinematicsV1.startTick;
    const endTick = scope?.endTick ?? Math.ceil(sampledKinematicsV1.startTick + (last.tick - first.tick) / sampledKinematicsV1.sourceTicksPerSecond / sampledKinematicsV1.playbackRate * sampledKinematicsV1.ticksPerSecond);
    if (!Number.isSafeInteger(startTick) || startTick < 0 || !Number.isSafeInteger(endTick) || endTick < startTick)
      throw new Error("invalid sampled rigid swing interval");
    const stateAtStart = motion.sample(startTick).state;
    createRigidBatStateFromBatterSwingState(stateAtStart, physical2);
    const freeze7 = (value) => {
      if (value && typeof value === "object") {
        Object.values(value).forEach(freeze7);
        Object.freeze(value);
      }
      return value;
    };
    return freeze7({ startTick, endTick, ticksPerSecond: sampledKinematicsV1.ticksPerSecond, stateAtStart, physical: physical2, sampledKinematicsV1 });
  };
  var EPSILON8 = 1e-12;
  var magnitude8 = (value) => Math.hypot(
    value.x,
    value.y,
    value.z
  );
  var subtract7 = (a, b) => ({
    x: a.x - b.x,
    y: a.y - b.y,
    z: a.z - b.z
  });
  var cross8 = (a, b) => ({
    x: a.y * b.z - a.z * b.y,
    y: a.z * b.x - a.x * b.z,
    z: a.x * b.y - a.y * b.x
  });
  var add8 = (a, b) => ({
    x: a.x + b.x,
    y: a.y + b.y,
    z: a.z + b.z
  });
  var validate2 = (input) => {
    const { trajectory, swing } = input;
    if (!Number.isSafeInteger(
      swing.startTick
    ) || !Number.isSafeInteger(
      swing.endTick
    ) || swing.endTick < swing.startTick || swing.startTick < trajectory.start.tick || swing.endTick > trajectory.endTick) {
      throw new Error(
        "rigid bat swing window must lie inside the aerodynamic pitch trajectory"
      );
    }
    if (!Number.isSafeInteger(
      swing.ticksPerSecond
    ) || swing.ticksPerSecond <= 0 || swing.ticksPerSecond !== trajectory.parameters.ticksPerSecond) {
      throw new Error(
        "rigid bat swing and aerodynamic pitch must share ticksPerSecond"
      );
    }
    const kinematics = swing.kinematicsV1;
    if (kinematics !== void 0 && (kinematics.startTick !== swing.startTick || kinematics.endTick !== swing.endTick || kinematics.ticksPerSecond !== swing.ticksPerSecond)) {
      throw new Error(
        "swing kinematics v1 interval must exactly match rigid bat swing window"
      );
    }
  };
  var sampleSwing = (swing, tick2) => swing.kinematicsV1 !== void 0 ? sampleSwingStateV1(
    swing.kinematicsV1,
    tick2
  ) : sampleCompatibilityBatterSwingState(
    swing.stateAtStart,
    tick2 - swing.startTick,
    swing.ticksPerSecond
  );
  var maximumClosingSpeed = (input, sampledBatPointSpeed) => {
    const durationSeconds = (input.swing.endTick - input.trajectory.start.tick) / input.swing.ticksPerSecond;
    const wind = input.trajectory.parameters.aerodynamics.windVelocityMps;
    const releaseAirRelative = subtract7(
      input.trajectory.start.velocity,
      wind
    );
    const conservativePitchSpeed = magnitude8(releaseAirRelative) + Math.abs(
      input.trajectory.parameters.gravityY
    ) * durationSeconds + magnitude8(wind);
    if (sampledBatPointSpeed !== void 0) return conservativePitchSpeed + sampledBatPointSpeed;
    if (input.swing.kinematicsV1 !== void 0) {
      return conservativePitchSpeed + SWING_KINEMATICS_V1_CONSERVATIVE_MAX_BAT_POINT_SPEED_MPS;
    }
    const batAxis = subtract7(
      input.swing.stateAtStart.pose.tip,
      input.swing.stateAtStart.pose.grip
    );
    const gripSpeed = magnitude8(
      input.swing.stateAtStart.linearVelocity
    );
    const tipSpeed = magnitude8(
      add8(
        input.swing.stateAtStart.linearVelocity,
        cross8(
          input.swing.stateAtStart.angularVelocity,
          batAxis
        )
      )
    );
    return conservativePitchSpeed + Math.max(
      gripSpeed,
      tipSpeed
    );
  };
  var validateV1PointSpeed = (swing, sampledSwing) => {
    if (swing.kinematicsV1 === void 0) {
      return;
    }
    const batAxis = subtract7(
      sampledSwing.pose.tip,
      sampledSwing.pose.grip
    );
    const gripSpeed = magnitude8(
      sampledSwing.linearVelocity
    );
    const tipSpeed = magnitude8(
      add8(
        sampledSwing.linearVelocity,
        cross8(
          sampledSwing.angularVelocity,
          batAxis
        )
      )
    );
    if (Math.max(
      gripSpeed,
      tipSpeed
    ) > SWING_KINEMATICS_V1_CONSERVATIVE_MAX_BAT_POINT_SPEED_MPS) {
      throw new Error(
        "swing kinematics v1 exceeded conservative bat-point speed safety bound"
      );
    }
  };
  var resolveAerodynamicRigidBatSwing = (input) => {
    validate2(input);
    const rawSampled = input.swing.sampledKinematicsV1;
    if (Object.hasOwn(input.swing, "sampledKinematicsV1") && !rawSampled) throw new Error("invalid sampled rigid swing model");
    if (rawSampled && input.swing.kinematicsV1) throw new Error("rigid swing cannot select two kinematic models");
    const sampled = rawSampled ? createReferenceBatKinematicsV1(rawSampled) : null;
    let pointSpeed;
    if (sampled && rawSampled) {
      const seed = sampled.sample(input.swing.startTick).state, actual = input.swing.stateAtStart;
      const sameVector = (a, b) => a && b && a.x === b.x && a.y === b.y && a.z === b.z;
      if (rawSampled.ticksPerSecond !== input.swing.ticksPerSecond || !sameVector(seed.pose.grip, actual.pose.grip) || !sameVector(seed.pose.tip, actual.pose.tip) || !sameVector(seed.linearVelocity, actual.linearVelocity) || !sameVector(seed.angularVelocity, actual.angularVelocity))
        throw new Error("sampled rigid swing original clock or seed differs");
      createRigidBatStateFromBatterSwingState(input.swing.stateAtStart, input.swing.physical);
      const radius = Math.max(...input.swing.physical.radiusProfile.knots.map((k) => k.radiusM));
      pointSpeed = sampled.maximumGripSpeedMps + sampled.maximumAngularSpeedRadPerSecond * (sampled.batLengthM + radius);
      if (!Number.isFinite(pointSpeed)) throw new Error("sampled rigid swing point-speed bound overflow");
    }
    const closingSpeed = maximumClosingSpeed(input, pointSpeed);
    let tick2 = input.swing.startTick;
    let pitch = sampleAerodynamicPitchTrajectory(
      input.trajectory,
      tick2
    );
    while (tick2 <= input.swing.endTick) {
      const sampledSwing = sampled ? sampled.sample(tick2).state : sampleSwing(input.swing, tick2);
      validateV1PointSpeed(
        input.swing,
        sampledSwing
      );
      const rigidBat = createRigidBatStateFromBatterSwingState(
        sampledSwing,
        input.swing.physical
      );
      const separation = measureRigidBatBallSurfaceSeparation(
        pitch,
        rigidBat,
        input.ball
      );
      if (separation <= 0) {
        const contact = resolveRigidBatBallContactWithParameterResolver(
          pitch,
          rigidBat,
          input.ball,
          input.parameterResolver
        );
        if (contact !== null) {
          return {
            kind: "contact",
            contact
          };
        }
      }
      if (tick2 === input.swing.endTick) {
        break;
      }
      const safeAdvanceTicks = separation > 0 && closingSpeed > EPSILON8 ? Math.floor(
        separation / closingSpeed * input.swing.ticksPerSecond
      ) - 1 : 1;
      const advanceTicks = Math.min(
        input.swing.endTick - tick2,
        Math.max(
          1,
          safeAdvanceTicks
        )
      );
      pitch = sampled ? sampleAerodynamicPitchTrajectory(input.trajectory, tick2 + advanceTicks) : advanceAerodynamicPitchState(pitch, advanceTicks, input.trajectory.parameters);
      tick2 += advanceTicks;
    }
    return {
      kind: "swinging_miss",
      adjudicationTick: input.swing.endTick
    };
  };

  // src/integration/browser/ReferenceBattingWorkbench.ts
  var add9 = (a, b) => ({ x: a.x + b.x, y: a.y + b.y, z: a.z + b.z });
  var scale11 = (a, n) => ({ x: a.x * n, y: a.y * n, z: a.z * n });
  var norm2 = (a) => Math.hypot(a.x, a.y, a.z);
  var cross9 = (a, b) => ({ x: a.y * b.z - a.z * b.y, y: a.z * b.x - a.x * b.z, z: a.x * b.y - a.y * b.x });
  var simulateReferenceBattingWorkbench = (raw) => {
    const input = cloneInert(raw), player = createWorkbenchPlayer(input.player), reference = createReferenceBatKinematicsV1(input.referenceTrajectory);
    const p = WORKBENCH_TICKS_PER_SECOND, duration = input.throughSeconds ?? 8;
    if (!Number.isFinite(duration) || duration < 1 || duration > 20 || input.referenceTrajectory.ticksPerSecond !== p)
      throw new Error("invalid reference experiment duration or clock");
    if (Math.abs(reference.batLengthM - player.bat.lengthM) > 1e-9 || reference.sweetSpotT !== player.bat.sweetSpotT)
      throw new Error("\u53C2\u8003\u30D0\u30C3\u30C8\u306E\u9577\u3055\u30FB\u82AF\u3068\u9078\u624B\u306E\u7528\u5177\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
    if (input.referenceTrajectory.startTick < player.capability.motorLatencyTicks) throw new Error("\u53C2\u8003\u30B9\u30A4\u30F3\u30B0\u59CB\u52D5\u304C\u9078\u624B\u306E\u53CD\u5FDC\u6642\u9593\u3088\u308A\u65E9\u3059\u304E\u307E\u3059");
    if (reference.maximumSweetSpotSpeedMps > player.capability.maximumSweetSpotSpeedMps * (1 + 1e-10))
      throw new Error("\u53C2\u8003\u8ECC\u9053\u306E\u5B9F\u901F\u5EA6\u304C\u9078\u624B\u306E\u8EAB\u4F53\u4E0A\u9650\u3092\u8D85\u3048\u307E\u3059");
    const frames = input.referenceTrajectory.frames, refEnd = input.referenceTrajectory.startTick + (frames[frames.length - 1].tick - frames[0].tick) / input.referenceTrajectory.sourceTicksPerSecond / input.referenceTrajectory.playbackRate * p;
    if (refEnd > 20 * p) throw new Error("reference experiment clip exceeds twenty seconds");
    const sourceValues = exportWorkbenchPlayerSources(player), equipment = sourceValues.equipment;
    const { initial, parameters, flightEnd } = createWorkbenchPitchTrajectory(input.pitch);
    const trajectory = { start: initial, endTick: flightEnd, parameters };
    const swing = createRigidBatSwingWindowFromSampledV1(input.referenceTrajectory, equipment.batPhysical, { startTick: initial.tick, endTick: flightEnd });
    const outcome = resolveAerodynamicRigidBatSwing({
      trajectory,
      swing,
      ball: equipment.ball,
      parameterResolver: (k) => resolveWoodBatSpeedResponse(NATHAN_2012_WOOD_LOCAL_CONTACT_PROFILE_V1, k.normalApproachSpeedMps)
    });
    const contact = outcome.kind === "contact" ? outcome.contact : null, end = contact?.tick ?? flightEnd;
    let ball = initial, orientation = IDENTITY_QUATERNION;
    const pitchFrames = [];
    pitchFrames.push({ tick: ball.tick, position: ball.position, spin: ball.spin, orientation });
    while (ball.tick < end) {
      const step = Math.min(1e3, end - ball.tick), next = advanceAerodynamicPitchState(ball, step, parameters);
      orientation = advanceBaseballOrientation(orientation, scale11(add9(ball.spin, next.spin), 0.5), step / p);
      ball = next;
      if (ball.tick % 8e3 === 0 || ball.tick === end) pitchFrames.push({ tick: ball.tick, position: ball.position, spin: ball.spin, orientation });
    }
    const batEnd = Math.ceil(Math.max(flightEnd, refEnd)), batTicks = /* @__PURE__ */ new Set([0, batEnd]);
    for (let tick2 = 0; tick2 <= batEnd; tick2 += 4e3) batTicks.add(tick2);
    if (contact) batTicks.add(contact.tick);
    const batFrames = [...batTicks].sort((a, b) => a - b).map((tick2) => {
      const f = reference.sample(tick2);
      return { tick: tick2, ...f.state.pose, orientation: f.orientation, sweetSpot: f.sweetSpot, sweetSpotVelocity: f.sweetSpotVelocity, body: null };
    });
    let flightFrames = [], firstLanding = null;
    if (contact) {
      const free = createFreeBaseballTrajectory({
        initialBall: {
          tick: contact.tick,
          position: contact.ballCenter,
          velocity: contact.exitVelocity,
          spin: contact.exitSpin
        },
        throughTick: contact.tick + Math.round(duration * p),
        aerodynamics: parameters,
        ground: {
          radiusM: equipment.ball.radiusM,
          inertiaRatio: equipment.ball.rotationalInertiaFactor,
          gravityMps2: 9.81,
          ticksPerSecond: p,
          restingVerticalSpeedMps: 0.15,
          material: { restitution: 0.4, slidingFriction: 0.3, rollingDecelerationMps2: 0.8, normalSpinDecayPerSecond: 0.5 }
        },
        orientationAtStart: orientation
      });
      flightFrames = free.observe(Array.from({ length: Math.floor(duration * 100) + 1 }, (_, i) => contact.tick + i * 1e4));
      firstLanding = free.groundContacts[0]?.incoming.position ?? null;
    }
    const horizontal = contact ? Math.hypot(contact.exitVelocity.x, contact.exitVelocity.z) : 0;
    const exitSpeed = contact ? norm2(contact.exitVelocity) : null, exitSpin = contact ? norm2(contact.exitSpin) : null;
    const perpendicularSpin = contact && exitSpeed ? norm2(cross9(contact.exitSpin, scale11(contact.exitVelocity, 1 / exitSpeed))) : 0;
    return {
      authority: "CORE_REFERENCE_BAT_RESEARCH",
      nativeAdmission: false,
      officialResult: null,
      player,
      sourceValues,
      bodyConstraintsApplied: false,
      referenceProvenance: reference.provenance,
      trajectoryAuthority: { beforeContact: "SAMPLED_REFERENCE_KINEMATICS", afterContact: "PRESCRIBED_REFERENCE_REPLAY_RECOIL_NOT_COUPLED" },
      numericalResolution: { contactClockTicks: 1, renderStepTicks: 4e3, referenceInterpolation: "LINEAR_GRIP_SHORTEST_SO3" },
      batFrames,
      pitchFrames,
      flightFrames,
      contact,
      diagnostics: [
        "\u53C2\u8003\u30D0\u30C3\u30C8\u306E\u307F\u306E\u7814\u7A76\u8A66\u9A13\u3002\u8EAB\u4F53\u5230\u9054\u7BC4\u56F2\u30FB\u5224\u65AD\u30FB\u4E88\u6E2C\u30FB\u4F4D\u7F6E\u8AA4\u5DEE\u306F\u672A\u9069\u7528\u3001\u53CD\u5FDC\u6642\u9593\u3068\u5B9F\u901F\u5EA6\u4E0A\u9650\u30FB\u7528\u5177\u306F\u691C\u8A3C",
        "\u6295\u7403\u30FB\u885D\u7A81\u30FB\u6253\u7403\u306E\u98DB\u7FD4/\u5730\u4E0A\u7269\u7406\u306F\u5171\u901ACore\u3002\u885D\u7A81\u5F8C\u306E\u30D0\u30C3\u30C8\u306F\u53C2\u8003\u8ECC\u9053\u3092\u7D99\u7D9A\u3057\u53CD\u52D5\u306F\u8EAB\u4F53\u306B\u9023\u6210\u3057\u3066\u3044\u307E\u305B\u3093",
        "\u5B9F\u6E2C\u30AD\u30FC\u9593\u306F\u7DDA\u5F62/SO(3)\u88DC\u9593\u3002\u8EF8\u56DE\u308A\u56DE\u8EE2\u306F\u672A\u8A08\u6E2C\u3067\u3059\u3002\u6B63\u5F0FNative\u30E2\u30C7\u30EB\u30FB\u516C\u5F0F\u88C1\u5B9A\u306E\u53D7\u5165\u8A3C\u62E0\u306B\u306F\u3067\u304D\u307E\u305B\u3093"
      ],
      metrics: {
        batSpeedMps: reference.maximumSweetSpotSpeedMps,
        exitSpeedMps: exitSpeed,
        launchAngleDeg: contact ? Math.atan2(contact.exitVelocity.y, horizontal) * 180 / Math.PI : null,
        spinRpm: exitSpin === null ? null : exitSpin * 60 / (2 * Math.PI),
        spinEfficiency: exitSpin ? perpendicularSpin / exitSpin : null,
        carryM: contact && firstLanding ? Math.hypot(firstLanding.x - contact.ballCenter.x, firstLanding.z - contact.ballCenter.z) : null
      }
    };
  };

  // src/core/sim/contact/MeasuredBatAxisReferenceV1.ts
  var add10 = (a, b) => ({ x: a.x + b.x, y: a.y + b.y, z: a.z + b.z });
  var sub3 = (a, b) => ({ x: a.x - b.x, y: a.y - b.y, z: a.z - b.z });
  var scale12 = (a, n) => ({ x: a.x * n, y: a.y * n, z: a.z * n });
  var norm3 = (a) => Math.hypot(a.x, a.y, a.z);
  var dot6 = (a, b) => a.x * b.x + a.y * b.y + a.z * b.z;
  var cross10 = (a, b) => ({ x: a.y * b.z - a.z * b.y, y: a.z * b.x - a.x * b.z, z: a.x * b.y - a.y * b.x });
  var fields3 = (value, names) => !!value && typeof value === "object" && !Array.isArray(value) && Object.keys(value).sort().join("|") === [...names].sort().join("|");
  var vector = (value) => fields3(value, ["x", "y", "z"]) && Object.values(value).every((n) => Number.isFinite(n) && Math.abs(n) <= 1e6);
  var freeze3 = (value) => {
    if (value && typeof value === "object") {
      Object.values(value).forEach(freeze3);
      Object.freeze(value);
    }
    return value;
  };
  function assert(value, message) {
    if (!value) throw new Error("Measured bat axis reference: " + message);
  }
  var minimalTurn = (from, to, initial = false) => {
    const cosine = Math.max(-1, Math.min(1, dot6(from, to))), axis = cross10(from, to), sine = norm3(axis);
    if (sine <= 1e-12) {
      if (cosine >= 0) return { w: 1, x: 0, y: 0, z: 0 };
      assert(initial, "antipodal source axes have no measured intermediate path");
      return { w: 0, x: 1, y: 0, z: 0 };
    }
    const half = Math.atan2(sine, cosine) / 2, vector2 = scale12(axis, Math.sin(half) / sine);
    return normalizeQuaternion({ w: Math.cos(half), ...vector2 });
  };
  var createMeasuredBatAxisReferenceV1 = (raw) => {
    const input = cloneInert(raw);
    assert(fields3(input, [
      "provenance",
      "frames",
      "batLengthM",
      "sweetSpotFromTipM",
      "handReferenceFromKnobM",
      "maximumHandResidualM",
      "sourceTicksPerSecond",
      "startTick",
      "ticksPerSecond",
      "playbackRate",
      "transform"
    ]) && Array.isArray(input.frames) && input.frames.length >= 2 && input.frames.length <= 1e4, "invalid measured frames or fields");
    const length = input.batLengthM, radius = length - input.sweetSpotFromTipM;
    assert([length, input.sweetSpotFromTipM, input.handReferenceFromKnobM, input.maximumHandResidualM].every(Number.isFinite) && length > 0 && length <= 2 && input.sweetSpotFromTipM > 0 && radius > 0 && input.handReferenceFromKnobM >= 0 && input.handReferenceFromKnobM < radius && input.maximumHandResidualM >= 0 && input.maximumHandResidualM <= length, "invalid declared binding");
    let priorAxis = { x: 0, y: 1, z: 0 }, orientation = { w: 1, x: 0, y: 0, z: 0 };
    const residuals = [];
    const frames = input.frames.map((frame, index) => {
      assert(fields3(frame, ["tick", "handReference", "sweetSpot"]) && vector(frame.handReference) && vector(frame.sweetSpot), "missing measured point");
      const delta = sub3(frame.sweetSpot, frame.handReference), distance = norm3(delta);
      assert(Number.isFinite(distance) && distance > 1e-9, "zero measured bat axis");
      const axis = scale12(delta, 1 / distance);
      orientation = normalizeQuaternion(multiplyQuaternions(minimalTurn(priorAxis, axis, index === 0), orientation));
      priorAxis = axis;
      const grip = sub3(frame.sweetSpot, scale12(axis, radius));
      const residual = norm3(sub3(add10(grip, scale12(axis, input.handReferenceFromKnobM)), frame.handReference));
      assert(residual <= input.maximumHandResidualM, "hand reference residual exceeds the declared bound");
      residuals.push(residual);
      return { tick: frame.tick, grip, orientation };
    });
    const reference = {
      provenance: input.provenance,
      frames,
      batLengthM: length,
      sweetSpotT: radius / length,
      sourceTicksPerSecond: input.sourceTicksPerSecond,
      startTick: input.startTick,
      ticksPerSecond: input.ticksPerSecond,
      playbackRate: input.playbackRate,
      transform: input.transform
    };
    createReferenceBatKinematicsV1(reference);
    return freeze3({
      reference,
      measurements: input.frames,
      handResidualsM: residuals,
      maximumHandResidualM: Math.max(...residuals),
      axialPhase: "DECLARED_MINIMUM_ROTATION_TRANSPORT",
      nativeAdmission: false,
      officialResult: null
    });
  };

  // src/core/sim/fielding/LiveFielderAvoidanceV1.ts
  var LIVE_FIELDER_AVOIDANCE_POLICY_V1 = Object.freeze({
    clearanceMeters: 0.02,
    softClearanceMeters: 0.35,
    softClearanceCostWeight: 2,
    numericalReserveMeters: 1e-8,
    rescuePasses: 4,
    improvementPasses: 2
  });

  // src/core/sim/fielding/LiveHandPreparationV1.ts
  var zero2 = Object.freeze({ x: 0, y: 0, z: 0 });

  // src/core/sim/fielding/LiveFieldRoleAssignmentV1.ts
  var LIVE_FIELD_ROLE_POLICY_V1 = Object.freeze({
    switchCostSeconds: 0.25,
    lateArrivalCost: 2,
    backupDepthMeters: 10,
    pickupBackupDepthMeters: 6,
    directThrowSeconds: 0.9,
    backupHomeAbandonmentCost: 0.1,
    secondaryResponsibilityCostSeconds: 1.5,
    otherResponsibilityCostSeconds: 5,
    catcherHomePriorityCostSeconds: 8,
    supportSeparationMeters: 4
  });

  // src/core/sim/fielding/LiveRunnerAdvancePolicyV1.ts
  var LIVE_RUNNER_ADVANCE_POLICY_V1 = Object.freeze({
    safetyMarginSeconds: 0.35,
    recognitionSeconds: 0
  });

  // src/core/sim/fielding/LiveFieldHandlerSelectionV1.ts
  var LIVE_FIELD_HANDLER_POLICY_V1 = Object.freeze({
    interceptionWindowSeconds: 0,
    switchBurdenSeconds: 0.25,
    minimumPursuitCostWeight: 0.25,
    maximumPursuitCostWeight: 4
  });

  // src/core/sim/fielding/LiveRelayPlanV1.ts
  var LIVE_RELAY_PLAN_POLICY_V1 = Object.freeze({
    maximumIntermediateReceivers: 2,
    maximumEvaluatedRoutes: 8,
    minimumProgressMeters: 0.28,
    baseTouchRadiusMeters: 0.28
  });

  // src/core/sim/running/LiveRunnerMotionV1.ts
  var TWO_PI = 2 * Math.PI;

  // src/core/sim/fielding/LiveFieldPlayV1.ts
  var LIVE_FIELD_TEST_MODEL_V1 = Object.freeze({
    basis: "EXPLICIT_SYNTHETIC_LIVE_FIELD_CONTROL_V1",
    controlSeconds: 0.04,
    frameSeconds: 0.055,
    bodyRadiusMeters: 0.24,
    roleAssignment: LIVE_FIELD_ROLE_POLICY_V1,
    fielderAvoidance: LIVE_FIELDER_AVOIDANCE_POLICY_V1,
    catchApproachCostFraction: 0.3,
    bodyMaterial: Object.freeze({ restitution: 0.25, tangentialDamping: 0.3, spinDamping: 0.1 }),
    wallMaterial: Object.freeze({
      restitution: 0.25,
      tangentialDamping: 0.3,
      spinDamping: 0.1,
      groundNormalHysteresisLossJ: 1e-4,
      maximumCompressionMeters: 2e-3
    }),
    sensorPrediction: Object.freeze({
      horizonSeconds: 8,
      maximumPositionResidualMeters: 0.01,
      maximumVelocityResidualMps: 0.05,
      maximumSpinResidualRadPerSecond: 0.5,
      nearInterceptStepSeconds: 0.02,
      nearInterceptThroughSeconds: 0.5,
      farInterceptStepSeconds: 0.1
    }),
    fenceMotorStoppingReserveMeters: 0.02,
    throwHand: Object.freeze({ heightAboveHipMeters: 0.7, forwardMeters: 0.5, readyRadiusUsesBallRadius: true }),
    neuralReactionCalibrated: false,
    muscleTorqueCalibrated: false,
    tagUpAppealsImplemented: true
  });

  // src/integration/browser/MeasuredBatFieldRegistrationV1.ts
  var MEASURED_BAT_FIELD_REGISTRATION_V1 = Object.freeze({
    authority: "OBP_ORIGINAL_LAB_TO_FIRST_BASE_POSITIVE_X_FIELD_V1",
    rawMeasuredArtifactUnchanged: true,
    storedPositionToField: "(-x,y,z)",
    originalLabPositionToField: "(-labY,labZ,labX)",
    quaternionToField: "(w,x,-y,-z)",
    linearVelocityToField: "(-vx,vy,vz)",
    angularVelocityToField: "(wx,-wy,-wz); axial vector det(M)*M",
    rightHandedBox: "THIRD_BASE_NEGATIVE_X",
    leftHandedBox: "FIRST_BASE_POSITIVE_X"
  });

  // src/integration/browser/LiveTraitProfilesV1.ts
  var freeze4 = (value) => {
    if (value && typeof value === "object") {
      Object.values(value).forEach(freeze4);
      Object.freeze(value);
    }
    return value;
  };
  var catalog = freeze4([{
    familyId: "bad_ball_hitting",
    label: "\u60AA\u7403\u6253\u3061",
    lifecycleClass: "LEARNED_MASTERY_PERSISTENT",
    sourceRoute: "SOURCE_EXECUTION",
    states: [{ stateId: "LEARNED", label: "\u60AA\u7403\u6253\u3061", color: "blue" }],
    sourcePaths: ["physical.badBallControl", "workbenchPlayer.traits.badBallControl"],
    effectOwner: "LivePitchV1 awkward execution error / BattingWorkbench execution error",
    sourceDefinition: "canonical09 \xA75.2.1 / 2026-10-14 USER-DIRECTED REFINEMENT; no chase or result-probability bonus"
  }]);
  var getLiveTraitCatalogV1 = () => catalog;
  var assert2 = (value, message) => {
    if (!value) throw new Error("live trait profiles: " + message);
  };
  var text2 = (value) => typeof value === "string" && value.length > 0 && value.trim() === value && value.length <= 160;
  var object = (value, fields5, path) => {
    assert2(value && typeof value === "object" && !Array.isArray(value), "invalid " + path);
    const record = value;
    assert2(Object.keys(record).length === fields5.length && fields5.every((key) => Object.hasOwn(record, key)), "invalid fields " + path);
    return record;
  };
  var control = (value) => {
    assert2(typeof value === "number" && Number.isFinite(value) && value >= 0 && value <= 1, "invalid bad-ball technique source");
    return value;
  };
  var readProfile = (raw) => {
    const profile = object(cloneInert(raw), ["version", "selections"], "profile");
    assert2(profile.version === "live_trait_profile_v1" && Array.isArray(profile.selections), "unsupported profile");
    const seen = /* @__PURE__ */ new Set();
    const selections = profile.selections.map((rawSelection) => {
      const selection = object(rawSelection, ["familyId", "stateId", "source"], "selection"), definition = catalog.find((item) => item.familyId === selection.familyId);
      assert2(definition && !seen.has(definition.familyId), "unknown or duplicate trait family");
      seen.add(definition.familyId);
      assert2(selection.stateId === null || definition.states.some((state) => state.stateId === selection.stateId), "unsupported family state");
      const source = object(selection.source, ["badBallControl"], "source");
      return {
        familyId: definition.familyId,
        stateId: selection.stateId,
        source: { badBallControl: control(source.badBallControl) }
      };
    });
    return { version: "live_trait_profile_v1", selections };
  };
  function validateLiveTraitProfileV1(raw, physical2) {
    const profile = readProfile(raw), source = cloneInert(physical2);
    for (const selection of profile.selections) {
      const expected = selection.stateId === null ? 0 : selection.source.badBallControl;
      assert2(source.badBallControl === expected, "trait profile contradicts the executed bad-ball source");
    }
    return freeze4(profile);
  }
  function sourceOf(entry) {
    assert2(!(entry.physical && entry.workbenchPlayer), "ambiguous physical and workbench sources");
    const value = entry.physical ? entry.physical.badBallControl : entry.workbenchPlayer?.traits.badBallControl;
    return { value: value === void 0 ? null : control(value), path: entry.workbenchPlayer ? "workbenchPlayer.traits.badBallControl" : "physical.badBallControl" };
  }
  function context(raw, playerId) {
    const roster = cloneInert(raw);
    assert2(roster.version === "live_physical_roster_v1" && text2(roster.sourceId) && Array.isArray(roster.entries), "invalid roster");
    const ids = /* @__PURE__ */ new Set();
    for (const entry2 of roster.entries) {
      assert2(text2(entry2.playerId) && text2(entry2.sourceId) && !ids.has(entry2.playerId), "invalid or duplicate player source");
      ids.add(entry2.playerId);
      const source = sourceOf(entry2);
      if (entry2.traitProfile !== void 0) validateLiveTraitProfileV1(
        entry2.traitProfile,
        source.value === null ? {} : { badBallControl: source.value }
      );
    }
    const entry = roster.entries.find((item) => item.playerId === playerId);
    assert2(entry, "unknown player");
    return { roster, entry };
  }
  function projectLiveTraitProfilesV1(input) {
    const { entry } = context(input.roster, input.playerId), source = sourceOf(entry);
    return freeze4({
      boundary: "LOCAL_TRAIT_AUTHORING_ONLY",
      nativeMasteryAuthenticated: false,
      traits: catalog.map((definition) => {
        const selection = entry.traitProfile?.selections.find((item) => item.familyId === definition.familyId), owned = selection ? selection.stateId !== null : null, state = definition.states.find((item) => item.stateId === selection?.stateId);
        return {
          familyId: definition.familyId,
          label: definition.label,
          status: owned === null ? "UNASSESSED" : owned ? "OWNED" : "ABSENT",
          owned,
          stateId: selection?.stateId ?? null,
          color: state?.color ?? "neutral",
          sourceValue: selection?.source.badBallControl ?? source.value,
          effectiveSourceValue: source.value,
          sourcePath: source.path,
          sourceRoute: definition.sourceRoute
        };
      })
    });
  }
  function setLiveTraitProfileV1(input) {
    const request = cloneInert(input), { roster, entry } = context(request.roster, request.playerId), definition = catalog.find((item) => item.familyId === request.familyId);
    assert2(definition && (request.stateId === null || definition.states.some((state) => state.stateId === request.stateId)), "unknown family or state");
    assert2(entry.physical || entry.workbenchPlayer, "an explicit numerical source owner is required");
    const current = sourceOf(entry), previousProfile = entry.traitProfile, previous = previousProfile?.selections.find((item) => item.familyId === request.familyId);
    const explicit = request.source === void 0 ? null : control(object(request.source, ["badBallControl"], "source").badBallControl), retained = explicit ?? previous?.source.badBallControl ?? current.value ?? 0;
    const effective = request.stateId === null ? 0 : retained, changes = [];
    if (previous?.stateId === request.stateId && previous.source.badBallControl === retained && current.value === effective)
      return freeze4({ roster, projection: projectLiveTraitProfilesV1({ roster, playerId: request.playerId }), changes });
    assert2(request.stateId === null || explicit !== null || retained > 0, "an explicit technique source is required for initial zero or missing control");
    const mutable = entry, selections = [
      ...entry.traitProfile?.selections.filter((item) => item.familyId !== request.familyId) ?? [],
      { familyId: request.familyId, stateId: request.stateId, source: { badBallControl: retained } }
    ];
    mutable.traitProfile = { version: "live_trait_profile_v1", selections };
    changes.push({
      path: "traitProfile",
      before: cloneInert(previousProfile ?? null),
      after: cloneInert(mutable.traitProfile)
    });
    if (mutable.physical) mutable.physical.badBallControl = effective;
    else mutable.workbenchPlayer.traits.badBallControl = effective;
    if (current.value !== effective) changes.push({ path: current.path, before: current.value, after: effective });
    if (!mutable.sourceId.split(":").includes("trait-edited")) mutable.sourceId += ":trait-edited";
    const mutableRoster = roster;
    if (!mutableRoster.sourceId.split(":").includes("trait-edited")) mutableRoster.sourceId += ":trait-edited";
    assert2(text2(mutable.sourceId) && text2(mutableRoster.sourceId), "source identifier exceeds the authoring limit");
    return freeze4({ roster, projection: projectLiveTraitProfilesV1({ roster, playerId: request.playerId }), changes });
  }

  // src/integration/browser/LiveBaseballMatchV1.ts
  var LIVE_MATCH_AUTHORED_SI_DEFAULTS_V1 = Object.freeze({
    basis: "EXPLICIT_AUTHORED_SI_V1",
    batLengthM: 0.84,
    batMassKg: 0.88,
    swingRate: 1,
    timingStdSeconds: 9e-3,
    aimStdMeters: 0.022,
    chaseMarginMeters: 0.12,
    releaseSpeedMps: 42.5,
    spinRadPerSecond: Object.freeze({ x: -230, y: 15, z: 10 }),
    commandStdMeters: 0.11,
    reactionSeconds: 0.18,
    topSpeedMps: 8,
    accelerationMps2: 5.2,
    gloveSpeedMps: 11,
    gloveReachMeters: 1.35,
    gloveRadiusMeters: 0.11,
    retentionCapacityJ: 160,
    captureDissipationPowerW: 3e3,
    transferSeconds: 0.46,
    throwSpeedMps: 34
  });
  var zero3 = () => ({ x: 0, y: 0, z: 0 });
  var baseSide = 27.432 / Math.sqrt(2);
  var LIVE_MATCH_BASES_V1 = Object.freeze({
    home: Object.freeze(zero3()),
    first: Object.freeze({ x: baseSide, y: 0, z: baseSide }),
    second: Object.freeze({ x: 0, y: 0, z: baseSide * 2 }),
    third: Object.freeze({ x: -baseSide, y: 0, z: baseSide })
  });
  var LIVE_MATCH_PHYSICS_V1 = Object.freeze({
    kind: "aero_ground_v1",
    air: Object.freeze({ ticksPerSecond: 1e6, integrationStepTicks: 5e3, gravityY: -9.80665, aerodynamics: REALISTIC_LYU_2022_BASEBALL_AERODYNAMICS }),
    ground: Object.freeze({
      ticksPerSecond: 1e6,
      gravityMps2: 9.80665,
      radiusM: 0.0366,
      inertiaRatio: 0.378,
      restingVerticalSpeedMps: 0.28,
      material: Object.freeze({ restitution: 0.48, slidingFriction: 0.24, rollingDecelerationMps2: 0.36, normalSpinDecayPerSecond: 0.18 })
    })
  });

  // src/integration/browser/LivePhysicalRosterV1.ts
  var scalarKeys = [
    "batLengthM",
    "batMassKg",
    "swingRate",
    "timingStdSeconds",
    "aimStdMeters",
    "chaseMarginMeters",
    "releaseSpeedMps",
    "commandStdMeters",
    "reactionSeconds",
    "topSpeedMps",
    "accelerationMps2",
    "gloveSpeedMps",
    "gloveReachMeters",
    "gloveRadiusMeters",
    "retentionCapacityJ",
    "captureDissipationPowerW",
    "transferSeconds",
    "throwSpeedMps",
    "maximumPitchSpeedMps",
    "maximumSweetSpotSpeedMps",
    "targetSweetSpotSpeedMps",
    "motorLatencySeconds",
    "technicalTimingOffsetSeconds",
    "sweetSpotT",
    "attackAngleDegrees",
    "pullAngleDegrees",
    "badBallControl",
    "defensiveDecisionSeconds",
    "preContactSeconds",
    "followThroughSeconds",
    "contactDepthMeters",
    "throwDirectionStdRadians",
    "zoneJudgmentStdMeters",
    "baserunningSafetyMarginSeconds",
    "fieldingPursuitCostWeight",
    "baserunningTurnRadiusMeters",
    "baserunningLateralAccelerationMps2"
  ];
  var physicalKeys = ["basis", ...scalarKeys, "spinRadPerSecond", "clipId", "swingDecision"];
  var bounds = {
    batLengthM: [0.55, 1.2],
    batMassKg: [0.4, 1.8],
    swingRate: [0.3, 3],
    timingStdSeconds: [0, 0.08],
    aimStdMeters: [0, 0.35],
    chaseMarginMeters: [0, 0.6],
    releaseSpeedMps: [15, 85],
    maximumPitchSpeedMps: [15, 85],
    commandStdMeters: [0, 0.6],
    gloveSpeedMps: [0.1, 40],
    gloveReachMeters: [0.4, 3],
    gloveRadiusMeters: [0.03, 0.3],
    retentionCapacityJ: [1, 2e3],
    captureDissipationPowerW: [10, 1e6],
    maximumSweetSpotSpeedMps: [0.1, 90],
    targetSweetSpotSpeedMps: [0.1, 90],
    motorLatencySeconds: [0, 2],
    technicalTimingOffsetSeconds: [-0.5, 0.5],
    sweetSpotT: [0.65, 0.9],
    attackAngleDegrees: [-80, 80],
    pullAngleDegrees: [-80, 80],
    badBallControl: [0, 1],
    preContactSeconds: [5e-3, 2],
    followThroughSeconds: [5e-3, 2],
    contactDepthMeters: [1e-3, 2],
    throwDirectionStdRadians: [0, 0.12],
    zoneJudgmentStdMeters: [0, 0.6],
    baserunningSafetyMarginSeconds: [0, 3],
    fieldingPursuitCostWeight: [0.25, 4],
    baserunningTurnRadiusMeters: [0.5, 10],
    baserunningLateralAccelerationMps2: [0.5, 20]
  };
  var nonnegative = /* @__PURE__ */ new Set(["reactionSeconds", "transferSeconds", "defensiveDecisionSeconds"]);
  var freeze5 = (value) => {
    if (value && typeof value === "object") {
      Object.values(value).forEach(freeze5);
      Object.freeze(value);
    }
    return value;
  };
  function assert3(value, message) {
    if (!value) throw new Error("live physical roster: " + message);
  }
  var validText = (value) => typeof value === "string" && value.trim() === value && value.length > 0 && value.length <= 200;
  function fields4(value, allowed, required, path) {
    assert3(value && typeof value === "object" && !Array.isArray(value), "object required at " + path);
    assert3(Object.keys(value).every((k) => allowed.includes(k)) && required.every((k) => Object.hasOwn(value, k)), "unknown or missing fields at " + path);
  }
  function validatePhysical(raw) {
    fields4(raw, physicalKeys, ["basis"], "physical");
    assert3(raw.basis === "EXPLICIT_AUTHORED_SI_V1", "explicit SI basis required");
    for (const key of scalarKeys) if (Object.hasOwn(raw, key)) {
      const value = raw[key], limits = bounds[key];
      assert3(typeof value === "number" && Number.isFinite(value) && (limits ? value >= limits[0] && value <= limits[1] : nonnegative.has(key) ? value >= 0 : value > 0), "unsupported physical range: " + key);
    }
    if (Object.hasOwn(raw, "spinRadPerSecond")) {
      fields4(raw.spinRadPerSecond, ["x", "y", "z"], ["x", "y", "z"], "spinRadPerSecond");
      const spin = raw.spinRadPerSecond;
      assert3(Object.values(spin).every((n) => typeof n === "number" && Number.isFinite(n)) && Math.hypot(spin.x, spin.y, spin.z) <= 1200, "invalid SI spin");
    }
    if (Object.hasOwn(raw, "clipId")) assert3(validText(raw.clipId), "invalid measured clip identity");
    if (Object.hasOwn(raw, "swingDecision")) {
      fields4(raw.swingDecision, ["approach", "threshold", "aggressionWeight"], ["approach", "threshold", "aggressionWeight"], "swingDecision");
      assert3(["AUTO", "TAKE", "SWING"].includes(raw.swingDecision.approach) && [raw.swingDecision.threshold, raw.swingDecision.aggressionWeight].every((v) => typeof v === "number" && Number.isFinite(v) && v >= 0 && v <= 1), "invalid explicit swing decision");
    }
    if (raw.maximumSweetSpotSpeedMps !== void 0 && raw.targetSweetSpotSpeedMps !== void 0)
      assert3(raw.targetSweetSpotSpeedMps <= raw.maximumSweetSpotSpeedMps, "target swing speed exceeds declared motor ceiling");
  }
  function applyLivePhysicalRosterV1(raw) {
    const input = cloneInert(raw);
    fields4(input, ["players", "roster"], ["players", "roster"], "input");
    assert3(Array.isArray(input.players), "players required");
    const players = input.players;
    assert3(players.every((p) => validText(p.playerId) && validText(p.name) && Number.isFinite(p.heightMeters) && p.heightMeters >= 1.1 && p.heightMeters <= 2.5 && ["R", "L"].includes(p.bats)) && new Set(players.map((p) => p.playerId)).size === players.length, "invalid roster identity");
    fields4(input.roster, ["version", "sourceId", "entries"], ["version", "sourceId", "entries"], "roster");
    assert3(input.roster.version === "live_physical_roster_v1" && validText(input.roster.sourceId) && Array.isArray(input.roster.entries), "invalid roster packet");
    const entries = input.roster.entries;
    assert3(new Set(entries.map((e) => e.playerId)).size === entries.length, "duplicate player source binding");
    const byId = new Map(players.map((p) => [p.playerId, p]));
    for (const entry of entries) {
      fields4(entry, ["playerId", "sourceId", "workbenchPlayer", "physical", "maximumPitchSpeedKmh", "heightMeters", "legacyRelativeRatings", "traitLabels", "traitProfile"], ["playerId", "sourceId"], "entry");
      assert3(validText(entry.playerId) && validText(entry.sourceId) && byId.has(entry.playerId), "unknown player or source binding");
      assert3(!(Object.hasOwn(entry, "workbenchPlayer") && Object.hasOwn(entry, "physical")), "ambiguous physical authoring sources");
      if (Object.hasOwn(entry, "workbenchPlayer")) assert3(entry.workbenchPlayer && typeof entry.workbenchPlayer === "object", "invalid maker authoring source");
      if (Object.hasOwn(entry, "physical")) assert3(entry.physical && typeof entry.physical === "object", "invalid physical authoring source");
    }
    const auditPlayers = [];
    const output = players.map((player) => {
      const entry = entries.find((e) => e.playerId === player.playerId), projected = [], unsupported = [];
      let physical2 = { ...player.physical ?? LIVE_MATCH_AUTHORED_SI_DEFAULTS_V1 }, heightMeters = player.heightMeters;
      validatePhysical(physical2);
      let sourcePlayerId = null;
      const project = (inputPath, targetPath, value, conversion = "identity") => {
        projected.push({ inputPath, targetPath, value: cloneInert(value), conversion });
      };
      if (entry?.physical) {
        validatePhysical(entry.physical);
        physical2 = { ...physical2, ...entry.physical };
        for (const key of Object.keys(entry.physical).filter((k) => k !== "basis")) project("physical." + key, key, entry.physical[key]);
      }
      if (entry?.workbenchPlayer) {
        const maker = createWorkbenchPlayer(entry.workbenchPlayer), c = maker.capability, s = maker.swing;
        sourcePlayerId = maker.identity.playerId;
        heightMeters = maker.body.heightMeters;
        physical2 = {
          ...physical2,
          batLengthM: maker.bat.lengthM,
          batMassKg: maker.bat.massKg,
          sweetSpotT: maker.bat.sweetSpotT,
          maximumSweetSpotSpeedMps: c.maximumSweetSpotSpeedMps,
          targetSweetSpotSpeedMps: s.speedMps,
          motorLatencySeconds: c.motorLatencyTicks / WORKBENCH_TICKS_PER_SECOND,
          technicalTimingOffsetSeconds: c.technicalTimingOffsetTicks / WORKBENCH_TICKS_PER_SECOND,
          timingStdSeconds: c.timingErrorTicks / WORKBENCH_TICKS_PER_SECOND,
          aimStdMeters: c.positionErrorMeters,
          topSpeedMps: c.runSpeedMps,
          throwSpeedMps: c.throwSpeedMps,
          releaseSpeedMps: c.pitchSpeedMps,
          attackAngleDegrees: s.attackAngleDeg,
          pullAngleDegrees: s.pullAngleDeg,
          swingDecision: maker.decision,
          badBallControl: maker.traits.badBallControl,
          preContactSeconds: s.preContactSeconds,
          followThroughSeconds: s.followThroughSeconds,
          contactDepthMeters: s.contactDepthM
        };
        const mappings = [
          ["body.heightMeters", "heightMeters"],
          ["bat.lengthM", "batLengthM"],
          ["bat.massKg", "batMassKg"],
          ["bat.sweetSpotT", "sweetSpotT"],
          ["capability.maximumSweetSpotSpeedMps", "maximumSweetSpotSpeedMps"],
          ["swing.speedMps", "targetSweetSpotSpeedMps"],
          ["capability.motorLatencyTicks", "motorLatencySeconds"],
          ["capability.technicalTimingOffsetTicks", "technicalTimingOffsetSeconds"],
          ["capability.timingErrorTicks", "timingStdSeconds"],
          ["capability.positionErrorMeters", "aimStdMeters"],
          ["capability.runSpeedMps", "topSpeedMps"],
          ["capability.throwSpeedMps", "throwSpeedMps"],
          ["capability.pitchSpeedMps", "releaseSpeedMps"],
          ["swing.attackAngleDeg", "attackAngleDegrees"],
          ["swing.pullAngleDeg", "pullAngleDegrees"],
          ["decision", "swingDecision"],
          ["traits.badBallControl", "badBallControl"],
          ["swing.preContactSeconds", "preContactSeconds"],
          ["swing.followThroughSeconds", "followThroughSeconds"],
          ["swing.contactDepthM", "contactDepthMeters"]
        ];
        for (const [from, to] of mappings) project("workbenchPlayer." + from, to, to === "heightMeters" ? heightMeters : physical2[to], from.endsWith("Ticks") ? "tick / 1000000" : "identity");
        for (const path of ["body.massKg", "swing.loadAngleDeg", "swing.finishAngleDeg", "swing.handTravelM"]) {
          const [group, key] = path.split(".");
          unsupported.push({
            path: "workbenchPlayer." + path,
            value: maker[group][key],
            reason: "No corresponding individual body/reference-trajectory motor consumer in this local Host; no inferred effect."
          });
        }
        for (const key of ["playerId", "name", "leagueId", "bats", "throws"]) unsupported.push({
          path: "workbenchPlayer.identity." + key,
          value: maker.identity[key],
          reason: "Ability-only binding keeps the selected match identity and handedness; this identity field is retained as source provenance, not applied."
        });
        maker.traits.labels.forEach((value, index) => unsupported.push({
          path: `workbenchPlayer.traits.labels[${index}]`,
          value,
          reason: "A display label does not supply a calibrated technical source or an extra physical bonus."
        }));
      }
      if (entry?.maximumPitchSpeedKmh !== void 0) {
        assert3(Number.isFinite(entry.maximumPitchSpeedKmh) && entry.maximumPitchSpeedKmh >= 54 && entry.maximumPitchSpeedKmh <= 306, "unsupported maximum pitch speed");
        const maximumPitchSpeedMps = entry.maximumPitchSpeedKmh / 3.6;
        assert3(physical2.maximumPitchSpeedMps === void 0 || physical2.maximumPitchSpeedMps === maximumPitchSpeedMps, "conflicting pitch speed limits");
        physical2 = { ...physical2, maximumPitchSpeedMps };
        project("maximumPitchSpeedKmh", "maximumPitchSpeedMps", maximumPitchSpeedMps, "km/h / 3.6");
      }
      if (entry?.heightMeters !== void 0) {
        assert3(Number.isFinite(entry.heightMeters) && entry.heightMeters >= 1.1 && entry.heightMeters <= 2.5, "unsupported physical height");
        assert3(!entry.workbenchPlayer || entry.workbenchPlayer.body.heightMeters === entry.heightMeters, "conflicting body heights");
        heightMeters = entry.heightMeters;
        project("heightMeters", "heightMeters", heightMeters);
      }
      if (entry?.legacyRelativeRatings !== void 0) {
        assert3(entry.legacyRelativeRatings && typeof entry.legacyRelativeRatings === "object" && !Array.isArray(entry.legacyRelativeRatings), "invalid relative ratings");
        for (const [key, value] of Object.entries(entry.legacyRelativeRatings)) {
          assert3(validText(key) && Number.isFinite(value), "invalid relative rating entry");
          unsupported.push({ path: "legacyRelativeRatings." + key, value, reason: "Relative display rating has no calibrated SI inverse; preserved without physical conversion." });
        }
      }
      if (entry?.traitLabels !== void 0) {
        assert3(Array.isArray(entry.traitLabels) && entry.traitLabels.every(validText) && new Set(entry.traitLabels).size === entry.traitLabels.length, "invalid trait labels");
        entry.traitLabels.forEach((value, index) => unsupported.push({
          path: `traitLabels[${index}]`,
          value,
          reason: "Trait name alone is descriptive; an explicit current numerical source is required to execute its skill."
        }));
      }
      validatePhysical(physical2);
      const traitProfile = entry?.traitProfile === void 0 ? void 0 : validateLiveTraitProfileV1(entry.traitProfile, physical2);
      if (traitProfile !== void 0) project("traitProfile", "traitProfile", traitProfile, "LOCAL_SOURCE_METADATA_NO_ADDITIONAL_EFFECT");
      assert3(heightMeters >= 1.1 && heightMeters <= 2.5, "unsupported physical height");
      const targetPaths = new Set(projected.map((p) => p.targetPath));
      auditPlayers.push({
        playerId: player.playerId,
        sourceId: entry?.sourceId ?? null,
        sourcePlayerId,
        projected,
        unsupported,
        referenceDefaultPaths: player.physical ? [] : Object.keys(LIVE_MATCH_AUTHORED_SI_DEFAULTS_V1).filter((k) => k !== "basis" && !targetPaths.has(k))
      });
      const { traitProfile: _previousProfile, ...basePlayer } = player;
      return { ...basePlayer, heightMeters, physical: physical2, ...traitProfile === void 0 ? {} : { traitProfile } };
    });
    return freeze5({ players: output, audit: {
      version: "live_physical_roster_projection_v1",
      sourceId: input.roster.sourceId,
      nativeAuthentication: false,
      projectionOnly: true,
      players: auditPlayers
    } });
  }

  // src/integration/browser/LivePublicAbilitiesV1.ts
  var up = (path) => ({ path, direction: 1, floor: 0 });
  var down = (path, floor) => ({ path, direction: -1, floor });
  var specs = [
    { id: "contact", label: "\u30DF\u30FC\u30C8", section: "batter", mode: "group", components: [down("aimStdMeters", 1e-3), down("timingStdSeconds", 1e-3)], note: "\u72D9\u3046\u4F4D\u7F6E\u3068\u30BF\u30A4\u30DF\u30F3\u30B0\u306E\u7CBE\u5EA6" },
    { id: "power", label: "\u30D1\u30EF\u30FC", section: "batter", mode: "group", components: [up("targetSweetSpotSpeedMps"), up("maximumSweetSpotSpeedMps")], note: "\u82AF\u306E\u76EE\u6A19\u901F\u5EA6\u3068\u6700\u5927\u901F\u5EA6" },
    { id: "vision", label: "\u9078\u7403\u773C", section: "batter", mode: "group", components: [down("zoneJudgmentStdMeters", 1e-3)], note: "\u30B3\u30FC\u30B9\u5224\u65AD\u306E\u7CBE\u5EA6\u3002\u7A4D\u6975\u6027\u306F\u8A73\u7D30\u3067\u5225\u306B\u8A2D\u5B9A" },
    { id: "run", label: "\u8D70\u529B", section: "common", mode: "group", components: [up("topSpeedMps"), up("accelerationMps2")], note: "\u6700\u9AD8\u901F\u5EA6\u3068\u52A0\u901F" },
    { id: "arm", label: "\u80A9\u529B", section: "common", mode: "group", components: [up("throwSpeedMps")], note: "\u5B9F\u969B\u306E\u9001\u7403\u521D\u901F" },
    { id: "field", label: "\u5B88\u5099\u529B", section: "common", mode: "group", components: [down("reactionSeconds", 0.01), down("defensiveDecisionSeconds", 0.01), down("transferSeconds", 0.01)], note: "\u521D\u52D5\u30FB\u72B6\u6CC1\u5224\u65AD\u30FB\u6301\u3061\u66FF\u3048\u3002\u8D70\u529B\u3068\u6355\u7403\u306F\u5225" },
    { id: "catching", label: "\u6355\u7403", section: "common", mode: "group", components: [up("gloveSpeedMps"), up("retentionCapacityJ"), up("captureDissipationPowerW")], note: "\u30B0\u30E9\u30D6\u306E\u52D5\u4F5C\u3068\u885D\u6483\u306E\u5438\u53CE\u30FB\u4FDD\u6301" },
    { id: "throwingAccuracy", label: "\u9001\u7403\u7CBE\u5EA6", section: "common", mode: "group", components: [down("throwDirectionStdRadians", 1e-4)], note: "\u30EA\u30EA\u30FC\u30B9\u65B9\u5411\u306E\u7CBE\u5EA6" },
    { id: "maxSpeedKmh", label: "\u7403\u901F", section: "pitcher", mode: "pitchSpeed", components: [up("maximumPitchSpeedMps"), up("releaseSpeedMps")], note: "\u6700\u9AD8\u521D\u901F\u3002\u57FA\u6E96\u521D\u901F\u3068\u306E\u6BD4\u7387\u3092\u7DAD\u6301" },
    { id: "control", label: "\u5236\u7403", section: "pitcher", mode: "group", components: [down("commandStdMeters", 1e-3)], note: "\u6295\u7403\u306E\u72D9\u3044\u4F4D\u7F6E\u306E\u7CBE\u5EA6" }
  ];
  var policyId = "individual-profile-public-authoring-v1";
  var pointsPerLogUnit = 100;
  var assert4 = (value, message) => {
    if (!value) throw new Error("public abilities: " + message);
  };
  var freeze6 = (value) => {
    if (value && typeof value === "object") {
      Object.values(value).forEach(freeze6);
      Object.freeze(value);
    }
    return value;
  };
  var physical = (entry) => {
    assert4(entry.physical && !entry.workbenchPlayer && entry.maximumPitchSpeedKmh === void 0, "explicit SI entry without competing speed source required");
    return entry.physical;
  };
  function numeric(entry, path) {
    const value = physical(entry)[path] ?? (path === "zoneJudgmentStdMeters" ? 0 : void 0);
    assert4(typeof value === "number" && Number.isFinite(value), "missing SI control: " + path);
    return value;
  }
  function context2(input) {
    const reference = input.reference;
    assert4(reference?.version === "live_public_ability_reference_v1" && reference.policyId === policyId, "unsupported authoring reference");
    assert4(Array.isArray(reference.players) && Array.isArray(reference.anchors) && reference.players.length === reference.anchors.length && new Set(reference.anchors.map((a) => a.playerId)).size === reference.anchors.length, "invalid reference bindings");
    const ids = new Set(reference.players.map((p) => p.playerId));
    assert4(reference.anchors.every((a) => ids.has(a.playerId) && a.entry.playerId === a.playerId && typeof a.leagueId === "string" && typeof a.role === "string" && specs.filter((s) => s.mode === "group").every((s) => Number.isFinite(a.ratings[s.id]) && a.ratings[s.id] >= 0 && a.ratings[s.id] <= 100)), "invalid reference anchor");
    applyLivePhysicalRosterV1({ players: reference.players, roster: input.roster });
    assert4(input.roster.entries.length === ids.size && input.roster.entries.every((e) => ids.has(e.playerId)), "complete reference roster required");
    applyLivePhysicalRosterV1({ players: reference.players, roster: { version: "live_physical_roster_v1", sourceId: policyId, entries: reference.anchors.map((a) => a.entry) } });
    const entry = input.roster.entries.find((e) => e.playerId === input.playerId), anchor = reference.anchors.find((a) => a.playerId === input.playerId);
    assert4(entry && anchor, "unknown player");
    return { entry, anchor };
  }
  function quality(entry, spec) {
    const components = spec.mode === "pitchSpeed" ? spec.components.slice(0, 1) : spec.components;
    return components.reduce((sum, c) => {
      const value = numeric(entry, c.path) + c.floor;
      assert4(value > 0, "nonpositive ability component: " + c.path);
      return sum + c.direction * Math.log(value);
    }, 0) / components.length;
  }
  function abilityValue(entry, anchor, spec) {
    if (spec.mode === "percent") return numeric(entry, spec.components[0].path) * 100;
    if (spec.mode === "pitchSpeed") return numeric(entry, spec.components[0].path) * 3.6;
    return anchor.ratings[spec.id] + pointsPerLogUnit * (quality(entry, spec) - quality(anchor.entry, spec));
  }
  function projectLivePublicAbilitiesV1(input) {
    const { entry, anchor } = context2(input);
    return freeze6({ policyId, abilities: specs.map((spec) => ({
      id: spec.id,
      label: spec.label,
      section: spec.section,
      value: abilityValue(entry, anchor, spec),
      min: spec.mode === "pitchSpeed" ? 54 : 0,
      max: spec.mode === "pitchSpeed" ? 306 : 100,
      unit: spec.mode === "pitchSpeed" ? "km/h" : "",
      linkedPaths: spec.components.map((c) => c.path),
      note: spec.note
    })) });
  }
  function editLivePublicAbilityV1(input) {
    const projection = projectLivePublicAbilitiesV1(input), spec = specs.find((s) => s.id === input.abilityId), old = projection.abilities.find((a) => a.id === input.abilityId);
    assert4(spec && old && Number.isFinite(input.value), "invalid public ability value");
    assert4(input.value === old.value || input.value >= old.min && input.value <= old.max, "invalid public ability value");
    const copy = cloneInert(input.roster);
    const selected = copy.entries.find((e) => e.playerId === input.playerId);
    const before = input.roster.entries.find((e) => e.playerId === input.playerId);
    const changes = [];
    if (input.value !== old.value) {
      for (const component of spec.components) {
        const previous = numeric(before, component.path);
        const next = spec.mode === "percent" ? input.value / 100 : spec.mode === "pitchSpeed" ? previous * input.value / old.value : (previous + component.floor) * Math.exp(component.direction * (input.value - old.value) / pointsPerLogUnit) - component.floor;
        assert4(Number.isFinite(next) && next >= 0, "requested value exceeds this individual profile; inspect detailed controls");
        selected.physical[component.path] = next;
        changes.push({ path: component.path, before: previous, after: next });
      }
      if (!selected.sourceId.split(":").includes("public-edited")) selected.sourceId += ":public-edited";
      copy.sourceId = input.roster.sourceId.split(":").includes("public-edited") ? input.roster.sourceId : input.roster.sourceId + ":public-edited";
    }
    const roster = copy;
    applyLivePhysicalRosterV1({ players: input.reference.players, roster });
    return freeze6({ policyId, roster, projection: projectLivePublicAbilitiesV1({ ...input, roster }), changes });
  }
  function previewLivePublicLeagueV1(input) {
    const { entry, anchor } = context2(input);
    assert4(["MLB", "NLB", "NPB", "KBO", "CUSTOM"].includes(input.leagueId), "unsupported preview league");
    const candidates = input.reference.anchors.filter((a) => a.leagueId === input.leagueId);
    const byId = new Map(input.roster.entries.map((e) => [e.playerId, e]));
    return freeze6({ leagueId: input.leagueId, sampleCount: candidates.length, metrics: specs.map((spec) => {
      const peers = candidates.filter((a) => spec.section !== "pitcher" || a.role === "P").filter((a) => spec.section !== "batter" || a.role !== "P");
      const values = peers.map((a) => spec.mode === "percent" ? numeric(byId.get(a.playerId), spec.components[0].path) : quality(byId.get(a.playerId), spec));
      const mean = values.reduce((sum, n) => sum + n, 0) / (values.length || 1);
      const sd = Math.sqrt(values.reduce((sum, n) => sum + (n - mean) ** 2, 0) / (values.length || 1));
      const actual = spec.mode === "percent" ? numeric(entry, spec.components[0].path) : quality(entry, spec);
      return {
        id: spec.id,
        label: spec.label,
        sampleCount: values.length,
        value: values.length >= 2 && sd > 0 ? Math.max(0, Math.min(100, 50 + 20 * (actual - mean) / sd)) : null
      };
    }), sourceLeagueId: anchor.leagueId, basis: "SUPPLIED_LOCAL_SAMPLE_NOT_OFFICIAL_LEAGUE_POPULATION" });
  }
  return __toCommonJS(workbench_index_exports);
})();
